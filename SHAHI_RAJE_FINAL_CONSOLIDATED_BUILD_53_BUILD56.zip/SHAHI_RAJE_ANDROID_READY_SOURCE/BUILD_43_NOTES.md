BUILD 43 — Renderer resilience
- WebView render-process callbacks installed.
- Keeps lifecycle hooks available for future recovery UX.
- Version 43.0.
