#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
test -f "$ROOT/settings.gradle"
test -f "$ROOT/build.gradle"
test -f "$ROOT/app/build.gradle"
test -f "$ROOT/app/src/main/AndroidManifest.xml"
test -f "$ROOT/app/src/main/assets/index.html"
test -f "$ROOT/app/src/main/assets/app.js"
grep -q "versionCode 52" "$ROOT/app/build.gradle"
grep -q "cleartextTrafficPermitted=\"false\"" "$ROOT/app/src/main/res/xml/network_security_config.xml"
if command -v node >/dev/null 2>&1; then node --check "$ROOT/app/src/main/assets/app.js"; fi
echo "BUILD 52 STATIC VALIDATION PASS"
