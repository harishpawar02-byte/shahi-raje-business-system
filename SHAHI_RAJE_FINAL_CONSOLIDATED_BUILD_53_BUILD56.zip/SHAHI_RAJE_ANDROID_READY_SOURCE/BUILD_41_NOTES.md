BUILD 41 — Android WebView hardening
- Local app remains offline-first.
- HTTP/HTTPS links are opened externally instead of navigating the local app shell.
- File-URL universal access disabled.
- File-URL file access disabled.
- Zoom disabled for predictable mobile UI.
- Version 41.0.
