#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
test -f "$ROOT/settings.gradle"
test -f "$ROOT/app/build.gradle"
test -f "$ROOT/app/src/main/AndroidManifest.xml"
test -f "$ROOT/app/src/main/java/com/shahiraje/business/MainActivity.java"
test -f "$ROOT/app/src/main/res/xml/network_security_config.xml"
test -f "$ROOT/app/src/main/assets/index.html"
test -f "$ROOT/app/src/main/assets/app.js"
grep -q "versionCode 43" "$ROOT/app/build.gradle"
grep -q 'cleartextTrafficPermitted="false"' "$ROOT/app/src/main/res/xml/network_security_config.xml"
node --check "$ROOT/app/src/main/assets/app.js"
printf '%s\n' 'BUILD 44 STATIC VALIDATION PASS'
