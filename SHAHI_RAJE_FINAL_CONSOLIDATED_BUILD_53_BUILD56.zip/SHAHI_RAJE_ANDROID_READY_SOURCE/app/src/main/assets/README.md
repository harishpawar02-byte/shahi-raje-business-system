# SHAHI RAJE Mobile App

Mobile-first Progressive Web App build based on the existing SHAHI RAJE SQLite project.

## Current build
- Mobile-first dashboard
- Products/SKU viewer
- Inventory ledger viewer
- Safe stock correction workflow that creates a new correction ledger entry
- Suppliers
- Customers
- Purchase
- Production
- Sales
- Finance
- Reports
- Marathi/Hindi/English/Gujarati UI labels
- Offline service-worker cache
- Existing SQLite data exported to `seed.json`

## Important
This package is an installable PWA build, not an Android APK. An APK requires an Android build environment (Android SDK/Gradle) which was not available in the current execution environment.

To install as an app, serve this folder over HTTPS and choose **Add to Home Screen / Install App** in a supported mobile browser.
