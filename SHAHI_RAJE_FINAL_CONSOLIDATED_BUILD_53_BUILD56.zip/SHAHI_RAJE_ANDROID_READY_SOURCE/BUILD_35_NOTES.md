# SHAHI RAJE — Build 35

## Changes
- Android versionCode/versionName bumped to 35/35.0.
- WebView lifecycle/state restoration hardened.
- Disabled cleartext network traffic for the local APK shell.
- Preserved localStorage and offline service-worker behavior.
- Mobile data namespace moved from v34 to v35 to avoid accidental cross-build state collisions.
- Service-worker cache namespace moved to v35.

## Verification performed in this environment
- Existing Python regression suite: 28 passed.
- Python compileall: passed.
- Android source structure inspected.
- JavaScript syntax check: performed with Node.js.

## APK status
This package is Android build-ready source, not a verified APK. The current execution environment does not have an Android SDK/build-tools installation, so an APK is not claimed until an actual Android build is executed and the resulting APK is verified.
