BUILD 42 — Network security baseline
- Cleartext HTTP disabled by Android Network Security Config.
- HTTPS remains available for future backend integrations.
- Version 42.0.
