# SHAHI RAJE Build 56 — White Screen Fix

- Version code: 56
- Version name: 56.0
- Replaced `file:///android_asset/index.html` loading with AndroidX WebViewAssetLoader secure asset origin.
- Local assets are served from `https://appassets.androidplatform.net/assets/`.
- `seed.json`, `app.js`, manifest and service worker now load under a secure origin.
- Disabled WebView file/content access while preserving local asset access through the asset loader.
- External HTTP/HTTPS URLs continue to open outside the app.
- Permanent signing is expected to be performed by the existing GitHub Actions release workflow.

This package is source-ready; APK build/signing must still be performed by the GitHub Actions workflow.
