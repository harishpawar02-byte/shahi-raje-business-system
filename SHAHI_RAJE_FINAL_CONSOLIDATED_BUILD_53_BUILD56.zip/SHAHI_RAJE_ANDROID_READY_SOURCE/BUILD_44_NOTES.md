BUILD 44 — Release validation
- Added deterministic static Android source validation script.
- Verifies required Android files/assets, SDK config, security policy and JavaScript syntax.
- Version remains 43.0 because Build 44 is a QA/release-validation build, not an app version bump.
