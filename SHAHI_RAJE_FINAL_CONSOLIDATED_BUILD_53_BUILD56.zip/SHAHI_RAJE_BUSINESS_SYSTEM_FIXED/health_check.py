from database.migrations.migration_manager import run_migrations, applied_versions
from database.connection import get_connection
from core.backup import validate_db
from config import DB_PATH

run_migrations()
c=get_connection()
try:
    print('Migrations:', ', '.join(sorted(applied_versions(c))))
    print('Integrity:', c.execute('PRAGMA integrity_check').fetchone()[0])
    print('Foreign-key errors:', len(c.execute('PRAGMA foreign_key_check').fetchall()))
    print('Tables:', c.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0])
finally:
    c.close()
print('DB validation:', validate_db(DB_PATH))
