from database.repositories.base_repository import BaseRepository


class UnitRepository(BaseRepository):
    table = "units"

    def get_all(self, active_only=True):
        return self.conn.execute(
            "SELECT * FROM units ORDER BY name"
        ).fetchall()


class WarehouseRepository(BaseRepository):
    table = "warehouses"
