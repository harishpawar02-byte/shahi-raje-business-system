"""
Common CRUD helpers so individual repositories stay short.
Business logic (validation, permission checks) does NOT live here —
it lives in services/. This file only talks SQL.
"""


class BaseRepository:
    table = None

    def __init__(self, conn):
        self.conn = conn

    def get_all(self, active_only=True):
        q = f"SELECT * FROM {self.table}"
        if active_only:
            q += " WHERE is_active = 1"
        return self.conn.execute(q).fetchall()

    def get_by_id(self, id_):
        return self.conn.execute(
            f"SELECT * FROM {self.table} WHERE id = ?", (id_,)).fetchone()

    def deactivate(self, id_):
        """Soft delete — rule #12: never hard-delete business records."""
        self.conn.execute(
            f"UPDATE {self.table} SET is_active = 0 WHERE id = ?", (id_,))
        self.conn.commit()
