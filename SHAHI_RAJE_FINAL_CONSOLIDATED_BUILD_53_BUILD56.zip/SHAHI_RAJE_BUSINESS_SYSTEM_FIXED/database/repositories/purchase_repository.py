from database.repositories.base_repository import BaseRepository


class PurchaseOrderRepository(BaseRepository):
    table = "purchase_orders"

    def create(self, po_number, supplier_id, created_by):
        cur = self.conn.execute(
            "INSERT INTO purchase_orders (po_number, supplier_id, created_by) VALUES (?,?,?)",
            (po_number, supplier_id, created_by))
        self.conn.commit()
        return cur.lastrowid

    def add_item(self, po_id, raw_material_id, quantity, rate):
        cur = self.conn.execute(
            """INSERT INTO purchase_order_items
               (po_id, raw_material_id, quantity, rate) VALUES (?,?,?,?)""",
            (po_id, raw_material_id, str(quantity), str(rate)))
        self.conn.commit()
        return cur.lastrowid

    def items(self, po_id):
        return self.conn.execute(
            "SELECT * FROM purchase_order_items WHERE po_id=?", (po_id,)).fetchall()

    def set_status(self, po_id, status):
        self.conn.execute(
            "UPDATE purchase_orders SET status=? WHERE id=?", (status, po_id))
        self.conn.commit()

    def mark_received(self, po_item_id, qty):
        self.conn.execute(
            """UPDATE purchase_order_items
               SET received_qty = CAST(received_qty AS REAL) + ?
               WHERE id=?""", (float(qty), po_item_id))
        self.conn.commit()
