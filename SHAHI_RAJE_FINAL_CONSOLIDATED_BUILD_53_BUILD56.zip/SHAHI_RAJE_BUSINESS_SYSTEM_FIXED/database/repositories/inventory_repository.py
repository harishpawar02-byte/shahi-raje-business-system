from core.money import to_qty
from core.exceptions import InsufficientStockError, ValidationError
from core.audit import write_audit

class InventoryRepository:
    def __init__(self, conn): self.conn = conn

    def get_balance(self, item_type, item_id, warehouse_id=None, batch_id=None):
        q = "SELECT COALESCE(SUM(CAST(quantity AS DECIMAL)),0) bal FROM stock_movements WHERE item_type=? AND item_id=?"
        p = [item_type, item_id]
        if warehouse_id is not None: q += " AND warehouse_id=?"; p.append(warehouse_id)
        if batch_id is not None: q += " AND batch_id=?"; p.append(batch_id)
        return to_qty(self.conn.execute(q, p).fetchone()["bal"])

    def get_unassigned_balance(self, item_type, item_id, batch_id=None):
        q = "SELECT COALESCE(SUM(CAST(quantity AS DECIMAL)),0) bal FROM stock_movements WHERE item_type=? AND item_id=? AND warehouse_id IS NULL"
        p = [item_type, item_id]
        if batch_id is not None: q += " AND batch_id=?"; p.append(batch_id)
        return to_qty(self.conn.execute(q, p).fetchone()["bal"])

    def unassigned_fefo_batches(self, item_type, item_id):
        q='''SELECT id,batch_number,expiry_date FROM batches WHERE item_type=? AND item_id=?
             AND (saleable=1 OR item_type='raw_material')
             ORDER BY CASE WHEN expiry_date IS NULL THEN 1 ELSE 0 END, expiry_date ASC,id ASC'''
        out=[]
        for r in self.conn.execute(q,(item_type,item_id)):
            bal=self.get_unassigned_balance(item_type,item_id,r['id'])
            if bal>0: out.append({'batch_id':r['id'],'batch_number':r['batch_number'],'expiry_date':r['expiry_date'],'balance':bal})
        return out

    def record_movement(self, *, item_type, item_id, movement_type, quantity, warehouse_id=None,
                        batch_id=None, reference=None, user='system', allow_negative=False,
                        source='application', correction_of_id=None, correction_reason=None,
                        approved_by=None, commit=True):
        qty = to_qty(quantity)
        if qty == 0: raise ValidationError('Stock quantity cannot be zero')
        if qty < 0 and not allow_negative:
            projected = self.get_balance(item_type, item_id, warehouse_id, batch_id) + qty
            if projected < 0: raise InsufficientStockError(f'Stock cannot go negative (projected {projected})')
        if correction_of_id is not None:
            original = self.conn.execute("SELECT * FROM stock_movements WHERE id=?", (correction_of_id,)).fetchone()
            if not original: raise ValidationError('Original stock movement not found')
            if original['correction_of_id'] is not None: raise ValidationError('A correction cannot be corrected again; correct the latest effective entry')
            if not correction_reason or not correction_reason.strip(): raise ValidationError('Correction reason is required')
        cur = self.conn.execute('''INSERT INTO stock_movements
            (item_type,item_id,batch_id,warehouse_id,movement_type,quantity,reference,created_by,correction_of_id,correction_reason,approved_by,source)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
            (item_type,item_id,batch_id,warehouse_id,movement_type,str(qty),reference,user,correction_of_id,correction_reason,approved_by,source))
        write_audit(self.conn, user=user, action=f'stock:{movement_type}', entity=item_type, entity_id=item_id,
                    after={'quantity':str(qty),'batch_id':batch_id,'warehouse_id':warehouse_id,'reference':reference},
                    reason=correction_reason or '', approved_by=approved_by or '', source=source, commit=False)
        if commit: self.conn.commit()
        return cur.lastrowid

    def fefo_batches(self, item_type, item_id, warehouse_id=None):
        q='''SELECT id,batch_number,expiry_date FROM batches WHERE item_type=? AND item_id=?
             AND (saleable=1 OR item_type='raw_material')
             ORDER BY CASE WHEN expiry_date IS NULL THEN 1 ELSE 0 END, expiry_date ASC,id ASC'''
        out=[]
        for r in self.conn.execute(q,(item_type,item_id)):
            bal=self.get_balance(item_type,item_id,warehouse_id,r['id'])
            if bal>0: out.append({'batch_id':r['id'],'batch_number':r['batch_number'],'expiry_date':r['expiry_date'],'balance':bal})
        return out

    def create_batch(self, *, batch_number, item_type, item_id, mfg_date=None, expiry_date=None, recipe_version_id=None, commit=True):
        if not batch_number or not batch_number.strip(): raise ValidationError('Batch number is required')
        cur=self.conn.execute('INSERT INTO batches(batch_number,item_type,item_id,mfg_date,expiry_date,recipe_version_id) VALUES(?,?,?,?,?,?)',
                              (batch_number.strip(),item_type,item_id,mfg_date,expiry_date,recipe_version_id))
        if commit:self.conn.commit()
        return cur.lastrowid

    def ledger(self,item_type=None,item_id=None,limit=200):
        limit=max(1,min(int(limit),5000)); q='SELECT * FROM stock_movements WHERE 1=1';p=[]
        if item_type:q+=' AND item_type=?';p.append(item_type)
        if item_id:q+=' AND item_id=?';p.append(item_id)
        q+=' ORDER BY id DESC LIMIT ?';p.append(limit)
        return self.conn.execute(q,p).fetchall()
