from database.repositories.base_repository import BaseRepository


class SupplierRepository(BaseRepository):
    table = "suppliers"

    def create(self, name, contact=None, gstin=None):
        cur = self.conn.execute(
            "INSERT INTO suppliers (name, contact, gstin) VALUES (?,?,?)",
            (name, contact, gstin))
        self.conn.commit()
        return cur.lastrowid


class CustomerRepository(BaseRepository):
    table = "customers"

    def create(self, name, customer_type="Direct Customer",
               contact=None, gstin=None):
        cur = self.conn.execute(
            """INSERT INTO customers (name, customer_type, contact, gstin)
               VALUES (?,?,?,?)""",
            (name, customer_type, contact, gstin))
        self.conn.commit()
        return cur.lastrowid
