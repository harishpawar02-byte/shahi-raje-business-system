from database.repositories.base_repository import BaseRepository


class ProductRepository(BaseRepository):
    table = "products"

    def create(self, name, category=None):
        cur = self.conn.execute(
            "INSERT INTO products (name, category) VALUES (?,?)",
            (name, category))
        self.conn.commit()
        return cur.lastrowid


class SKURepository(BaseRepository):
    table = "skus"

    def create(self, product_id, sku_code, pack_size, unit_id,
               selling_price, barcode=None):
        cur = self.conn.execute(
            """INSERT INTO skus
               (product_id, sku_code, pack_size, unit_id, selling_price, barcode)
               VALUES (?,?,?,?,?,?)""",
            (product_id, sku_code, pack_size, unit_id,
             str(selling_price), barcode))
        self.conn.commit()
        return cur.lastrowid

    def by_product(self, product_id):
        return self.conn.execute(
            "SELECT * FROM skus WHERE product_id = ? AND is_active = 1",
            (product_id,)).fetchall()
