from pathlib import Path
from database.connection import get_connection
from core.logging_config import get_logger
VERSIONS_DIR = Path(__file__).parent / "versions"
logger = get_logger("migrations")

def _ensure_tracking_table(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT (datetime('now')))" )
    conn.commit()

def applied_versions(conn):
    _ensure_tracking_table(conn)
    return {r[0] for r in conn.execute("SELECT version FROM schema_migrations")}

def run_migrations():
    conn = get_connection()
    try:
        _ensure_tracking_table(conn)
        applied = applied_versions(conn)
        for f in sorted(VERSIONS_DIR.glob("v*.sql")):
            version = f.stem
            if version in applied: continue
            sql = f.read_text(encoding="utf-8")
            try:
                conn.executescript(sql)
                conn.execute("INSERT INTO schema_migrations(version) VALUES (?)", (version,))
                conn.commit()
                logger.info("Applied migration %s", version)
            except Exception:
                conn.rollback()
                raise
    finally:
        conn.close()
