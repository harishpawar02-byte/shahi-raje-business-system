-- v001: Phase 0/1 foundation schema
-- Money/qty stored as TEXT to preserve exact Decimal precision (rule #7).

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS warehouses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    branch TEXT,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS units (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,      -- e.g. kg, g, litre, ml, pcs
    base_unit TEXT,                 -- e.g. g is base for kg
    conversion_factor TEXT NOT NULL DEFAULT '1'  -- to base unit
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,             -- e.g. Garam Masala (rule #25)
    category TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS skus (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL REFERENCES products(id),
    sku_code TEXT UNIQUE NOT NULL,  -- e.g. GRM-100G
    pack_size TEXT,
    unit_id INTEGER REFERENCES units(id),
    barcode TEXT,
    selling_price TEXT NOT NULL DEFAULT '0',
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS raw_materials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    unit_id INTEGER REFERENCES units(id),
    reorder_level TEXT NOT NULL DEFAULT '0',
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    contact TEXT,
    gstin TEXT,
    is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    customer_type TEXT NOT NULL DEFAULT 'Direct Customer',
        -- Retailer / Distributor / Wholesaler / Direct Customer /
        -- Restaurant-Hotel / Other   (rule #26)
    contact TEXT,
    gstin TEXT,
    is_active INTEGER NOT NULL DEFAULT 1
);

-- Batch/Lot tracking for both raw materials and finished SKUs (rule #4)
CREATE TABLE IF NOT EXISTS batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_number TEXT UNIQUE NOT NULL,   -- e.g. GRM-20260912-001
    item_type TEXT NOT NULL,             -- 'raw_material' or 'sku'
    item_id INTEGER NOT NULL,
    mfg_date TEXT,
    expiry_date TEXT,
    recipe_version_id INTEGER,
    qc_status TEXT NOT NULL DEFAULT 'Pending',   -- Pending/Passed/Failed
    qc_result TEXT,
    approved_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Every stock change is a ledger row — never overwrite a balance (rule #3)
CREATE TABLE IF NOT EXISTS stock_movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_type TEXT NOT NULL,             -- 'raw_material' or 'sku'
    item_id INTEGER NOT NULL,
    batch_id INTEGER REFERENCES batches(id),
    warehouse_id INTEGER REFERENCES warehouses(id),
    movement_type TEXT NOT NULL,         -- Opening/Purchase/Production/
                                          -- Wastage/Sales/Adjustment
    quantity TEXT NOT NULL,              -- signed Decimal string
    reference TEXT,                      -- e.g. invoice/PO number
    created_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_stock_item
    ON stock_movements(item_type, item_id);

-- Mandatory audit log (rule #12)
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user TEXT NOT NULL,
    action TEXT NOT NULL,
    entity TEXT NOT NULL,
    entity_id TEXT,
    before_json TEXT,
    after_json TEXT,
    reason TEXT,
    approved_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Seed a default Owner user and common units so the app is usable
-- immediately. Password is 'admin123' (sha256-hashed) — MUST be
-- changed on first login.
INSERT OR IGNORE INTO users (username, password_hash, role)
VALUES ('owner', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'Owner');

INSERT OR IGNORE INTO units (name, base_unit, conversion_factor) VALUES
    ('kg', 'g', '1000'),
    ('g', 'g', '1'),
    ('litre', 'ml', '1000'),
    ('ml', 'ml', '1'),
    ('pcs', 'pcs', '1');

INSERT OR IGNORE INTO warehouses (name, branch) VALUES ('Main Warehouse', 'Dhule');
