-- v002: Phase 2 — Purchase (PO -> GRN -> stock-in link)

CREATE TABLE IF NOT EXISTS purchase_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    po_number TEXT UNIQUE NOT NULL,
    supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
    status TEXT NOT NULL DEFAULT 'Draft',  -- Draft/Approved/Received/Cancelled
    order_date TEXT NOT NULL DEFAULT (date('now')),
    created_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS purchase_order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    po_id INTEGER NOT NULL REFERENCES purchase_orders(id),
    raw_material_id INTEGER NOT NULL REFERENCES raw_materials(id),
    quantity TEXT NOT NULL,       -- ordered qty (Decimal string)
    rate TEXT NOT NULL DEFAULT '0',   -- purchase rate per unit
    received_qty TEXT NOT NULL DEFAULT '0'
);

CREATE TABLE IF NOT EXISTS goods_receipts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    grn_number TEXT UNIQUE NOT NULL,
    po_id INTEGER NOT NULL REFERENCES purchase_orders(id),
    received_date TEXT NOT NULL DEFAULT (date('now')),
    received_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS goods_receipt_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    grn_id INTEGER NOT NULL REFERENCES goods_receipts(id),
    po_item_id INTEGER NOT NULL REFERENCES purchase_order_items(id),
    batch_id INTEGER REFERENCES batches(id),
    quantity TEXT NOT NULL
);

-- Supplier payable ledger (rule #8 transaction chain: Purchase -> Payable -> Payment)
CREATE TABLE IF NOT EXISTS supplier_payables (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
    po_id INTEGER REFERENCES purchase_orders(id),
    amount TEXT NOT NULL,          -- positive = payable increases, negative = payment made
    entry_type TEXT NOT NULL,      -- 'Invoice' or 'Payment'
    reference TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
