-- v008: configurable GST presentation and reporting metadata.
ALTER TABLE sales_invoices ADD COLUMN tax_type TEXT NOT NULL DEFAULT 'GST';
ALTER TABLE sales_invoices ADD COLUMN place_of_supply TEXT;
ALTER TABLE sales_invoice_items ADD COLUMN cgst_amount TEXT NOT NULL DEFAULT '0';
ALTER TABLE sales_invoice_items ADD COLUMN sgst_amount TEXT NOT NULL DEFAULT '0';
ALTER TABLE sales_invoice_items ADD COLUMN igst_amount TEXT NOT NULL DEFAULT '0';
ALTER TABLE sales_invoice_items ADD COLUMN tax_type TEXT NOT NULL DEFAULT 'GST';
ALTER TABLE transactions ADD COLUMN tax_amount TEXT NOT NULL DEFAULT '0';
CREATE INDEX IF NOT EXISTS idx_sales_customer_date ON sales_invoices(customer_id,invoice_date);
