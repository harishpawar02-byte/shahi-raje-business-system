-- v010: Sales Order -> Stock Check -> Picking -> Invoice + Stock Issue workflow.
-- Existing invoices remain valid; the new workflow is additive.

CREATE TABLE IF NOT EXISTS sales_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_number TEXT UNIQUE NOT NULL,
    customer_id INTEGER NOT NULL REFERENCES customers(id),
    warehouse_id INTEGER REFERENCES warehouses(id),
    status TEXT NOT NULL DEFAULT 'Draft',
    tax_type TEXT NOT NULL DEFAULT 'GST',
    place_of_supply TEXT,
    notes TEXT,
    created_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    confirmed_at TEXT,
    picked_at TEXT,
    invoice_id INTEGER REFERENCES sales_invoices(id)
);

CREATE TABLE IF NOT EXISTS sales_order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sales_order_id INTEGER NOT NULL REFERENCES sales_orders(id),
    sku_id INTEGER NOT NULL REFERENCES skus(id),
    quantity TEXT NOT NULL,
    rate TEXT NOT NULL,
    tax_rate TEXT NOT NULL DEFAULT '0',
    picked_quantity TEXT NOT NULL DEFAULT '0'
);

CREATE TABLE IF NOT EXISTS sales_order_picks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sales_order_id INTEGER NOT NULL REFERENCES sales_orders(id),
    sales_order_item_id INTEGER NOT NULL REFERENCES sales_order_items(id),
    quantity TEXT NOT NULL,
    picked_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_sales_orders_customer ON sales_orders(customer_id, created_at);
CREATE INDEX IF NOT EXISTS idx_sales_orders_status ON sales_orders(status, created_at);
CREATE INDEX IF NOT EXISTS idx_sales_order_items_order ON sales_order_items(sales_order_id);
CREATE INDEX IF NOT EXISTS idx_sales_order_picks_order ON sales_order_picks(sales_order_id, created_at);

ALTER TABLE sales_invoices ADD COLUMN sales_order_id INTEGER REFERENCES sales_orders(id);
CREATE INDEX IF NOT EXISTS idx_sales_invoice_order ON sales_invoices(sales_order_id);
