-- v009: operational completion, audit-safe corrections, settings, reporting and immutable recipe usage.
CREATE TABLE IF NOT EXISTS recipe_change_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recipe_id INTEGER NOT NULL REFERENCES recipes(id),
    action TEXT NOT NULL,
    version INTEGER NOT NULL,
    changed_by TEXT NOT NULL,
    reason TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS payment_allocations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ledger_type TEXT NOT NULL CHECK(ledger_type IN ('receivable','payable')),
    ledger_id INTEGER NOT NULL,
    amount TEXT NOT NULL,
    payment_reference TEXT,
    created_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS report_exports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_name TEXT NOT NULL,
    file_name TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS app_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'INFO',
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_recipe_change_recipe ON recipe_change_log(recipe_id, created_at);
CREATE INDEX IF NOT EXISTS idx_app_events_created ON app_events(created_at);
CREATE INDEX IF NOT EXISTS idx_pay_alloc_ledger ON payment_allocations(ledger_type, ledger_id);

INSERT OR IGNORE INTO company_settings(setting_key, setting_value) VALUES
 ('company_address',''),('company_phone',''),('company_email',''),('company_gstin',''),
 ('invoice_prefix','INV'),('purchase_prefix','PO'),('grn_prefix','GRN'),
 ('inventory_negative_override_requires_approval','1'),('default_tax_rate','5'),
 ('date_format','DD-MM-YYYY'),('backup_frequency','daily');
