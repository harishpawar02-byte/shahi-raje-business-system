-- v007: data quality, indexes and operational defaults.
CREATE UNIQUE INDEX IF NOT EXISTS ux_sku_barcode ON skus(barcode) WHERE barcode IS NOT NULL AND barcode<>'';
CREATE INDEX IF NOT EXISTS idx_recipe_product_active ON recipes(product_id,is_active);
CREATE INDEX IF NOT EXISTS idx_batch_expiry ON batches(item_type,item_id,expiry_date);
CREATE INDEX IF NOT EXISTS idx_task_status_due ON task_workflows(status,due_date);
CREATE INDEX IF NOT EXISTS idx_transaction_type_date ON transactions(txn_type,txn_date);
CREATE INDEX IF NOT EXISTS idx_receivable_customer ON customer_receivables(customer_id,created_at);
CREATE INDEX IF NOT EXISTS idx_payable_supplier ON supplier_payables(supplier_id,created_at);
INSERT OR IGNORE INTO unit_conversions(from_unit_id,to_unit_id,factor) SELECT u1.id,u2.id,u1.conversion_factor FROM units u1 JOIN units u2 ON u1.base_unit=u2.name WHERE u1.id<>u2.id;
