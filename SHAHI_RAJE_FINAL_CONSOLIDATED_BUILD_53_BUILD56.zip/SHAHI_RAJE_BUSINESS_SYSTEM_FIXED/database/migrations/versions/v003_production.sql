-- v003: Phase 3 — Production, Recipe (BOM) versioning, QC

CREATE TABLE IF NOT EXISTS recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL REFERENCES products(id),
    version INTEGER NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(product_id, version)
);

CREATE TABLE IF NOT EXISTS recipe_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recipe_id INTEGER NOT NULL REFERENCES recipes(id),
    raw_material_id INTEGER NOT NULL REFERENCES raw_materials(id),
    quantity_per_batch TEXT NOT NULL   -- Decimal string, for 1 "batch unit"
);

CREATE TABLE IF NOT EXISTS production_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    production_number TEXT UNIQUE NOT NULL,
    product_id INTEGER NOT NULL REFERENCES products(id),
    recipe_id INTEGER NOT NULL REFERENCES recipes(id),
    planned_qty TEXT NOT NULL,
    produced_qty TEXT NOT NULL DEFAULT '0',
    wastage_qty TEXT NOT NULL DEFAULT '0',
    output_batch_id INTEGER REFERENCES batches(id),
    status TEXT NOT NULL DEFAULT 'Planned',  -- Planned/InProgress/Completed/Cancelled
    estimated_cost TEXT,
    actual_cost TEXT,
    created_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS production_consumption (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    production_order_id INTEGER NOT NULL REFERENCES production_orders(id),
    raw_material_id INTEGER NOT NULL REFERENCES raw_materials(id),
    batch_id INTEGER REFERENCES batches(id),
    quantity TEXT NOT NULL,     -- consumed qty
    rate TEXT NOT NULL DEFAULT '0'
);
