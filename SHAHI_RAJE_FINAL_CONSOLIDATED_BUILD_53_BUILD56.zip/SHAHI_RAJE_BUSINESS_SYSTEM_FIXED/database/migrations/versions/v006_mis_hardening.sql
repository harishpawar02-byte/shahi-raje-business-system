-- v006: MIS hardening, configurable masters, safe corrections, QC and settings.
ALTER TABLE users ADD COLUMN password_scheme TEXT NOT NULL DEFAULT 'sha256';
ALTER TABLE users ADD COLUMN password_change_required INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN last_login TEXT;
ALTER TABLE warehouses ADD COLUMN code TEXT;
ALTER TABLE units ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1;
ALTER TABLE skus ADD COLUMN mrp TEXT NOT NULL DEFAULT '0';
ALTER TABLE skus ADD COLUMN standard_cost TEXT NOT NULL DEFAULT '0';
ALTER TABLE skus ADD COLUMN packaging_material_id INTEGER REFERENCES packaging_materials(id);
ALTER TABLE skus ADD COLUMN tax_rate TEXT NOT NULL DEFAULT '0';
ALTER TABLE skus ADD COLUMN reorder_level TEXT NOT NULL DEFAULT '0';
ALTER TABLE raw_materials ADD COLUMN code TEXT;
ALTER TABLE raw_materials ADD COLUMN category TEXT;
ALTER TABLE raw_materials ADD COLUMN purchase_unit_id INTEGER REFERENCES units(id);
ALTER TABLE raw_materials ADD COLUMN conversion_factor TEXT NOT NULL DEFAULT '1';
ALTER TABLE raw_materials ADD COLUMN min_level TEXT NOT NULL DEFAULT '0';
ALTER TABLE raw_materials ADD COLUMN max_level TEXT NOT NULL DEFAULT '0';
ALTER TABLE raw_materials ADD COLUMN preferred_supplier_id INTEGER REFERENCES suppliers(id);
ALTER TABLE suppliers ADD COLUMN code TEXT;
ALTER TABLE suppliers ADD COLUMN email TEXT;
ALTER TABLE suppliers ADD COLUMN address TEXT;
ALTER TABLE suppliers ADD COLUMN payment_terms TEXT;
ALTER TABLE customers ADD COLUMN code TEXT;
ALTER TABLE customers ADD COLUMN email TEXT;
ALTER TABLE customers ADD COLUMN address TEXT;
ALTER TABLE customers ADD COLUMN payment_terms TEXT;
ALTER TABLE customers ADD COLUMN credit_limit TEXT NOT NULL DEFAULT '0';
ALTER TABLE stock_movements ADD COLUMN correction_of_id INTEGER REFERENCES stock_movements(id);
ALTER TABLE stock_movements ADD COLUMN correction_reason TEXT;
ALTER TABLE stock_movements ADD COLUMN approved_by TEXT;
ALTER TABLE stock_movements ADD COLUMN source TEXT NOT NULL DEFAULT 'manual';
ALTER TABLE batches ADD COLUMN qc_date TEXT;
ALTER TABLE batches ADD COLUMN qc_inspector TEXT;
ALTER TABLE batches ADD COLUMN saleable INTEGER NOT NULL DEFAULT 0;
ALTER TABLE production_orders ADD COLUMN output_sku_id INTEGER REFERENCES skus(id);
ALTER TABLE production_orders ADD COLUMN warehouse_id INTEGER REFERENCES warehouses(id);
ALTER TABLE production_orders ADD COLUMN qc_status TEXT NOT NULL DEFAULT 'Pending';
ALTER TABLE production_orders ADD COLUMN approved_by TEXT;
ALTER TABLE production_consumption ADD COLUMN warehouse_id INTEGER REFERENCES warehouses(id);
ALTER TABLE sales_invoices ADD COLUMN warehouse_id INTEGER REFERENCES warehouses(id);
ALTER TABLE sales_invoices ADD COLUMN notes TEXT;
ALTER TABLE transactions ADD COLUMN source_type TEXT;
ALTER TABLE transactions ADD COLUMN source_id TEXT;
ALTER TABLE transactions ADD COLUMN payment_mode TEXT;
ALTER TABLE notifications ADD COLUMN priority TEXT NOT NULL DEFAULT 'Normal';
ALTER TABLE notifications ADD COLUMN user_id INTEGER REFERENCES users(id);
ALTER TABLE audit_log ADD COLUMN source TEXT NOT NULL DEFAULT 'application';

CREATE TABLE IF NOT EXISTS packaging_materials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    category TEXT,
    unit_id INTEGER REFERENCES units(id),
    reorder_level TEXT NOT NULL DEFAULT '0',
    standard_cost TEXT NOT NULL DEFAULT '0',
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS unit_conversions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_unit_id INTEGER NOT NULL REFERENCES units(id),
    to_unit_id INTEGER NOT NULL REFERENCES units(id),
    factor TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    UNIQUE(from_unit_id, to_unit_id)
);

CREATE TABLE IF NOT EXISTS company_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT,
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_by TEXT
);

CREATE TABLE IF NOT EXISTS qc_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id INTEGER NOT NULL REFERENCES batches(id),
    inspection_date TEXT NOT NULL DEFAULT (date('now')),
    inspector TEXT NOT NULL,
    parameters_json TEXT NOT NULL DEFAULT '{}',
    result TEXT NOT NULL,
    remarks TEXT,
    approved_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS task_workflows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'Pending',
    priority TEXT NOT NULL DEFAULT 'Normal',
    due_date TEXT,
    assigned_to TEXT,
    source TEXT,
    created_by TEXT,
    completed_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS research_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    source_url TEXT,
    source_date TEXT,
    confidence TEXT NOT NULL DEFAULT 'Medium',
    summary TEXT,
    created_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS forecasts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    metric TEXT NOT NULL,
    period TEXT NOT NULL,
    forecast_value TEXT NOT NULL,
    confidence TEXT NOT NULL,
    basis TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    created_by TEXT
);

CREATE INDEX IF NOT EXISTS idx_stock_batch ON stock_movements(batch_id);
CREATE INDEX IF NOT EXISTS idx_stock_warehouse ON stock_movements(warehouse_id);
CREATE INDEX IF NOT EXISTS idx_stock_correction ON stock_movements(correction_of_id);
CREATE INDEX IF NOT EXISTS idx_po_status ON purchase_orders(status);
CREATE INDEX IF NOT EXISTS idx_production_status ON production_orders(status);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales_invoices(invoice_date);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(is_read, created_at);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity, entity_id);
CREATE UNIQUE INDEX IF NOT EXISTS ux_rm_code ON raw_materials(code) WHERE code IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_supplier_code ON suppliers(code) WHERE code IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_customer_code ON customers(code) WHERE code IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS ux_warehouse_code ON warehouses(code) WHERE code IS NOT NULL;

UPDATE users SET password_hash='pbkdf2_sha256$310000$00112233445566778899aabbccddeeff$979762d47e079ecc3c52f80e283a4003f510a0616351d9d7e14e7491644e7e92', password_scheme='pbkdf2_sha256', password_change_required=1 WHERE username='owner' AND password_scheme='sha256';
UPDATE skus SET mrp=selling_price WHERE mrp='0' AND selling_price<>'0';
UPDATE skus SET tax_rate='5' WHERE tax_rate='0';
UPDATE raw_materials SET code='RM-' || printf('%04d', id) WHERE code IS NULL;
UPDATE suppliers SET code='SUP-' || printf('%04d', id) WHERE code IS NULL;
UPDATE customers SET code='CUS-' || printf('%04d', id) WHERE code IS NULL;
UPDATE warehouses SET code='WH-' || printf('%03d', id) WHERE code IS NULL;
INSERT OR IGNORE INTO company_settings(setting_key, setting_value) VALUES
 ('company_name','SHAHI RAJE'),
 ('currency','INR'),
 ('timezone','Asia/Kolkata'),
 ('language','Marathi'),
 ('negative_stock_policy','blocked'),
 ('default_warehouse_id','1'),
 ('tax_mode','configurable'),
 ('backup_retention_days','30');
