-- v005: Phase 6 (HR/Admin), Phase 10 (Notifications),
--       Phase 8/9 scaffold (AI Agent recommendations + approval workflow)

CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    role_title TEXT,
    linked_user_id INTEGER REFERENCES users(id),
    contact TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    notif_type TEXT NOT NULL,   -- LowStock/PaymentDue/ProductionPending/QCPending/ApprovalPending
    message TEXT NOT NULL,
    entity TEXT,
    entity_id TEXT,
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Rule #10/#11: every AI Agent suggestion is logged here and needs
-- explicit Owner/Admin approval before any action_fn actually runs.
-- The AI layer NEVER touches the database directly (rule #11).
CREATE TABLE IF NOT EXISTS agent_recommendations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_name TEXT NOT NULL,     -- e.g. 'InventoryAgent'
    recommendation TEXT NOT NULL, -- human-readable text
    based_on TEXT,                -- what data/reasoning it used
    status TEXT NOT NULL DEFAULT 'Pending',  -- Pending/Approved/Rejected/Executed
    approved_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    decided_at TEXT
);
