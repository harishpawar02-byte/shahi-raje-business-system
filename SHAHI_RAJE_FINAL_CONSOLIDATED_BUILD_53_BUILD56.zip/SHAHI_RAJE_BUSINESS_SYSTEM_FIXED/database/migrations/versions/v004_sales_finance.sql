-- v004: Phase 4 (Sales/Invoice/Payments) + Phase 5 (Finance/Costing)

CREATE TABLE IF NOT EXISTS sales_invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_number TEXT UNIQUE NOT NULL,
    customer_id INTEGER NOT NULL REFERENCES customers(id),
    invoice_date TEXT NOT NULL DEFAULT (date('now')),
    status TEXT NOT NULL DEFAULT 'Issued',  -- Issued/Cancelled
    subtotal TEXT NOT NULL DEFAULT '0',
    tax_amount TEXT NOT NULL DEFAULT '0',
    total TEXT NOT NULL DEFAULT '0',
    created_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sales_invoice_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL REFERENCES sales_invoices(id),
    sku_id INTEGER NOT NULL REFERENCES skus(id),
    batch_id INTEGER REFERENCES batches(id),
    quantity TEXT NOT NULL,
    rate TEXT NOT NULL,
    tax_rate TEXT NOT NULL DEFAULT '0',   -- e.g. GST % (rule #9)
    line_total TEXT NOT NULL
);

-- Customer receivable ledger (rule #8: Sale -> Invoice -> Receivable -> Payment)
CREATE TABLE IF NOT EXISTS customer_receivables (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL REFERENCES customers(id),
    invoice_id INTEGER REFERENCES sales_invoices(id),
    amount TEXT NOT NULL,        -- positive = invoice raises receivable
    entry_type TEXT NOT NULL,    -- 'Invoice' or 'Payment'
    reference TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Phase 5 — general transaction ledger + simple expenses (rule #8)
CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    txn_date TEXT NOT NULL DEFAULT (date('now')),
    txn_type TEXT NOT NULL,     -- Sale/Purchase/Expense/Payment-In/Payment-Out
    category TEXT,
    amount TEXT NOT NULL,       -- always positive; sign meaning via txn_type
    reference TEXT,
    notes TEXT,
    created_by TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
