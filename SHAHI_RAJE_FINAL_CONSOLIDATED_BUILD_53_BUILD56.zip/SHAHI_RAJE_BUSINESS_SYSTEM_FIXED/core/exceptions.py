class MISError(Exception):
    """Base exception for business-rule violations."""

class InsufficientStockError(MISError):
    pass

class PermissionDeniedError(MISError):
    pass

class ValidationError(MISError):
    pass

class DuplicateRecordError(MISError):
    pass
