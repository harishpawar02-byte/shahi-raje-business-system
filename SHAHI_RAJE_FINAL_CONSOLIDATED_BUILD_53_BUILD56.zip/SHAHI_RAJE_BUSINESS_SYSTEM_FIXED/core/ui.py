import streamlit as st
from core.i18n import t

def require_login():
    if not st.session_state.get('user'):
        st.warning('Please login first / कृपया Login करा.');st.stop()
    return st.session_state.user

def page_header(title): st.title(title)

def error(e): st.error('Operation failed. Please try again.')

def display_table(rows, *, use_container_width=True, hide_index=True, key=None):
    """Render rows with a human-facing 1..N serial number without changing DB IDs."""
    data=[dict(r) for r in rows]
    numbered=[{'Sr. No.': i, **row} for i,row in enumerate(data, 1)]
    return st.dataframe(numbered, use_container_width=use_container_width, hide_index=hide_index, key=key)
