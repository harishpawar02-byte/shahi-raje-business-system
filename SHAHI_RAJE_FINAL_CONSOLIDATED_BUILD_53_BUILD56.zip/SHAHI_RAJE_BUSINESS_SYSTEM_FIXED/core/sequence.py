def sequential_rows(rows):
    """Return display rows in stable database sequence with a 1..N serial number."""
    data=[dict(r) for r in rows]
    data.sort(key=lambda r: (r.get("id") is None, r.get("id", 0)))
    return [{"Sr. No.": i, **row} for i, row in enumerate(data, 1)]
