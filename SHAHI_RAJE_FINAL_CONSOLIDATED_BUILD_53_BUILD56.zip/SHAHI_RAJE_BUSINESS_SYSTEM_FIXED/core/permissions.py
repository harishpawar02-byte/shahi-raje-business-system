from core.exceptions import PermissionDeniedError

ROLES = ["Owner", "Admin", "Finance", "Production", "Inventory", "Sales", "Marketing", "HR"]
ACTIONS = ["View", "Create", "Edit", "Approve", "Cancel", "Delete", "Export"]
ROLE_PERMISSIONS = {
    "Owner": set(ACTIONS), "Admin": set(ACTIONS),
    "Finance": {"View", "Create", "Edit", "Export"},
    "Production": {"View", "Create", "Edit"},
    "Inventory": {"View", "Create", "Edit", "Export"},
    "Sales": {"View", "Create", "Edit", "Export"},
    "Marketing": {"View", "Create", "Edit", "Export"},
    "HR": {"View", "Create", "Edit"},
}

def has_permission(role, action):
    return action in ROLE_PERMISSIONS.get(role, set())

def require_permission(role, action):
    if not has_permission(role, action):
        raise PermissionDeniedError(f"Permission required: {action}")
