import json
from datetime import datetime, timezone

def write_audit(conn, *, user, action, entity, entity_id=None, before=None, after=None,
                reason="", approved_by="", source="application", commit=True):
    conn.execute(
        """INSERT INTO audit_log
        (user, action, entity, entity_id, before_json, after_json, reason, approved_by, created_at, source)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (user or "system", action, entity, str(entity_id) if entity_id is not None else None,
         json.dumps(before, ensure_ascii=False, default=str) if before is not None else None,
         json.dumps(after, ensure_ascii=False, default=str) if after is not None else None,
         reason or "", approved_by or "", datetime.now(timezone.utc).isoformat(), source or "application"),
    )
    if commit:
        conn.commit()
