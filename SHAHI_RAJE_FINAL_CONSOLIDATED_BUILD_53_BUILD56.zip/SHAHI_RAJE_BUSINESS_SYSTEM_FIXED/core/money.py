"""Exact Decimal helpers for money and quantities."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from config import MONEY_DECIMALS, QTY_DECIMALS


def _decimal(value, places):
    try:
        d = Decimal(str(value).strip())
    except (InvalidOperation, AttributeError):
        raise ValueError(f"Invalid numeric value: {value!r}")
    if not d.is_finite():
        raise ValueError("Numeric value must be finite")
    quantum = Decimal("1." + "0" * places)
    return d.quantize(quantum, rounding=ROUND_HALF_UP)


def to_money(value):
    return _decimal(value, MONEY_DECIMALS)


def to_qty(value):
    return _decimal(value, QTY_DECIMALS)
