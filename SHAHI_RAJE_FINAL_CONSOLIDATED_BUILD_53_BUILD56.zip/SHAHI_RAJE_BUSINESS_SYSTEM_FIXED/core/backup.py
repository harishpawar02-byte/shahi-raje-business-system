"""Safe SQLite backup/restore utilities with integrity validation."""
import shutil, sqlite3
from datetime import datetime
from pathlib import Path
from config import DB_PATH, BACKUP_DIR

def validate_db(path):
    c=sqlite3.connect(path)
    try:
        integrity=c.execute('PRAGMA integrity_check').fetchone()[0]
        fk=c.execute('PRAGMA foreign_key_check').fetchall()
        return integrity=='ok' and not fk, integrity, len(fk)
    finally:c.close()

def backup_now(label='manual'):
    src=Path(DB_PATH);BACKUP_DIR.mkdir(parents=True,exist_ok=True)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S');dest=Path(BACKUP_DIR)/f'mis_{label}_{stamp}.db';shutil.copy2(src,dest)
    ok,integrity,fk=validate_db(dest)
    if not ok:dest.unlink(missing_ok=True);raise RuntimeError(f'Backup validation failed: {integrity}; foreign keys: {fk}')
    return dest

def list_backups():return sorted(Path(BACKUP_DIR).glob('*.db'),reverse=True)

def restore(backup_path):
    backup=Path(backup_path);ok,integrity,fk=validate_db(backup)
    if not ok:raise RuntimeError('Selected backup failed integrity validation')
    safety=backup_now('before_restore');shutil.copy2(backup,DB_PATH);ok2,integrity2,fk2=validate_db(DB_PATH)
    if not ok2:
        shutil.copy2(safety,DB_PATH);raise RuntimeError('Restore validation failed; production DB reverted to safety backup')
    return safety
