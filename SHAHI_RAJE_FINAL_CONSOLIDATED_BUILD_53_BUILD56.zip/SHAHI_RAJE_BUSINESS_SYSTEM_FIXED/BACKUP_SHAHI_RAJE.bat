@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe py -m venv .venv
call .venv\Scripts\activate.bat
python -c "from core.backup import backup_now; print(backup_now('manual'))"
pause
