import streamlit as st
from datetime import date
from database.connection import db_session
from services.mis_service import MISService
from services.production_service import ProductionService
from services.inventory_service import InventoryService
from core.ui import require_login, display_table
from core.permissions import has_permission

user=require_login();st.title('🏭 Production — Recipe → Batch → QC')
with db_session() as c:
 svc=MISService(c,user);prod=ProductionService(c,user);inv=InventoryService(c,user);products=svc.products();rms=svc.raw_materials();skus=svc.skus();warehouses=svc.warehouses();pmap={f"{p['id']} — {p['name']}":p['id'] for p in products};rmap={f"{r['id']} — {r['name']}":r['id'] for r in rms};smap={f"{s['id']} — {s['sku_code']} / {s['product_name']}":s['id'] for s in skus};wmap={f"{w['id']} — {w['name']}":w['id'] for w in warehouses}
 t1,t2,t3=st.tabs(['Recipe Versions','Production Order','Complete + QC'])
 with t1:
  if pmap and rmap and has_permission(user['role'],'Create'):
   p=st.selectbox('Product',list(pmap));n=st.number_input('Ingredients',1,50,1);items=[]
   for i in range(n):a,b=st.columns(2);rm=a.selectbox(f'RM {i+1}',list(rmap),key=f'prm{i}');q=b.number_input(f'Qty per batch unit {i+1}',min_value=0.0,key=f'pq{i}');items.append({'raw_material_id':rmap[rm],'quantity_per_batch':q})
   if st.button('Create New Recipe Version'):
    try:rid,v=prod.create_recipe_version(pmap[p],items);st.success(f'Recipe v{v} created');st.rerun()
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  if pmap:
   p=st.selectbox('View active recipe',list(pmap),key='viewp');r=prod.active_recipe(pmap[p]);
   if r:display_table([dict(x) for x in prod.recipe_items(r['id'])])
 with t2:
  if pmap and has_permission(user['role'],'Create'):
   p=st.selectbox('Product',list(pmap),key='op');r=prod.active_recipe(pmap[p]);sku_options=[f"{s['id']} — {s['sku_code']} / {s['product_name']}" for s in svc.production_skus(pmap[p])]
   if r and sku_options:
    sku=st.selectbox('Output SKU',sku_options);warehouse=st.selectbox('Warehouse',list(wmap),key='plan_warehouse');qty=st.number_input('Planned batch units',min_value=0.001);rates={x['id']:0 for x in rms}
    if st.button('Plan Production'):
     try:oid,num,est=prod.plan_production(pmap[p],r['id'],qty,rates,smap[sku],warehouse_id=wmap[warehouse]);st.success(f'{num} planned');st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  pending=svc.pending_production_orders();
  if pending:display_table([dict(x) for x in pending])
 with t3:
  pending=svc.pending_production_orders()
  if pending:
   pm={f"{p['id']} — {p['production_number']} — {p['product_name']}":p for p in pending};sel=st.selectbox('Production Order',list(pm));po=pm[sel];items=prod.recipe_items(po['recipe_id']);cons=[]
   for it in items:
    rm_name=svc.raw_material_name(it['raw_material_id']);bal=inv.balance('raw_material',it['raw_material_id']);a,b=st.columns(2);a.write(f"{rm_name} • stock {bal}");q=b.number_input(f'Consume {it["id"]}',min_value=0.0,key=f'consume{it["id"]}');
    if q>0:cons.append({'raw_material_id':it['raw_material_id'],'quantity':q,'rate':0})
   sku_opts=[f"{s['id']} — {s['sku_code']} / {s['product_name']}" for s in svc.production_skus(po['product_id'])];sku=st.selectbox('Output SKU',sku_opts);warehouse_options=list(wmap) or ['All / Default'];default_wh=(wmap[warehouse_options[0]] if wmap else None);warehouse=st.selectbox('Warehouse',warehouse_options,key='complete_warehouse');batch=st.text_input('Output Batch');out=st.number_input('Produced Qty',min_value=0.001);w=st.number_input('Wastage Qty',min_value=0.0);qc=st.selectbox('QC',['Passed','Failed','Pending']);remarks=st.text_input('QC Remarks')
   if st.button('Complete Production') and batch and cons:
    try:bid,actual,unit=prod.consume_and_produce(production_order_id=po['id'],product_id=po['product_id'],output_sku_id=smap[sku],consumptions=cons,output_batch_number=batch,output_qty=out,wastage_qty=w,qc_status=qc,qc_result=remarks,warehouse_id=(wmap[warehouse] if wmap else None));st.success(f'Completed {batch}; actual cost ₹{actual}; unit cost ₹{unit}');st.rerun()
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
