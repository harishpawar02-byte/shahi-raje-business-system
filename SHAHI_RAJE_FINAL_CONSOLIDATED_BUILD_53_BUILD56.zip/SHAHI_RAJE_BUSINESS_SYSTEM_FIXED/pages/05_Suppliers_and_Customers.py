import streamlit as st
from database.connection import db_session
from services.mis_service import MISService
from core.ui import require_login, display_table
from core.permissions import has_permission

user=require_login();st.title('🤝 Suppliers & Customers')
with db_session() as c:
 svc=MISService(c,user);sups=svc.suppliers();custs=svc.customers();t1,t2=st.tabs(['Suppliers','Customers'])
 with t1:
  if has_permission(user['role'],'Create'):
   with st.form('sup'):
    code=st.text_input('Code',value=f'SUP-{len(sups)+1:04d}');name=st.text_input('Name');contact=st.text_input('Phone');email=st.text_input('Email');addr=st.text_area('Address');gst=st.text_input('GSTIN');terms=st.text_input('Payment Terms')
    if st.form_submit_button('Create Supplier') and name:
     try:svc.create_supplier(code,name,contact,email,addr,gst,terms);st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  display_table([{'Sr. No.': i, **dict(x)} for i, x in enumerate(sups, 1)])
  if sups and has_permission(user['role'],'Edit'):
   sel=st.selectbox('Deactivate Supplier',[f"{x['id']} — {x['name']}" for x in sups],key='dsup')
   if st.button('Deactivate Supplier',key='deactsup'): svc.deactivate('suppliers',int(sel.split(' — ')[0])); st.rerun()
  if sups and has_permission(user['role'],'Edit'):
   sel=st.selectbox('Edit Supplier',[f"{x['id']} — {x['name']}" for x in sups]);r=next(x for x in sups if x['id']==int(sel.split(' — ')[0]))
   with st.form('esup'):
    code=st.text_input('Code',r['code']);name=st.text_input('Name',r['name']);contact=st.text_input('Phone',r['contact'] or '');email=st.text_input('Email',r['email'] or '');addr=st.text_area('Address',r['address'] or '');gst=st.text_input('GSTIN',r['gstin'] or '');terms=st.text_input('Payment Terms',r['payment_terms'] or '')
    if st.form_submit_button('Save Supplier'):
     try:svc.update_supplier(r['id'],code,name,contact,email,addr,gst,terms);st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
 with t2:
  types=['Retailer','Distributor','Wholesaler','Direct Customer','Restaurant/Hotel','Other']
  if has_permission(user['role'],'Create'):
   with st.form('cust'):
    code=st.text_input('Code',value=f'CUS-{len(custs)+1:04d}');name=st.text_input('Name');typ=st.selectbox('Type',types);contact=st.text_input('Phone');email=st.text_input('Email');addr=st.text_area('Address');gst=st.text_input('GSTIN');terms=st.text_input('Payment Terms');credit=st.number_input('Credit Limit ₹',min_value=0.0)
    if st.form_submit_button('Create Customer') and name:
     try:svc.create_customer(code,name,typ,contact,email,addr,gst,terms,credit);st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  display_table([{'Sr. No.': i, **dict(x)} for i, x in enumerate(custs, 1)])
  if custs and has_permission(user['role'],'Edit'):
   sel=st.selectbox('Deactivate Customer',[f"{x['id']} — {x['name']}" for x in custs],key='dcust')
   if st.button('Deactivate Customer',key='deactcust'): svc.deactivate('customers',int(sel.split(' — ')[0])); st.rerun()
  if custs and has_permission(user['role'],'Edit'):
   sel=st.selectbox('Edit Customer',[f"{x['id']} — {x['name']}" for x in custs]);r=next(x for x in custs if x['id']==int(sel.split(' — ')[0]))
   with st.form('ecust'):
    code=st.text_input('Code',r['code']);name=st.text_input('Name',r['name']);typ=st.selectbox('Type',types,index=types.index(r['customer_type']) if r['customer_type'] in types else 0);contact=st.text_input('Phone',r['contact'] or '');email=st.text_input('Email',r['email'] or '');addr=st.text_area('Address',r['address'] or '');gst=st.text_input('GSTIN',r['gstin'] or '');terms=st.text_input('Payment Terms',r['payment_terms'] or '');credit=st.number_input('Credit Limit ₹',min_value=0.0,value=float(r['credit_limit'] or 0))
    if st.form_submit_button('Save Customer'):
     try:svc.update_customer(r['id'],code,name,typ,contact,email,addr,gst,terms,credit);st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
