import streamlit as st
from database.connection import db_session
from services.inventory_service import InventoryService
from services.mis_service import MISService
from core.ui import require_login, display_table
from core.permissions import has_permission

user=require_login();st.title('📦 Inventory — Ledger & Safe Correction')
with db_session() as c:
 inv=InventoryService(c,user);svc=MISService(c,user);rms=svc.raw_materials();skus=svc.skus();wh=svc.warehouses();wmap={w['name']:w['id'] for w in wh}
 tab1,tab2,tab3=st.tabs(['Balances','Movement','Safe Correction'])
 with tab1:
  rows=[]
  for r in rms:rows.append({'Type':'Raw Material','Code':r['code'],'Item':r['name'],'Balance':str(inv.balance('raw_material',r['id']))})
  for s in skus:rows.append({'Type':'SKU','Code':s['sku_code'],'Item':f"{s['product_name']} / {s['pack_size']}",'Balance':str(inv.balance('sku',s['id']))})
  display_table([{'Sr. No.': i, **r} for i, r in enumerate(rows, 1)])
 with tab2:
  if has_permission(user['role'],'Create'):
   kind=st.selectbox('Item Type',['Raw Material','SKU']); items=rms if kind=='Raw Material' else skus;typ='raw_material' if kind=='Raw Material' else 'sku';imap={f"{r['id']} — {r['name']}" if kind=='Raw Material' else f"{r['id']} — {r['sku_code']} / {r['product_name']}":r['id'] for r in items}
   with st.form('move'):
    item=st.selectbox('Item',list(imap));mt=st.selectbox('Movement Type',['Opening','Adjustment','Wastage','Transfer','Other']);qty=st.number_input('Quantity',min_value=0.001);direction=st.radio('Direction',['IN','OUT']);warehouse=st.selectbox('Warehouse',[None]+list(wmap),format_func=lambda x:'All / Default' if x is None else x);ref=st.text_input('Reference');
    if st.form_submit_button('Post Movement'):
     try:
      fn=inv.stock_in if direction=='IN' else inv.stock_out;fn(item_type=typ,item_id=imap[item],quantity=qty,movement_type=mt,warehouse_id=wmap.get(warehouse) if warehouse else None,reference=ref or None);st.success('Movement posted.');st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
 with tab3:
  st.subheader('Safe Stock Transfer')
  st.caption('Moves stock between warehouses while preserving the original ledger history and batch reference.')
  if has_permission(user['role'],'Create') and wmap:
   kind=st.selectbox('Transfer Item Type',['Raw Material','SKU'],key='transfer_kind'); items=rms if kind=='Raw Material' else skus;typ='raw_material' if kind=='Raw Material' else 'sku';imap={f"{r['id']} — {r['name']}" if kind=='Raw Material' else f"{r['id']} — {r['sku_code']} / {r['product_name']}":r['id'] for r in items}
   item=st.selectbox('Item',list(imap),key='transfer_item'); source=st.selectbox('Source Warehouse',['Unassigned / Default']+list(wmap),key='transfer_source'); dest=st.selectbox('Destination Warehouse',list(wmap),key='transfer_dest')
   batch_rows=inv.repo.unassigned_fefo_batches(typ,imap[item]) if source=='Unassigned / Default' else inv.repo.fefo_batches(typ,imap[item],wmap[source]); batch_map={'Unspecified / Unbatched':None}|{f"{b['batch_number']} — {b['balance']}":b['batch_id'] for b in batch_rows}; batch_label=st.selectbox('Batch',list(batch_map),key='transfer_batch'); qty=st.number_input('Transfer Quantity',min_value=0.001,key='transfer_qty'); ref=st.text_input('Transfer Reference',key='transfer_ref')
   if st.button('Transfer Stock Safely',key='transfer_btn'):
    try:
     inv.transfer(item_type=typ,item_id=imap[item],quantity=qty,source_warehouse_id=(wmap[source] if source!='Unassigned / Default' else None),destination_warehouse_id=wmap[dest],batch_id=batch_map[batch_label],reference=ref or None);st.success('Stock transferred safely; both ledger entries were preserved.');st.rerun()
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  ledger=inv.repo.ledger(limit=100);st.caption('Original ledger rows are never edited or deleted. Correction creates a new append-only transaction.')
  if ledger:
   opts=[f"#{r['id']} | {r['item_type']}:{r['item_id']} | {r['movement_type']} | {r['quantity']} | {r['created_at']}" for r in ledger];idx=st.selectbox('Original movement',range(len(opts)),format_func=lambda i:opts[i]);orig=ledger[idx];current=float(orig['quantity']);new=st.number_input('Corrected quantity (replacement effective quantity)',value=current);reason=st.text_area('Reason (required)');override=st.checkbox('Allow negative stock override (Owner/Admin only)') if user['role'] in ('Owner','Admin') else False
   if has_permission(user['role'],'Edit') and st.button('Create Safe Correction'):
    try:svc.correct_stock(orig['id'],new,reason,allow_negative_override=override);st.success('Correction created; original ledger preserved.');st.rerun()
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
