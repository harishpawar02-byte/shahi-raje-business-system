import streamlit as st
from database.connection import db_session
from services.mis_service import MISService
from services.notification_service import NotificationService
from core.ui import require_login, display_table

user=require_login();st.title('📊 Dashboard')
with db_session() as c:
    svc=MISService(c,user);d=svc.dashboard();NotificationService(c,user).refresh()
    cols=st.columns(6)
    for col,label,key in zip(cols,['Products','SKUs','Raw Materials','Customers','Planned Production','Unread Alerts'],['products','skus','raw_materials','customers','pending_production','unread_notifications']):col.metric(label,d[key])
    st.subheader('⚠️ Low Stock')
    if d['low_stock']:display_table([{'Sr. No.': i, **dict(r)} for i, r in enumerate(d['low_stock'], 1)])
    else:st.success('No raw material is currently at/below reorder level.')
    st.subheader('🧭 Work Queue')
    tasks=svc.tasks();
    if tasks:display_table([dict(r) for r in tasks[:20]])
    else:st.info('No tasks yet.')
