import streamlit as st
from database.connection import db_session
from services.finance_service import FinanceService
from services.mis_service import MISService
from core.ui import require_login, display_table
from core.permissions import has_permission

user=require_login();st.title('💰 Finance & Costing')
with db_session() as c:
 fin=FinanceService(c,user);svc=MISService(c,user);s=fin.summary();a,b,d,e=st.columns(4);a.metric('Revenue',f"₹{s['revenue']}");b.metric('Purchases',f"₹{s['purchase']}");d.metric('Expenses',f"₹{s['expense']}");e.metric('Operational surplus',f"₹{s['profit']}")
 if has_permission(user['role'],'Create'):
  with st.form('expense'):
   cat=st.text_input('Expense Category');amt=st.number_input('Amount ₹',min_value=0.0);ref=st.text_input('Reference');mode=st.selectbox('Payment Mode',['Cash','UPI','Bank','Cheque','Other']);notes=st.text_area('Notes')
   if st.form_submit_button('Record Expense') and cat and amt>0:
    try:fin.record_expense(cat,amt,ref or None,notes or None,mode);st.rerun()
    except Exception as ex:st.error(str(ex))
 prods=svc.completed_production_orders();
 if prods:
  pm={x['production_number']:x['id'] for x in prods};sel=st.selectbox('Production Cost Variance',list(pm));v=fin.costing_variance(pm[sel]);
  if v:display_table([v])
 st.subheader('Transactions');rows=svc.transactions(100);display_table([dict(x) for x in rows])
