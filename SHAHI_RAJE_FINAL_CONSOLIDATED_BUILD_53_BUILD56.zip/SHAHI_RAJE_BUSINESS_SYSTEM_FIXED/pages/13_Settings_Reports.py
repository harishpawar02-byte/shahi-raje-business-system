import streamlit as st
import csv, io
from database.connection import db_session
from services.mis_service import MISService
from core.ui import require_login, display_table
from core.permissions import has_permission

user=require_login();st.title('📑 Reports & System Control')
with db_session() as c:
 svc=MISService(c,user)
 t1,t2,t3,t4=st.tabs(['Inventory Report','Operational Reports','Notifications / Tasks','System Health'])
 with t1:
  rows=[dict(r) for r in svc.stock_report()];display_table(rows)
  if rows:
   out=io.StringIO();w=csv.DictWriter(out,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
   if has_permission(user['role'],'Export'):st.download_button('Export Inventory CSV',out.getvalue(),'inventory_report.csv','text/csv')
 with t2:
  a,b,d=st.columns(3);a.metric('Suppliers',len(svc.suppliers()));b.metric('Customers',len(svc.customers()));d.metric('Pending QC',len(svc.pending_qc()))
  st.subheader('Purchase Orders');display_table([dict(x) for x in svc.purchase_orders()])
  st.subheader('Production Orders');display_table([dict(x) for x in svc.production_orders()])
  st.subheader('Sales Invoices');display_table([dict(x) for x in svc.sales_invoices()])
 with t3:
  st.subheader('Notifications')
  notes=svc.notifications();display_table([dict(x) for x in notes])
  unread=[x for x in notes if not x['is_read']]
  if unread and has_permission(user['role'],'Edit'):
   nsel=st.selectbox('Mark notification read',[f"{x['id']} — {x['message'][:80]}" for x in unread])
   if st.button('Mark Read'):svc.mark_notification_read(int(nsel.split(' — ')[0]));st.rerun()
  st.subheader('Tasks')
  tasks=svc.tasks();display_table([dict(x) for x in tasks])
  pending=[x for x in tasks if x['status']=='Pending']
  if pending and has_permission(user['role'],'Edit'):
   tsel=st.selectbox('Complete task',[f"{x['id']} — {x['title']}" for x in pending])
   if st.button('Complete Task'):svc.complete_task(int(tsel.split(' — ')[0]));st.rerun()
 with t4:
  st.write('Database integrity is checked before backups. Foreign keys are enforced on every connection.')
  st.json({'products':len(svc.products()),'skus':len(svc.skus()),'raw_materials':len(svc.raw_materials()),'recipes':len(svc.all_recipes()),'purchase_orders':len(svc.purchase_orders()),'production_orders':len(svc.production_orders()),'sales_invoices':len(svc.sales_invoices()),'audit_rows':len(svc.audit(5000))})
