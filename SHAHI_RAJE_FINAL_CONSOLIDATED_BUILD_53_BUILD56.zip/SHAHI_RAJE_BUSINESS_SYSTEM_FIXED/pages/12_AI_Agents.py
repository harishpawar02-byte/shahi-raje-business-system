import streamlit as st
from database.connection import db_session
from services.agent_service import AgentService
from services.mis_service import MISService
from core.ui import require_login, display_table
from core.permissions import has_permission

user=require_login();st.title('🤖 AI Agents & CEO Briefing')
with db_session() as c:
 agent=AgentService(c,user);svc=MISService(c,user)
 a,b,d=st.columns(3)
 if a.button('Run Inventory Agent'):agent.run_inventory_agent();st.rerun()
 if b.button('Run Finance Agent'):agent.run_finance_agent();st.rerun()
 if d.button('Run CEO Briefing'):agent.run_ceo_agent();st.rerun()
 st.caption('Agents are deterministic and auditable; no external API key is required. External market research can be stored with source/date/confidence.')
 recs=agent.pending_recommendations()
 if recs:
  for r in recs:
   with st.container(border=True):
    st.write(f"**{r['agent_name']}** — {r['recommendation']}");st.caption(r['based_on'])
    if has_permission(user['role'],'Approve'):
     x,y=st.columns(2)
     if x.button('Approve',key=f'a{r["id"]}'):agent.approve(r['id']);st.rerun()
     if y.button('Reject',key=f'r{r["id"]}'):agent.reject(r['id'],'Owner/Admin rejected');st.rerun()
 else:st.info('No pending recommendations.')
 st.subheader('Market Research Sources')
 if has_permission(user['role'],'Create'):
  with st.form('research'):
   title=st.text_input('Source / Topic');url=st.text_input('Source URL');sd=st.date_input('Source Date');conf=st.selectbox('Confidence',['High','Medium','Low']);summary=st.text_area('Summary / Findings')
   if st.form_submit_button('Save Research') and title:
    svc.add_research_source(title,url,str(sd),conf,summary);st.rerun()
 sources=svc.research_sources()
 if sources: display_table([dict(x) for x in sources])

 st.subheader('Forecasts (clearly labelled forecast)')
 if has_permission(user['role'],'Create'):
  with st.form('forecast'):
   metric=st.text_input('Metric');period=st.text_input('Period',value='Next Month');value=st.number_input('Forecast Value');conf=st.selectbox('Forecast Confidence',['High','Medium','Low'],key='fc');basis=st.text_input('Basis / assumptions')
   if st.form_submit_button('Save Forecast') and metric and basis:
    svc.create_forecast(metric,period,value,conf,basis);st.rerun()
 forecasts=svc.forecasts()
 if forecasts: display_table([dict(x) for x in forecasts])

 st.subheader('Tasks')
 tasks=svc.tasks();
 if has_permission(user['role'],'Create'):
  with st.form('task'):
   title=st.text_input('Task');desc=st.text_area('Description');pri=st.selectbox('Priority',['High','Normal','Low']);due=st.date_input('Due date');assigned=st.text_input('Assigned to')
   if st.form_submit_button('Add Task') and title:svc.add_task(title,desc,pri,str(due),assigned);st.rerun()
 if tasks:
  display_table([dict(x) for x in tasks])
