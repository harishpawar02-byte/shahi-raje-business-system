import streamlit as st
from database.connection import db_session
from services.mis_service import MISService
from core.ui import require_login, display_table
from core.permissions import has_permission

user=require_login();st.title('🧂 Raw Materials')
with db_session() as c:
 svc=MISService(c,user); rms=svc.raw_materials(); units=svc.units(); sups=svc.suppliers(); umap={u['name']:u['id'] for u in units}; smap={f"{s['id']} — {s['name']}":s['id'] for s in sups}
 if has_permission(user['role'],'Create') and units:
  with st.form('rm'):
   code=st.text_input('Code',value=f'RM-{len(rms)+1:04d}');name=st.text_input('Name');cat=st.text_input('Category');unit=st.selectbox('Base Unit',list(umap));punit=st.selectbox('Purchase Unit',list(umap));conv=st.number_input('Purchase→Base conversion',min_value=0.000001,value=1.0);re=st.number_input('Reorder Level',min_value=0.0);mn=st.number_input('Minimum Level',min_value=0.0);mx=st.number_input('Maximum Level',min_value=0.0);sup=st.selectbox('Preferred Supplier',[None]+list(smap),format_func=lambda x:'None' if x is None else x)
   if st.form_submit_button('Create Raw Material') and name:
    try:svc.create_raw_material(code,name,cat,umap[unit],umap[punit],conv,re,mn,mx,smap.get(sup) if sup else None);st.rerun()
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
 display_table([{'Sr. No.': i, **dict(r)} for i, r in enumerate(rms, 1)])
 if rms and has_permission(user['role'],'Edit'):
  sel=st.selectbox('Select material to edit',[f"{r['id']} — {r['name']}" for r in rms]);r=next(x for x in rms if x['id']==int(sel.split(' — ')[0]))
  with st.form('edit_rm'):
   code=st.text_input('Code',r['code'] or '');name=st.text_input('Name',r['name']);cat=st.text_input('Category',r['category'] or '');unit=st.selectbox('Base Unit',list(umap),index=list(umap.values()).index(r['unit_id']) if r['unit_id'] in umap.values() else 0);punit=st.selectbox('Purchase Unit',list(umap),index=list(umap.values()).index(r['purchase_unit_id']) if r['purchase_unit_id'] in umap.values() else 0);conv=st.number_input('Conversion',min_value=0.000001,value=float(r['conversion_factor'] or 1));re=st.number_input('Reorder',min_value=0.0,value=float(r['reorder_level']));mn=st.number_input('Minimum',min_value=0.0,value=float(r['min_level']));mx=st.number_input('Maximum',min_value=0.0,value=float(r['max_level']));sup=st.selectbox('Preferred Supplier',[None]+list(smap),index=0 if not r['preferred_supplier_id'] else list(smap.values()).index(r['preferred_supplier_id'])+1,format_func=lambda x:'None' if x is None else x)
   if st.form_submit_button('Save changes'):
    try:svc.update_raw_material(r['id'],code,name,cat,umap[unit],umap[punit],conv,re,mn,mx,smap.get(sup) if sup else None);st.rerun()
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
