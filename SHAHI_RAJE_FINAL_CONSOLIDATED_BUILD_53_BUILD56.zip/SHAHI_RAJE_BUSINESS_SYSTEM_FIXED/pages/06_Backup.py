import streamlit as st
from core.backup import backup_now,list_backups,restore,validate_db
from database.connection import db_session
from services.mis_service import MISService
from services.auth_service import change_password
from core.ui import require_login, display_table
from core.permissions import has_permission

user=require_login();st.title('🛡️ Backup, Settings & Security')
with db_session() as c:
 svc=MISService(c,user);settings=svc.settings()
 t1,t2,t3,t4=st.tabs(['Company Settings','Backup / Restore','Security','System Audit'])
 with t1:
  fields=['company_name','company_address','company_phone','company_email','company_gstin','currency','timezone','language','negative_stock_policy','default_warehouse_id','tax_mode','default_tax_rate','invoice_prefix','purchase_prefix','grn_prefix','backup_retention_days','backup_frequency']
  for k in fields:
   val=st.text_input(k,settings.get(k,''),key='set_'+k)
   if has_permission(user['role'],'Edit') and st.button(f'Save {k}',key='save_'+k):svc.save_setting(k,val);st.success('Saved')
  st.subheader('Warehouses')
  wh=svc.warehouses();display_table([dict(x) for x in wh])
  if has_permission(user['role'],'Create'):
   with st.form('warehouse'):
    code=st.text_input('Warehouse Code');name=st.text_input('Warehouse Name');branch=st.text_input('Branch')
    if st.form_submit_button('Add Warehouse') and code and name:
     try:svc.add_warehouse(code,name,branch);st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
 with t2:
  if st.button('💾 Backup Now'):
   try:p=backup_now('manual');st.success(f'Backup created: {p.name}')
   except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  b=list_backups()
  if b: display_table([{'file':p.name,'size_kb':round(p.stat().st_size/1024,1),'valid':validate_db(p)[0]} for p in b])
  if b and has_permission(user['role'],'Approve'):
   sel=st.selectbox('Restore backup',[str(p) for p in b]);confirm=st.checkbox('I understand restore replaces the active database after a safety backup')
   if st.button('Restore Selected') and confirm:
    try:safety=restore(sel);st.success(f'Restored. Safety backup: {safety.name}. Restart the app.')
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
 with t3:
  st.subheader('Change password')
  with st.form('password'):
   cur=st.text_input('Current password',type='password');p1=st.text_input('New password',type='password');p2=st.text_input('Confirm password',type='password')
   if st.form_submit_button('Change Password'):
    try:
     if p1!=p2:raise ValueError('Passwords do not match')
     change_password(c,user['id'],cur,p1);st.success('Password changed.');st.session_state.user['password_change_required']=False
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
 with t4:
  display_table([dict(x) for x in svc.audit(200)])
