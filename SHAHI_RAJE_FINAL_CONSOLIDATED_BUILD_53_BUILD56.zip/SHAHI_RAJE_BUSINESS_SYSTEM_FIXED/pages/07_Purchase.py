import streamlit as st
from database.connection import db_session
from services.mis_service import MISService
from services.purchase_service import PurchaseService
from core.ui import require_login, display_table
from core.permissions import has_permission

user=require_login();st.title('🛒 Purchase — PO → GRN → Payable')
with db_session() as c:
 svc=MISService(c,user);purchase=PurchaseService(c,user);sups=svc.suppliers();rms=svc.raw_materials();smap={f"{s['id']} — {s['name']}":s['id'] for s in sups};rmap={f"{r['id']} — {r['name']}":r['id'] for r in rms}
 t1,t2,t3=st.tabs(['Create PO','Receive GRN','Supplier Payment'])
 with t1:
  if not smap or not rmap:st.info('Create a supplier and raw materials first.')
  elif has_permission(user['role'],'Create'):
   with st.form('po'):
    sup=st.selectbox('Supplier',list(smap));n=st.number_input('Lines',1,20,1);items=[]
    for i in range(n):
     a,b,d=st.columns(3);rm=a.selectbox(f'RM {i+1}',list(rmap),key=f'rm{i}');qty=b.number_input(f'Qty {i+1}',min_value=0.001,key=f'qty{i}');rate=d.number_input(f'Rate {i+1} ₹',min_value=0.0,key=f'rate{i}');items.append({'raw_material_id':rmap[rm],'quantity':qty,'rate':rate})
    if st.form_submit_button('Create PO'):
     try:pid,num=purchase.create_po(smap[sup],items);st.success(f'{num} created');st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  drafts=svc.purchase_drafts()
  if drafts and has_permission(user['role'],'Approve'):
   sel=st.selectbox('Approve Draft PO',[f"{r['id']} — {r['po_number']}" for r in drafts]);
   if st.button('Approve PO'):purchase.approve_po(int(sel.split(' — ')[0]));st.rerun()
 with t2:
  pos=svc.purchase_receivable_orders()
  if pos:
   pm={f"{p['id']} — {p['po_number']}":p['id'] for p in pos};sel=st.selectbox('PO',list(pm));poid=pm[sel];lines=svc.purchase_items(poid);receipts=[]
   for r in lines:
    remaining=float(r['quantity'])-float(r['received_qty']);a,b,d=st.columns(3);a.write(f"{r['name']} • remaining {remaining:g}");q=b.number_input(f'Receive {r["id"]}',0.0,max(remaining,0.0),0.0,key=f'grn{r["id"]}');batch=d.text_input(f'Batch {r["id"]}',key=f'bat{r["id"]}');
    if q>0:receipts.append({'po_item_id':r['id'],'raw_material_id':r['raw_material_id'],'quantity':q,'batch_number':batch or None,'rate':r['rate']})
   if has_permission(user['role'],'Create') and st.button('Create GRN') and receipts:
    try:gid,num=purchase.receive_goods(poid,receipts);st.success(f'{num} received');st.rerun()
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
 with t3:
  if smap:
   sup=st.selectbox('Supplier',list(smap),key='pay_sup');sid=smap[sup];out=purchase.outstanding_payable(sid);st.metric('Outstanding Payable',f'₹{out}');pos=svc.supplier_purchase_orders(sid);
   if pos and out>0:
    pm={f"{p['id']} — {p['po_number']}":p['id'] for p in pos};po=st.selectbox('PO',list(pm),key='pay_po');amt=st.number_input('Payment ₹',min_value=0.0,max_value=float(out));ref=st.text_input('Reference');mode=st.selectbox('Payment Mode',['Cash','UPI','Bank','Cheque','Other']);
    if st.button('Record Payment') and amt>0:
     try:purchase.record_payment(sid,pm[po],amt,ref or None,mode);st.success('Payment recorded');st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
