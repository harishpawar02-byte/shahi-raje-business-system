import streamlit as st
from database.connection import db_session
from services.auth_service import hash_password
from services.mis_service import MISService
from core.ui import require_login, display_table
from core.permissions import has_permission,ROLES

user=require_login();st.title('👥 HR & Admin')
if not has_permission(user['role'],'Approve'):st.warning('Owner/Admin only.');st.stop()
with db_session() as c:
 svc=MISService(c,user);t1,t2=st.tabs(['Users','Employees'])
 with t1:
  with st.form('user'):
   uname=st.text_input('Username');pwd=st.text_input('Initial Password',type='password');role=st.selectbox('Role',ROLES)
   if st.form_submit_button('Create User') and uname and pwd:
    try:
     if len(pwd)<8:raise ValueError('Password must contain at least 8 characters')
     svc.create_user(uname,hash_password(pwd),role);st.success('User created; first login requires password change.');st.rerun()
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  display_table([dict(x) for x in svc.users()])
  users=svc.users()
  if users:
   selected=st.selectbox('Deactivate user',[f"{x['id']} — {x['username']}" for x in users])
   if st.button('Deactivate Selected User'):
    try:svc.deactivate('users',int(selected.split(' — ')[0]));st.rerun()
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
 with t2:
  with st.form('emp'):
   n=st.text_input('Employee Name');title=st.text_input('Role/Title');contact=st.text_input('Contact')
   if st.form_submit_button('Create Employee') and n:
    try:
     svc.create_employee(n,title,contact);st.success('Employee created');st.rerun()
    except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  display_table([dict(x) for x in svc.employees()])
