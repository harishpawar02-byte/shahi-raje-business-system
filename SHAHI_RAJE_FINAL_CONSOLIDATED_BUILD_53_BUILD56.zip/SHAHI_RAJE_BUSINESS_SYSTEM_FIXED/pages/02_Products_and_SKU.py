import streamlit as st
from database.connection import db_session
from services.mis_service import MISService
from core.ui import require_login, display_table
from core.permissions import has_permission

user=require_login();st.title('🌶️ Products & SKU')
with db_session() as c:
 svc=MISService(c,user); products=svc.products(); skus=svc.skus(); units=svc.units(); packs=svc.packaging()
 t1,t2,t3=st.tabs(['Products','SKUs','Packaging Materials'])
 with t1:
  if has_permission(user['role'],'Create'):
   with st.form('product'):
    n=st.text_input('Product name');cat=st.text_input('Category',value='Masala');
    if st.form_submit_button('Create') and n:
     try:svc.create_product(n,cat);st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  display_table([{'Sr. No.': i, **dict(r)} for i, r in enumerate(products, 1)])
  if products and has_permission(user['role'],'Edit'):
   sel=st.selectbox('Select product to edit',[f"{r['id']} — {r['name']}" for r in products]);r=next(x for x in products if x['id']==int(sel.split(' — ')[0]))
   with st.form('edit_product'):
    n=st.text_input('Name',r['name']);cat=st.text_input('Category',r['category'] or '')
    if st.form_submit_button('Save changes'):
     try:svc.update_product(r['id'],n,cat);st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
 with t2:
  if has_permission(user['role'],'Create') and products and units:
   pmap={f"{p['id']} — {p['name']}":p['id'] for p in products};umap={u['name']:u['id'] for u in units};pm={f"{p['id']} — {p['name']}":p['id'] for p in packs}
   with st.form('sku'):
    p=st.selectbox('Product',list(pmap));code=st.text_input('SKU Code');pack=st.text_input('Pack Size',value='100g');unit=st.selectbox('Unit',list(umap));barcode=st.text_input('Barcode');sp=st.number_input('Selling Price ₹',min_value=0.0);mrp=st.number_input('MRP ₹',min_value=0.0);cost=st.number_input('Standard Cost ₹',min_value=0.0);tax=st.number_input('GST %',min_value=0.0,value=5.0);reorder=st.number_input('Reorder Qty',min_value=0.0);packmat=st.selectbox('Packaging Material',[None]+list(pm.keys()),format_func=lambda x:'None' if x is None else x)
    if st.form_submit_button('Create SKU') and code:
     try:svc.create_sku(pmap[p],code,pack,umap[unit],barcode,sp,mrp,cost,pm.get(packmat) if packmat else None,tax,reorder);st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  display_table([{'Sr. No.': i, **dict(r)} for i, r in enumerate(skus, 1)])
 with t3:
  if has_permission(user['role'],'Create') and units:
   umap={u['name']:u['id'] for u in units}
   with st.form('packmat'):
    code=st.text_input('Code');name=st.text_input('Name');cat=st.text_input('Category');unit=st.selectbox('Unit',list(umap));re=st.number_input('Reorder',min_value=0.0);cost=st.number_input('Standard Cost ₹',min_value=0.0)
    if st.form_submit_button('Create Packaging Material') and code and name:
     try:svc.create_packaging(code,name,cat,umap[unit],re,cost);st.rerun()
     except Exception as e:st.error('Operation failed. Please check the entered data and try again.')
  display_table([{'Sr. No.': i, **dict(r)} for i, r in enumerate(packs, 1)])
