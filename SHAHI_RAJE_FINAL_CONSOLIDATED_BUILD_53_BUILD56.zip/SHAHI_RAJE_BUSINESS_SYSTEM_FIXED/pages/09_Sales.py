import streamlit as st
from database.connection import db_session
from services.mis_service import MISService
from services.sales_service import SalesService
from core.ui import require_login, display_table
from core.permissions import has_permission


user = require_login()
st.title('🧾 Sales — Order, Invoice & Payments')

with db_session() as c:
    svc = MISService(c, user)
    sales = SalesService(c, user)
    custs = svc.customers()
    skus = svc.skus()
    warehouses = svc.warehouses()
    cmap = {f"{x['id']} — {x['name']}": x['id'] for x in custs}
    smap = {f"{x['id']} — {x['sku_code']} / {x['product_name']}": x for x in skus}
    wmap = {f"{x['id']} — {x['name']}": x['id'] for x in warehouses}

    if not cmap or not smap:
        st.info('Create customers and SKUs first.')
    else:
        t1, t2, t3, t4 = st.tabs([
            'Sales Order', 'Stock Check & Picking', 'Invoice + Stock Issue', 'Payments'
        ])

        # ---------- Sales Order ----------
        with t1:
            st.subheader('1. Create Sales Order')
            if has_permission(user['role'], 'Create'):
                cust = st.selectbox('Customer', list(cmap), key='so_customer')
                wh = st.selectbox('Warehouse', list(wmap), key='so_warehouse') if wmap else None
                tax_type = st.selectbox('Tax Type', ['GST', 'Intra-State', 'Inter-State', 'Exempt'], key='so_tax')
                place = st.text_input('Place of Supply (optional)', key='so_place')
                notes = st.text_input('Notes (optional)', key='so_notes')
                n = st.number_input('Lines', 1, 20, 1, key='so_lines')
                lines = []
                for i in range(n):
                    a, b, d = st.columns(3)
                    label = a.selectbox(f'SKU {i + 1}', list(smap), key=f'so_sku{i}')
                    q = b.number_input(f'Qty {i + 1}', min_value=0.001, value=1.0, key=f'so_qty{i}')
                    tax = d.number_input(
                        f'GST % {i + 1}', min_value=0.0,
                        value=float(smap[label]['tax_rate'] or 5), key=f'so_tax{i}')
                    lines.append({
                        'sku_id': smap[label]['id'],
                        'quantity': q,
                        'rate': smap[label]['selling_price'],
                        'tax_rate': tax,
                    })
                if st.button('Create Sales Order', type='primary'):
                    try:
                        oid, num = sales.create_sales_order(
                            cmap[cust], lines,
                            warehouse_id=(wmap[wh] if wh else None),
                            tax_type=tax_type, place_of_supply=place or None, notes=notes or None)
                        st.success(f'{num} created')
                        st.rerun()
                    except Exception as e:
                        st.error('Operation failed. Please check the entered data and try again.')

            orders = sales.sales_orders()
            if orders:
                display_table([dict(x) for x in orders])

                draft = [x for x in orders if x['status'] == 'Draft']
                if draft and has_permission(user['role'], 'Approve'):
                    om = {f"{x['order_number']} — {x['customer_name']}": x['id'] for x in draft}
                    selected = st.selectbox('Draft order to confirm', list(om), key='confirm_order')
                    if st.button('Confirm Order (Stock Check)', key='confirm_btn'):
                        try:
                            sales.confirm_sales_order(om[selected])
                            st.success('Order confirmed after stock check')
                            st.rerun()
                        except Exception as e:
                            st.error('Operation failed. Please check the entered data and try again.')

        # ---------- Stock check & picking ----------
        with t2:
            st.subheader('2. Stock Check & Picking')
            confirmed = sales.sales_orders(['Confirmed'])
            if not confirmed:
                st.info('No confirmed sales orders waiting for picking.')
            else:
                om = {f"{x['order_number']} — {x['customer_name']}": x['id'] for x in confirmed}
                selected = st.selectbox('Confirmed Order', list(om), key='pick_order')
                oid = om[selected]
                ok, rows = sales.stock_check_order(oid)
                display_table([
                    {
                        'SKU': r['sku_code'], 'Product': r['product_name'],
                        'Requested': r['requested'], 'Available': r['available'],
                        'Short': r['short'], 'Stock OK': 'Yes' if r['sufficient'] else 'No'
                    } for r in rows
                ])
                if ok and has_permission(user['role'], 'Create'):
                    if st.button('Mark Order Picked', type='primary', key='pick_btn'):
                        try:
                            sales.pick_sales_order(oid)
                            st.success('Order picked. Stock remains unchanged until invoice + stock issue.')
                            st.rerun()
                        except Exception as e:
                            st.error('Operation failed. Please check the entered data and try again.')

        # ---------- Invoice + stock issue ----------
        with t3:
            st.subheader('3. Invoice + Stock Issue')
            picked = sales.sales_orders(['Picked'])
            if picked:
                om = {f"{x['order_number']} — {x['customer_name']}": x['id'] for x in picked}
                selected = st.selectbox('Picked Order', list(om), key='invoice_order')
                oid = om[selected]
                if st.button('Create Invoice + Issue Stock', type='primary', key='invoice_order_btn'):
                    try:
                        iid, num, total = sales.create_invoice_from_order(oid)
                        st.success(f'{num} • ₹{total} • Stock issued')
                        st.rerun()
                    except Exception as e:
                        st.error('Operation failed. Please check the entered data and try again.')
            else:
                st.info('No picked sales orders waiting for invoice.')

            st.divider()
            st.subheader('Direct Invoice (without Sales Order)')
            if has_permission(user['role'], 'Create'):
                cust = st.selectbox('Customer', list(cmap), key='direct_customer')
                wh = st.selectbox('Warehouse', list(wmap), key='direct_warehouse') if wmap else None
                tax_type = st.selectbox('Tax Type', ['GST', 'Intra-State', 'Inter-State', 'Exempt'], key='direct_tax')
                place = st.text_input('Place of Supply (optional)', key='direct_place')
                n = st.number_input('Lines', 1, 10, 1, key='direct_lines')
                lines = []
                for i in range(n):
                    a, b, d = st.columns(3)
                    label = a.selectbox(f'Direct SKU {i + 1}', list(smap), key=f'dsku{i}')
                    q = b.number_input(f'Direct Qty {i + 1}', min_value=0.001, value=1.0, key=f'dqty{i}')
                    tax = d.number_input(
                        f'Direct GST % {i + 1}', min_value=0.0,
                        value=float(smap[label]['tax_rate'] or 5), key=f'dtax{i}')
                    lines.append({
                        'sku_id': smap[label]['id'], 'quantity': q,
                        'rate': smap[label]['selling_price'], 'tax_rate': tax,
                    })
                if st.button('Create Direct Invoice + Issue Stock', key='direct_invoice_btn'):
                    try:
                        iid, num, total = sales.create_invoice(
                            cmap[cust], lines,
                            warehouse_id=(wmap[wh] if wh else None),
                            tax_type=tax_type, place_of_supply=place or None)
                        st.success(f'{num} • ₹{total} • Stock issued')
                        st.rerun()
                    except Exception as e:
                        st.error('Operation failed. Please check the entered data and try again.')

            invs = svc.sales_invoices()
            if invs:
                st.subheader('Recent Invoices')
                display_table([dict(x) for x in invs])

        # ---------- Payments ----------
        with t4:
            st.subheader('4. Customer Payments & Receivables')
            cust = st.selectbox('Customer', list(cmap), key='payment_customer')
            cid = cmap[cust]
            out = sales.outstanding_balance(cid)
            st.metric('Outstanding', f'₹{out}')
            invs = svc.customer_invoices(cid)
            if invs and out > 0:
                im = {f"{x['id']} — {x['invoice_number']} — ₹{x['total']}": x['id'] for x in invs}
                sel = st.selectbox('Invoice', list(im), key='payment_invoice')
                amt = st.number_input('Payment ₹', min_value=0.0, max_value=float(out), key='payment_amount')
                ref = st.text_input('Reference', key='payment_ref')
                mode = st.selectbox('Payment Mode', ['Cash', 'UPI', 'Bank', 'Cheque', 'Other'], key='payment_mode')
                if st.button('Record Payment', key='record_payment') and amt > 0:
                    try:
                        sales.record_payment(cid, im[sel], amt, ref or None, mode)
                        st.success('Payment recorded')
                        st.rerun()
                    except Exception as e:
                        st.error('Operation failed. Please check the entered data and try again.')
            elif not invs:
                st.info('No invoices for this customer.')
            else:
                st.success('No outstanding amount for this customer.')
