# SHAHI RAJE BUSINESS MANAGEMENT SYSTEM — FIXED DELIVERY

## Work completed in this revision
- Kept the existing production repair and its regression coverage.
- Completed the Sales page workflow: Sales Order → Stock Check → Picking → Invoice + Stock Issue → Customer Payment.
- Added direct Invoice + Stock Issue as a separate legacy/manual path.
- Added append-only sales-order, picking and invoice linkage with audit events.
- Stock is not reduced during order creation or picking; the stock-issue ledger entry occurs atomically with invoice creation.
- Existing direct-invoice, payment and cancellation behavior remains covered by regression tests.

## Verification
- Python compilation: PASS
- pytest: **27 passed**
- Existing packaged database migrated safely on a temporary copy through v010: PASS
- SQLite `PRAGMA integrity_check`: PASS (`ok`)
- SQLite foreign-key check after v010: PASS (0 errors)
- Migration tracking: v001–v010

## Data protection
- Existing business database in `data/mis.db` was not overwritten during this source revision.
- The new v010 migration is additive. On normal startup, the application applies it only when its migration version is not already recorded.
- Inventory history remains append-only; sales cancellation remains a compensating stock movement.
- Existing backups in `backups/` are retained.

## Owner usage
- Use `START_SHAHI_RAJE.bat` to start the application.
- No manual database reset is required.
- No other AI builder is required for this project; this ZIP is the updated project artifact for the next replacement/startup step on the owner's Windows machine.

## Current scope note
This is operational MIS software. It is not a claim of statutory accounting, GST, tax or legal compliance. External services such as WhatsApp/SMS/email gateways, cloud hosting, barcode hardware and third-party LLM APIs remain optional and are not faked as connected.
