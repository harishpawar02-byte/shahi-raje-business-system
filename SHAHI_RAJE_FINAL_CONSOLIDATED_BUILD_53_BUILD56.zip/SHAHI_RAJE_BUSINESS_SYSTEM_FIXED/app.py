"""SHAHI RAJE Business Management System — owner-controlled local MIS."""
import streamlit as st
from config import APP_NAME
from database.migrations.migration_manager import run_migrations
from database.connection import db_session
from services.auth_service import authenticate, change_password

st.set_page_config(page_title=APP_NAME, page_icon='🌶️', layout='wide')
run_migrations()

if 'user' not in st.session_state:
    st.session_state.user = None
if 'language' not in st.session_state:
    st.session_state.language = 'Marathi'


def login_screen():
    st.title('🌶️ SHAHI RAJE BUSINESS MANAGEMENT SYSTEM')
    st.caption('Owner-controlled • Historical records protected • Local-first')
    with st.form('login'):
        username = st.text_input('Username', value='owner')
        password = st.text_input('Password', type='password')
        submitted = st.form_submit_button('Login')
    if submitted:
        try:
            with db_session() as conn:
                user = authenticate(conn, username, password)
            if user:
                st.session_state.user = user
                st.rerun()
            else:
                st.error('Invalid username or password')
        except Exception:
            st.error('Login failed. Please check the application log.')
    st.info('First-use login: owner / HR/Admin. Change the password immediately.')


def password_change_screen(user):
    st.warning('Security: please change the initial/default password before continuing.')
    with st.form('mandatory_password'):
        current = st.text_input('Current password', type='password')
        new = st.text_input('New password (minimum 8 characters)', type='password')
        confirm = st.text_input('Confirm new password', type='password')
        if st.form_submit_button('Change Password'):
            try:
                if new != confirm:
                    raise ValueError('Passwords do not match')
                with db_session() as c:
                    change_password(c, user['id'], current, new)
                st.session_state.user['password_change_required'] = False
                st.success('Password changed successfully.')
                st.rerun()
            except Exception as e:
                st.error('Operation failed. Please try again.')


def main_app():
    user = st.session_state.user
    if user.get('password_change_required'):
        password_change_screen(user)
        st.stop()

    st.sidebar.success(f"👤 {user['username']} • {user['role']}")
    languages = ['Marathi', 'Hindi', 'English', 'Gujarati']
    st.session_state.language = st.sidebar.selectbox(
        'Language', languages,
        index=languages.index(st.session_state.language)
    )
    if st.sidebar.button('Logout'):
        st.session_state.user = None
        st.rerun()

    # Explicit navigation removes the old root "app" entry and guarantees
    # the business modules remain in a stable numbered sequence.
    pages = [
        st.Page('pages/01_Dashboard.py', title='01 Dashboard', icon='📊'),
        st.Page('pages/02_Products_and_SKU.py', title='02 Products & SKU', icon='🌶️'),
        st.Page('pages/03_Raw_Materials.py', title='03 Raw Materials', icon='🧂'),
        st.Page('pages/04_Inventory.py', title='04 Inventory', icon='📦'),
        st.Page('pages/05_Suppliers_and_Customers.py', title='05 Suppliers & Customers', icon='🤝'),
        st.Page('pages/06_Backup.py', title='06 Backup, Settings & Security', icon='🛡️'),
        st.Page('pages/07_Purchase.py', title='07 Purchase', icon='🛒'),
        st.Page('pages/08_Production.py', title='08 Production', icon='🏭'),
        st.Page('pages/09_Sales.py', title='09 Sales', icon='🧾'),
        st.Page('pages/10_Finance.py', title='10 Finance', icon='💰'),
        st.Page('pages/11_HR_Admin.py', title='11 HR & Admin', icon='👥'),
        st.Page('pages/12_AI_Agents.py', title='12 AI Agents', icon='🤖'),
        st.Page('pages/13_Settings_Reports.py', title='13 Reports & System Control', icon='📑'),
    ]
    pg = st.navigation(pages, position='sidebar')
    pg.run()


if st.session_state.user is None:
    login_screen()
else:
    main_app()
