@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe py -m venv .venv
call .venv\Scripts\activate.bat
python -c "import streamlit,pandas" >nul 2>&1
if errorlevel 1 python -m pip install -r requirements.txt
python health_check.py
python -m streamlit run app.py
