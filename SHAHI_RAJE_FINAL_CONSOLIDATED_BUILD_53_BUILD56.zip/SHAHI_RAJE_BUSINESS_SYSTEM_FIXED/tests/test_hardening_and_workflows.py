import sqlite3
import pytest
from database.migrations.migration_manager import VERSIONS_DIR
from database.repositories.inventory_repository import InventoryRepository
from services.auth_service import hash_password, authenticate
from services.mis_service import MISService
from core.exceptions import InsufficientStockError

OWNER={'username':'owner','role':'Owner','id':1}

def test_pbkdf2_password_roundtrip(conn):
    h=hash_password('StrongPass123!')
    assert h.startswith('pbkdf2_sha256$')
    conn.execute("UPDATE users SET password_hash=?, password_scheme='pbkdf2_sha256', password_change_required=0 WHERE username='owner'",(h,));conn.commit()
    assert authenticate(conn,'owner','StrongPass123!')['role']=='Owner'

def test_safe_inventory_correction_preserves_original(conn):
    rm=conn.execute("INSERT INTO raw_materials(code,name,unit_id,reorder_level) VALUES('RM-X','Test RM',1,'5')").lastrowid;conn.commit()
    inv=InventoryRepository(conn);mid=inv.record_movement(item_type='raw_material',item_id=rm,movement_type='Opening',quantity='10',user='owner')
    svc=MISService(conn,OWNER);cid=svc.correct_stock(mid,'8','Counted physical stock is 8')
    assert conn.execute('SELECT quantity FROM stock_movements WHERE id=?',(mid,)).fetchone()[0]=='10.000'
    assert conn.execute('SELECT quantity FROM stock_movements WHERE id=?',(cid,)).fetchone()[0]=='-2.000'
    assert inv.get_balance('raw_material',rm)==8

def test_negative_correction_blocked(conn):
    rm=conn.execute("INSERT INTO raw_materials(code,name,unit_id,reorder_level) VALUES('RM-Y','Test RM 2',1,'5')").lastrowid;conn.commit();inv=InventoryRepository(conn);mid=inv.record_movement(item_type='raw_material',item_id=rm,movement_type='Opening',quantity='2',user='owner')
    with pytest.raises(InsufficientStockError):MISService(conn,OWNER).correct_stock(mid,'-1','Invalid negative correction')

def test_migrations_include_hardening(conn):
    cols={r['name'] for r in conn.execute('PRAGMA table_info(stock_movements)')}
    assert {'correction_of_id','correction_reason','approved_by','source'} <= cols
    assert conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='qc_records'").fetchone()
    assert conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='company_settings'").fetchone()


def test_seeded_owner_login_uses_pbkdf2(conn):
    user = authenticate(conn, 'owner', 'HR/Admin')
    assert user is not None
    assert user['role'] == 'Owner'
    row = conn.execute("SELECT password_scheme, password_change_required FROM users WHERE username='owner'").fetchone()
    assert row['password_scheme'] == 'pbkdf2_sha256'
    assert row['password_change_required'] == 1
