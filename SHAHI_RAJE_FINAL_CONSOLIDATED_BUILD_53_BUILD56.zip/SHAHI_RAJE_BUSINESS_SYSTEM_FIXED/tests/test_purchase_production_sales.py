"""
Phase 2-5 tests. Run with: pytest tests/
"""
from services.purchase_service import PurchaseService
from services.production_service import ProductionService
from services.sales_service import SalesService
from services.finance_service import FinanceService

OWNER = {"username": "owner", "role": "Owner"}


def _setup_masters(conn):
    sup_id = conn.execute(
        "INSERT INTO suppliers (name) VALUES ('ABC Traders')").lastrowid
    rm_id = conn.execute(
        "INSERT INTO raw_materials (name, unit_id, reorder_level) VALUES ('Chilli Powder',1,'20')").lastrowid
    prod_id = conn.execute(
        "INSERT INTO products (name) VALUES ('Garam Masala')").lastrowid
    sku_id = conn.execute(
        "INSERT INTO skus (product_id, sku_code, pack_size, unit_id, selling_price) "
        "VALUES (?, 'GRM-100G','100g',1,150)", (prod_id,)).lastrowid
    cust_id = conn.execute(
        "INSERT INTO customers (name, customer_type) VALUES ('Retail Shop','Retailer')").lastrowid
    conn.commit()
    return dict(sup_id=sup_id, rm_id=rm_id, prod_id=prod_id, sku_id=sku_id, cust_id=cust_id)


def test_purchase_to_stock_in(conn):
    ids = _setup_masters(conn)
    svc = PurchaseService(conn, OWNER)
    po_id, _ = svc.create_po(ids["sup_id"], [{"raw_material_id": ids["rm_id"], "quantity": 100, "rate": 200}])
    svc.approve_po(po_id)
    items = svc.po_repo.items(po_id)
    svc.receive_goods(po_id, [{
        "po_item_id": items[0]["id"], "raw_material_id": ids["rm_id"],
        "quantity": 100, "rate": 200, "batch_number": "CHL-001"}])
    bal = conn.execute(
        "SELECT COALESCE(SUM(CAST(quantity AS REAL)),0) b FROM stock_movements "
        "WHERE item_type='raw_material' AND item_id=?", (ids["rm_id"],)).fetchone()["b"]
    assert bal == 100


def test_production_consumes_and_outputs_on_qc_pass(conn):
    ids = _setup_masters(conn)
    purchase = PurchaseService(conn, OWNER)
    po_id, _ = purchase.create_po(ids["sup_id"], [{"raw_material_id": ids["rm_id"], "quantity": 100, "rate": 200}])
    purchase.approve_po(po_id)
    items = purchase.po_repo.items(po_id)
    purchase.receive_goods(po_id, [{
        "po_item_id": items[0]["id"], "raw_material_id": ids["rm_id"],
        "quantity": 100, "rate": 200, "batch_number": "CHL-001"}])

    prod = ProductionService(conn, OWNER)
    recipe_id, _ = prod.create_recipe_version(
        ids["prod_id"], [{"raw_material_id": ids["rm_id"], "quantity_per_batch": 0.5}])
    order_id, _, _ = prod.plan_production(ids["prod_id"], recipe_id, 10, {ids["rm_id"]: 200})
    batch_id, actual_cost, _ = prod.consume_and_produce(
        production_order_id=order_id, product_id=ids["prod_id"],
        consumptions=[{"raw_material_id": ids["rm_id"], "quantity": 5, "rate": 200}],
        output_batch_number="GRM-001", output_qty=10, qc_status="Passed")

    finished_bal = conn.execute(
        "SELECT COALESCE(SUM(CAST(quantity AS REAL)),0) b FROM stock_movements "
        "WHERE item_type='sku' AND item_id=?", (ids["prod_id"],)).fetchone()["b"]
    assert finished_bal == 10
    assert actual_cost == 1000  # 5 * 200 (Decimal compares equal to int here)


def test_qc_failed_batch_not_added_to_finished_stock(conn):
    ids = _setup_masters(conn)
    purchase = PurchaseService(conn, OWNER)
    po_id, _ = purchase.create_po(ids["sup_id"], [{"raw_material_id": ids["rm_id"], "quantity": 100, "rate": 200}])
    purchase.approve_po(po_id)
    items = purchase.po_repo.items(po_id)
    purchase.receive_goods(po_id, [{
        "po_item_id": items[0]["id"], "raw_material_id": ids["rm_id"],
        "quantity": 100, "rate": 200, "batch_number": "CHL-002"}])

    prod = ProductionService(conn, OWNER)
    recipe_id, _ = prod.create_recipe_version(
        ids["prod_id"], [{"raw_material_id": ids["rm_id"], "quantity_per_batch": 0.5}])
    order_id, _, _ = prod.plan_production(ids["prod_id"], recipe_id, 10, {})
    prod.consume_and_produce(
        production_order_id=order_id, product_id=ids["prod_id"],
        consumptions=[{"raw_material_id": ids["rm_id"], "quantity": 5, "rate": 200}],
        output_batch_number="GRM-BAD", output_qty=10, qc_status="Failed")

    finished_bal = conn.execute(
        "SELECT COALESCE(SUM(CAST(quantity AS REAL)),0) b FROM stock_movements "
        "WHERE item_type='sku' AND item_id=?", (ids["prod_id"],)).fetchone()["b"]
    assert finished_bal == 0


def test_sales_invoice_deducts_stock_and_creates_receivable(conn):
    ids = _setup_masters(conn)
    conn.execute(
        "INSERT INTO stock_movements (item_type, item_id, movement_type, quantity, created_by) "
        "VALUES ('sku', ?, 'Opening', '20', 'test')", (ids["prod_id"],))
    conn.commit()

    sales = SalesService(conn, OWNER)
    inv_id, _, total = sales.create_invoice(ids["cust_id"], [{
        "sku_id": ids["sku_id"], "product_id": ids["prod_id"],
        "quantity": 4, "rate": 150, "tax_rate": 5}])
    assert total == 630  # 600 + 5% tax

    bal = conn.execute(
        "SELECT COALESCE(SUM(CAST(quantity AS REAL)),0) b FROM stock_movements "
        "WHERE item_type='sku' AND item_id=?", (ids["prod_id"],)).fetchone()["b"]
    assert bal == 16  # 20 - 4

    assert sales.outstanding_balance(ids["cust_id"]) == 630
    sales.record_payment(ids["cust_id"], inv_id, 300)
    assert sales.outstanding_balance(ids["cust_id"]) == 330


def test_finance_summary_matches_ledger(conn):
    ids = _setup_masters(conn)
    conn.execute(
        "INSERT INTO stock_movements (item_type, item_id, movement_type, quantity, created_by) "
        "VALUES ('sku', ?, 'Opening', '20', 'test')", (ids["prod_id"],))
    conn.commit()
    sales = SalesService(conn, OWNER)
    sales.create_invoice(ids["cust_id"], [{
        "sku_id": ids["sku_id"], "product_id": ids["prod_id"],
        "quantity": 4, "rate": 150, "tax_rate": 5}])
    finance = FinanceService(conn, OWNER)
    finance.record_expense("Electricity", 500)
    s = finance.summary()
    assert s["revenue"] == 630
    assert s["expense"] == 500
    assert s["profit"] == 130


def test_sales_order_to_picking_to_invoice_issues_stock_atomically(conn):
    ids = _setup_masters(conn)
    conn.execute(
        "INSERT INTO stock_movements (item_type, item_id, movement_type, quantity, created_by) "
        "VALUES ('sku', ?, 'Opening', '10', 'test')", (ids['sku_id'],))
    conn.commit()

    sales = SalesService(conn, OWNER)
    order_id, order_no = sales.create_sales_order(ids['cust_id'], [
        {'sku_id': ids['sku_id'], 'quantity': 4, 'rate': 150, 'tax_rate': 5}
    ])
    assert order_no.startswith('SO-')
    assert conn.execute('SELECT status FROM sales_orders WHERE id=?', (order_id,)).fetchone()[0] == 'Draft'

    sales.confirm_sales_order(order_id)
    assert conn.execute('SELECT status FROM sales_orders WHERE id=?', (order_id,)).fetchone()[0] == 'Confirmed'

    sales.pick_sales_order(order_id)
    assert conn.execute('SELECT status FROM sales_orders WHERE id=?', (order_id,)).fetchone()[0] == 'Picked'
    assert sales.inv_repo.get_balance('sku', ids['sku_id']) == 10

    invoice_id, invoice_no, total = sales.create_invoice_from_order(order_id)
    assert invoice_no.startswith('INV-')
    assert total == 630
    assert sales.inv_repo.get_balance('sku', ids['sku_id']) == 6
    row = conn.execute('SELECT status,invoice_id FROM sales_orders WHERE id=?', (order_id,)).fetchone()
    assert row['status'] == 'Invoiced'
    assert row['invoice_id'] == invoice_id
    assert conn.execute('SELECT sales_order_id FROM sales_invoices WHERE id=?', (invoice_id,)).fetchone()[0] == order_id


def test_sales_order_confirmation_blocks_insufficient_stock(conn):
    ids = _setup_masters(conn)
    conn.execute(
        "INSERT INTO stock_movements (item_type, item_id, movement_type, quantity, created_by) "
        "VALUES ('sku', ?, 'Opening', '2', 'test')", (ids['sku_id'],))
    conn.commit()

    sales = SalesService(conn, OWNER)
    order_id, _ = sales.create_sales_order(ids['cust_id'], [
        {'sku_id': ids['sku_id'], 'quantity': 4, 'rate': 150, 'tax_rate': 5}
    ])
    import pytest
    with pytest.raises(Exception):
        sales.confirm_sales_order(order_id)
    assert conn.execute('SELECT status FROM sales_orders WHERE id=?', (order_id,)).fetchone()[0] == 'Draft'
    assert sales.inv_repo.get_balance('sku', ids['sku_id']) == 2
