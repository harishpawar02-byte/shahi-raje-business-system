import sys
import sqlite3
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from database.migrations.migration_manager import VERSIONS_DIR  # noqa: E402


@pytest.fixture
def conn():
    c = sqlite3.connect(":memory:")
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    for f in sorted(VERSIONS_DIR.glob("v*.sql")):
        c.executescript(f.read_text(encoding="utf-8"))
    yield c
    c.close()
