from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PAGES = ROOT / 'pages'


def test_pages_do_not_execute_sql_directly():
    import re
    sql_patterns = [
        re.compile(r"[\'\"]SELECT\s+[^\n]+\s+FROM\s+", re.I),
        re.compile(r"[\'\"]INSERT\s+INTO\s+", re.I),
        re.compile(r"[\'\"]UPDATE\s+\w+\s+SET\s+", re.I),
        re.compile(r"[\'\"]DELETE\s+FROM\s+", re.I),
    ]
    for path in PAGES.glob('*.py'):
        text = path.read_text(encoding='utf-8')
        assert not any(p.search(text) for p in sql_patterns), f'Direct SQL found in {path.name}'
        assert '.execute(' not in text.lower(), f'Direct DB execute found in {path.name}'


def test_pages_use_common_numbered_table_renderer():
    for path in PAGES.glob('*.py'):
        text = path.read_text(encoding='utf-8')
        if 'dataframe' in text:
            raise AssertionError(f'Use display_table() instead of st.dataframe() in {path.name}')


def test_reports_recipe_api_and_ui_renderer_exist():
    service = (ROOT / 'services' / 'mis_service.py').read_text(encoding='utf-8')
    reports = (PAGES / '13_Settings_Reports.py').read_text(encoding='utf-8')
    assert 'def all_recipes' in service
    assert 'svc.all_recipes()' in reports
    assert 'display_table' in reports
