def test_all_recipes_and_master_sequences(conn):
    user={"username":"owner","role":"Owner"}
    from services.mis_service import MISService
    svc = MISService(conn, user)
    recipes = svc.all_recipes()
    assert isinstance(recipes, list)
    ids = [r["id"] for r in svc.products(active_only=False)]
    assert ids == sorted(ids)
    ids = [r["id"] for r in svc.raw_materials(active_only=False)]
    assert ids == sorted(ids)

def test_sequential_rows_helper():
    from core.sequence import sequential_rows
    rows = [{"id": 9, "name": "B"}, {"id": 2, "name": "A"}]
    out = list(sequential_rows(rows))
    assert [x["id"] for x in out] == [2, 9]
    assert [x["Sr. No."] for x in out] == [1, 2]

def test_production_skus_include_display_fields(conn):
    from services.mis_service import MISService
    user={"username":"owner","role":"Owner"}
    svc=MISService(conn,user)
    product=conn.execute("INSERT INTO products(name) VALUES('Production UI Product')").lastrowid
    sku=conn.execute(
        "INSERT INTO skus(product_id,sku_code,pack_size,unit_id) VALUES(?,?,?,?)",
        (product,'PUI-100','100g',2),
    ).lastrowid
    conn.commit()
    rows=svc.production_skus(product)
    assert len(rows)==1
    assert rows[0]["id"]==sku
    assert rows[0]["sku_code"]=='PUI-100'
    assert rows[0]["product_name"]=='Production UI Product'
    assert rows[0]["unit_name"]=='g'
