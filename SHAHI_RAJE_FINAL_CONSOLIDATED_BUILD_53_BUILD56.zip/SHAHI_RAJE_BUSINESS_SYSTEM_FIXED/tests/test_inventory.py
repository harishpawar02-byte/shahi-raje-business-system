"""
Phase 1 tests — rule #16. Run with:  pytest tests/
"""
import pytest
from database.repositories.inventory_repository import InventoryRepository
from core.exceptions import InsufficientStockError


def _make_raw_material(conn, name="Chilli Powder"):
    cur = conn.execute(
        "INSERT INTO raw_materials (name, unit_id, reorder_level) VALUES (?,?,?)",
        (name, 1, "50"))
    conn.commit()
    return cur.lastrowid


def test_purchase_increases_stock(conn):
    repo = InventoryRepository(conn)
    rid = _make_raw_material(conn)
    repo.record_movement(item_type="raw_material", item_id=rid,
                          movement_type="Purchase", quantity=50, user="test")
    assert repo.get_balance("raw_material", rid) == 50


def test_sale_decreases_stock(conn):
    repo = InventoryRepository(conn)
    rid = _make_raw_material(conn)
    repo.record_movement(item_type="raw_material", item_id=rid,
                          movement_type="Opening", quantity=100, user="test")
    repo.record_movement(item_type="raw_material", item_id=rid,
                          movement_type="Sales", quantity=-20, user="test")
    assert repo.get_balance("raw_material", rid) == 80


def test_negative_stock_blocked(conn):
    repo = InventoryRepository(conn)
    rid = _make_raw_material(conn)
    repo.record_movement(item_type="raw_material", item_id=rid,
                          movement_type="Opening", quantity=10, user="test")
    with pytest.raises(InsufficientStockError):
        repo.record_movement(item_type="raw_material", item_id=rid,
                              movement_type="Sales", quantity=-20, user="test")


def test_fefo_orders_by_nearest_expiry(conn):
    repo = InventoryRepository(conn)
    rid = _make_raw_material(conn, "Turmeric")
    b1 = repo.create_batch(batch_number="TUR-001", item_type="raw_material",
                            item_id=rid, expiry_date="2027-06-01")
    b2 = repo.create_batch(batch_number="TUR-002", item_type="raw_material",
                            item_id=rid, expiry_date="2027-01-01")
    repo.record_movement(item_type="raw_material", item_id=rid, batch_id=b1,
                          movement_type="Opening", quantity=10, user="test")
    repo.record_movement(item_type="raw_material", item_id=rid, batch_id=b2,
                          movement_type="Opening", quantity=15, user="test")
    order = repo.fefo_batches("raw_material", rid)
    assert order[0]["batch_number"] == "TUR-002"  # earlier expiry first


def test_safe_transfer_preserves_batch(conn):
    from services.inventory_service import InventoryService
    repo = InventoryRepository(conn)
    rid = _make_raw_material(conn, 'Transfer Test RM')
    b = repo.create_batch(batch_number='TR-001', item_type='raw_material', item_id=rid, expiry_date='2027-12-01')
    repo.record_movement(item_type='raw_material', item_id=rid, batch_id=b, movement_type='Opening', quantity=25, user='test')
    conn.execute("INSERT INTO warehouses(code,name,branch) VALUES('WH-TEST','Test Warehouse','Test')")
    conn.commit()
    wid = conn.execute("SELECT id FROM warehouses WHERE code='WH-TEST'").fetchone()[0]
    inv = InventoryService(conn, {'username':'owner','role':'Owner'})
    inv.transfer(item_type='raw_material', item_id=rid, quantity=10, source_warehouse_id=None, destination_warehouse_id=wid, batch_id=b, reference='TR-TEST')
    assert repo.get_unassigned_balance('raw_material', rid, b) == 15
    assert repo.get_balance('raw_material', rid, wid, b) == 10
    rows = conn.execute("SELECT movement_type, quantity, batch_id, warehouse_id FROM stock_movements WHERE reference='TR-TEST' ORDER BY id").fetchall()
    assert len(rows) == 2
    assert rows[0][0] == 'Transfer OUT' and rows[0][1] == '-10.000'
    assert rows[1][0] == 'Transfer IN' and rows[1][1] == '10.000'
