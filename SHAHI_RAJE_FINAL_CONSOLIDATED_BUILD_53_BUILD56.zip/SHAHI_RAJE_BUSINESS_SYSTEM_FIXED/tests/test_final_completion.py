from pathlib import Path
from services.auth_service import authenticate, change_password, hash_password
from services.production_service import ProductionService
from services.sales_service import SalesService
from services.purchase_service import PurchaseService
from database.repositories.inventory_repository import InventoryRepository
from core.exceptions import ValidationError

OWNER={'username':'owner','role':'Owner','id':1}

def test_password_change_roundtrip(conn):
    conn.execute("UPDATE users SET password_hash=?,password_scheme='pbkdf2_sha256',password_change_required=1 WHERE username='owner'",(hash_password('OldPass123!'),));conn.commit()
    change_password(conn,1,'OldPass123!','NewPass123!')
    assert authenticate(conn,'owner','NewPass123!')['role']=='Owner'
    assert conn.execute("SELECT password_change_required FROM users WHERE id=1").fetchone()[0]==0

def test_recipe_versions_are_immutable_and_new_version_is_additive(conn):
    p=conn.execute("INSERT INTO products(name) VALUES('Masala')").lastrowid
    rm=conn.execute("INSERT INTO raw_materials(name,unit_id,reorder_level) VALUES('Chilli',1,'1')").lastrowid;conn.commit()
    svc=ProductionService(conn,OWNER);rid,v=svc.create_recipe_version(p,[{'raw_material_id':rm,'quantity_per_batch':'1'}])
    rid2,v2=svc.create_recipe_version(p,[{'raw_material_id':rm,'quantity_per_batch':'2'}])
    assert (v,v2)==(1,2)
    assert conn.execute('SELECT quantity_per_batch FROM recipe_items WHERE recipe_id=?',(rid,)).fetchone()[0]=='1.000'
    assert conn.execute('SELECT is_active FROM recipes WHERE id=?',(rid,)).fetchone()[0]==0

def test_qc_pending_then_approval_posts_finished_stock(conn):
    p=conn.execute("INSERT INTO products(name) VALUES('Garam')").lastrowid
    rm=conn.execute("INSERT INTO raw_materials(name,unit_id,reorder_level) VALUES('Chilli2',1,'1')").lastrowid
    sku=conn.execute("INSERT INTO skus(product_id,sku_code,pack_size,unit_id,selling_price,mrp,standard_cost,tax_rate,reorder_level) VALUES(?,?,?,?,?,?,?,?,?)",(p,'GAR-100','100g',2,'100','100','50','5','1')).lastrowid
    inv=InventoryRepository(conn);inv.record_movement(item_type='raw_material',item_id=rm,movement_type='Opening',quantity=10,user='owner')
    prod=ProductionService(conn,OWNER);recipe,_=prod.create_recipe_version(p,[{'raw_material_id':rm,'quantity_per_batch':1}]);oid,_,_=prod.plan_production(p,recipe,2,{rm:10},sku)
    bid,_,_=prod.consume_and_produce(production_order_id=oid,product_id=p,output_sku_id=sku,consumptions=[{'raw_material_id':rm,'quantity':2,'rate':10}],output_batch_number='GAR-B1',output_qty=2,qc_status='Pending')
    assert inv.get_balance('sku',sku)==0
    prod.approve_qc(bid,'Passed after inspection')
    assert inv.get_balance('sku',sku)==2

def test_sales_batch_traceability_and_cancel_are_append_only(conn):
    p=conn.execute("INSERT INTO products(name) VALUES('Biryani')").lastrowid
    sku=conn.execute("INSERT INTO skus(product_id,sku_code,pack_size,unit_id,selling_price,mrp,standard_cost,tax_rate,reorder_level) VALUES(?,?,?,?,?,?,?,?,?)",(p,'BRY-100','100g',2,'100','100','50','5','1')).lastrowid
    cust=conn.execute("INSERT INTO customers(name,customer_type) VALUES('Retailer','Retailer')").lastrowid
    inv=InventoryRepository(conn);b=inv.create_batch(batch_number='BRY-B1',item_type='sku',item_id=sku,expiry_date='2027-01-01');conn.execute("UPDATE batches SET qc_status='Passed',saleable=1 WHERE id=?",(b,));conn.commit();inv.record_movement(item_type='sku',item_id=sku,batch_id=b,movement_type='Opening',quantity=5,user='owner')
    sales=SalesService(conn,OWNER);iid,_,total=sales.create_invoice(cust,[{'sku_id':sku,'quantity':2,'rate':100,'tax_rate':5}])
    assert conn.execute('SELECT batch_id FROM sales_invoice_items WHERE invoice_id=?',(iid,)).fetchone()[0]==b
    sales.cancel_invoice(iid,'Customer cancelled order')
    assert conn.execute('SELECT status FROM sales_invoices WHERE id=?',(iid,)).fetchone()[0]=='Cancelled'
    movements=conn.execute("SELECT movement_type,quantity FROM stock_movements WHERE reference LIKE 'INV-%' ORDER BY id").fetchall()
    assert [m[0] for m in movements]==['Sales','SalesReturn']

def test_mis_service_exposes_recipe_report_and_numbered_navigation():
    from services.mis_service import MISService
    assert hasattr(MISService, 'all_recipes')
    app_text = (Path(__file__).resolve().parents[1] / 'app.py').read_text(encoding='utf-8')
    expected = [
        '01 Dashboard', '02 Products & SKU', '03 Raw Materials', '04 Inventory',
        '05 Suppliers & Customers', '06 Backup, Settings & Security', '07 Purchase',
        '08 Production', '09 Sales', '10 Finance', '11 HR & Admin',
        '12 AI Agents', '13 Reports & System Control'
    ]
    assert all(label in app_text for label in expected)
    assert 'st.navigation(pages, position=\'sidebar\')' in app_text
