from core.audit import write_audit

class NotificationService:
    def __init__(self,conn,user=None):self.conn=conn;self.user=user or {'username':'system','role':'Owner'}
    def push(self,notif_type,message,entity=None,entity_id=None,priority='Normal',user_id=None):
        self.conn.execute('INSERT INTO notifications(notif_type,message,entity,entity_id,priority,user_id) VALUES(?,?,?,?,?,?)',(notif_type,message,entity,str(entity_id) if entity_id is not None else None,priority,user_id));self.conn.commit()
    def unread(self,user_id=None):
        q='SELECT * FROM notifications WHERE is_read=0';p=[]
        if user_id is not None:q+=' AND (user_id IS NULL OR user_id=?)';p.append(user_id)
        return self.conn.execute(q+' ORDER BY CASE priority WHEN "High" THEN 0 WHEN "Normal" THEN 1 ELSE 2 END,id DESC',p).fetchall()
    def mark_read(self,id_):self.conn.execute('UPDATE notifications SET is_read=1 WHERE id=?',(id_,));self.conn.commit()
    def refresh(self):
        lows=self.conn.execute('''SELECT rm.id,rm.name,COALESCE(SUM(CAST(sm.quantity AS REAL)),0) balance,CAST(rm.reorder_level AS REAL) reorder_level FROM raw_materials rm LEFT JOIN stock_movements sm ON sm.item_type='raw_material' AND sm.item_id=rm.id WHERE rm.is_active=1 GROUP BY rm.id HAVING balance<=reorder_level''').fetchall()
        for r in lows:
            exists=self.conn.execute("SELECT 1 FROM notifications WHERE notif_type='LowStock' AND entity='raw_material' AND entity_id=? AND is_read=0",(str(r['id']),)).fetchone()
            if not exists:self.push('LowStock',f"{r['name']}: stock {r['balance']:.2f} is at/below reorder level {r['reorder_level']:.2f}.",'raw_material',r['id'],'High')
        return len(lows)
