from datetime import date, datetime
from core.permissions import require_permission
from core.money import to_qty, to_money
from core.audit import write_audit
from core.exceptions import ValidationError, InsufficientStockError
from database.repositories.inventory_repository import InventoryRepository


class SalesService:
    """Sales application service.

    Supports both the legacy direct invoice path and the controlled
    Sales Order -> Stock Check -> Picking -> Invoice + Stock Issue path.
    Stock is changed only by the invoice/stock-issue transaction.
    """

    def __init__(self, conn, current_user):
        self.conn, self.user = conn, current_user
        self.inv_repo = InventoryRepository(conn)

    # ---------- Sales Order workflow ----------
    def create_sales_order(self, customer_id, line_items, warehouse_id=None,
                           tax_type='GST', place_of_supply=None, notes=None):
        require_permission(self.user['role'], 'Create')
        if not line_items:
            raise ValidationError('At least one sales order line is required')
        self._validate_customer(customer_id)
        normalized = self._normalize_lines(line_items)
        try:
            self.conn.execute('BEGIN')
            order_number = f"SO-{date.today():%Y%m%d}-{self._next_order_seq():03d}"
            cur = self.conn.execute(
                '''INSERT INTO sales_orders
                   (order_number,customer_id,warehouse_id,status,tax_type,place_of_supply,notes,created_by)
                   VALUES(?,?,?,?,?,?,?,?)''',
                (order_number, customer_id, warehouse_id, 'Draft', tax_type,
                 place_of_supply, notes, self.user['username']))
            order_id = cur.lastrowid
            for li in normalized:
                self.conn.execute(
                    '''INSERT INTO sales_order_items
                       (sales_order_id,sku_id,quantity,rate,tax_rate)
                       VALUES(?,?,?,?,?)''',
                    (order_id, li['sku_id'], str(li['quantity']), str(li['rate']), str(li['tax_rate'])))
            write_audit(self.conn, user=self.user['username'], action='sales_order:create',
                        entity='sales_order', entity_id=order_id,
                        after={'order_number': order_number, 'customer_id': customer_id}, commit=False)
            self.conn.commit()
            return order_id, order_number
        except Exception:
            self.conn.rollback()
            raise

    def sales_orders(self, statuses=None, limit=200):
        limit = max(1, min(int(limit), 5000))
        q = '''SELECT so.*, c.name AS customer_name, w.name AS warehouse_name,
                       si.invoice_number
                FROM sales_orders so
                JOIN customers c ON c.id=so.customer_id
                LEFT JOIN warehouses w ON w.id=so.warehouse_id
                LEFT JOIN sales_invoices si ON si.id=so.invoice_id'''
        params = []
        if statuses:
            marks = ','.join('?' for _ in statuses)
            q += f' WHERE so.status IN ({marks})'
            params.extend(statuses)
        q += ' ORDER BY so.id DESC LIMIT ?'
        params.append(limit)
        return self.conn.execute(q, params).fetchall()

    def sales_order_items(self, order_id):
        return self.conn.execute(
            '''SELECT soi.*, s.sku_code, p.name AS product_name
               FROM sales_order_items soi
               JOIN skus s ON s.id=soi.sku_id
               JOIN products p ON p.id=s.product_id
               WHERE soi.sales_order_id=? ORDER BY soi.id''',
            (order_id,)).fetchall()

    def stock_check_order(self, order_id):
        order = self._get_order(order_id)
        results = []
        ok = True
        for item in self.sales_order_items(order_id):
            requested = to_qty(item['quantity'])
            available = self.inv_repo.get_balance('sku', item['sku_id'], order['warehouse_id'])
            short = max(to_qty(0), requested - available)
            row = dict(item)
            row.update(requested=requested, available=available, short=short, sufficient=short == 0)
            results.append(row)
            ok = ok and short == 0
        return ok, results

    def confirm_sales_order(self, order_id):
        require_permission(self.user['role'], 'Approve')
        order = self._get_order(order_id)
        if order['status'] != 'Draft':
            raise ValidationError('Only Draft sales orders can be confirmed')
        ok, _ = self.stock_check_order(order_id)
        if not ok:
            raise InsufficientStockError('Sales order cannot be confirmed because stock is insufficient')
        self.conn.execute("UPDATE sales_orders SET status='Confirmed',confirmed_at=datetime('now') WHERE id=?", (order_id,))
        write_audit(self.conn, user=self.user['username'], action='sales_order:confirm',
                    entity='sales_order', entity_id=order_id,
                    after={'status': 'Confirmed'})

    def pick_sales_order(self, order_id):
        require_permission(self.user['role'], 'Create')
        order = self._get_order(order_id)
        if order['status'] != 'Confirmed':
            raise ValidationError('Only Confirmed sales orders can be picked')
        ok, results = self.stock_check_order(order_id)
        if not ok:
            raise InsufficientStockError('Picking blocked because available stock is insufficient')
        try:
            self.conn.execute('BEGIN')
            for row in results:
                qty = to_qty(row['requested'])
                self.conn.execute(
                    'INSERT INTO sales_order_picks(sales_order_id,sales_order_item_id,quantity,picked_by) VALUES(?,?,?,?)',
                    (order_id, row['id'], str(qty), self.user['username']))
                self.conn.execute('UPDATE sales_order_items SET picked_quantity=? WHERE id=?',
                                  (str(qty), row['id']))
            self.conn.execute("UPDATE sales_orders SET status='Picked',picked_at=datetime('now') WHERE id=?", (order_id,))
            write_audit(self.conn, user=self.user['username'], action='sales_order:pick',
                        entity='sales_order', entity_id=order_id,
                        after={'status': 'Picked'}, commit=False)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def create_invoice_from_order(self, order_id):
        require_permission(self.user['role'], 'Create')
        order = self._get_order(order_id)
        if order['status'] != 'Picked':
            raise ValidationError('Only Picked sales orders can be invoiced')
        items = self.sales_order_items(order_id)
        lines = [{'sku_id': x['sku_id'], 'quantity': x['quantity'], 'rate': x['rate'], 'tax_rate': x['tax_rate']} for x in items]
        try:
            self.conn.execute('BEGIN')
            invoice_id, invoice_number, total = self._create_invoice_tx(
                order['customer_id'], lines, warehouse_id=order['warehouse_id'],
                tax_type=order['tax_type'], place_of_supply=order['place_of_supply'],
                sales_order_id=order_id)
            self.conn.execute("UPDATE sales_orders SET status='Invoiced',invoice_id=? WHERE id=?", (invoice_id, order_id))
            write_audit(self.conn, user=self.user['username'], action='sales_order:invoice',
                        entity='sales_order', entity_id=order_id,
                        after={'status': 'Invoiced', 'invoice_id': invoice_id}, commit=False)
            self.conn.commit()
            return invoice_id, invoice_number, total
        except Exception:
            self.conn.rollback()
            raise

    # ---------- Invoice / stock issue ----------
    def create_invoice(self, customer_id, line_items, warehouse_id=None, tax_type='GST', place_of_supply=None):
        require_permission(self.user['role'], 'Create')
        if not line_items:
            raise ValidationError('At least one invoice line is required')
        self._validate_customer(customer_id)
        try:
            self.conn.execute('BEGIN')
            result = self._create_invoice_tx(customer_id, line_items, warehouse_id, tax_type, place_of_supply)
            self.conn.commit()
            return result
        except Exception:
            self.conn.rollback()
            raise

    def _create_invoice_tx(self, customer_id, line_items, warehouse_id=None, tax_type='GST', place_of_supply=None,
                           sales_order_id=None):
        normalized = self._normalize_lines(line_items)
        invoice_number = f"INV-{date.today():%Y%m%d}-{self._next_seq():03d}"
        cur = self.conn.execute(
            '''INSERT INTO sales_invoices
               (invoice_number,customer_id,warehouse_id,tax_type,place_of_supply,sales_order_id,created_by)
               VALUES(?,?,?,?,?,?,?)''',
            (invoice_number, customer_id, warehouse_id, tax_type, place_of_supply, sales_order_id, self.user['username']))
        invoice_id = cur.lastrowid
        subtotal = to_money(0)
        tax_total = to_money(0)
        for li in normalized:
            sku_id = li['sku_id']; qty = li['quantity']; rate = li['rate']; tax_rate = li['tax_rate']
            sku = self.conn.execute('SELECT id,is_active FROM skus WHERE id=?', (sku_id,)).fetchone()
            if not sku or not sku['is_active']:
                raise ValidationError('SKU is not active')
            allocations = self._allocate_fefo(sku_id, qty, warehouse_id)
            line_subtotal = qty * rate
            line_tax = line_subtotal * tax_rate / to_money(100)
            subtotal += line_subtotal
            tax_total += line_tax
            remaining = qty
            for batch_id, alloc in allocations:
                alloc_sub = alloc * rate
                alloc_tax = alloc_sub * tax_rate / to_money(100)
                intra = tax_type in ('GST', 'Intra-State')
                inter = tax_type == 'Inter-State'
                self.conn.execute(
                    '''INSERT INTO sales_invoice_items
                       (invoice_id,sku_id,batch_id,quantity,rate,tax_rate,line_total,cgst_amount,sgst_amount,igst_amount,tax_type)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
                    (invoice_id, sku_id, batch_id, str(alloc), str(rate), str(tax_rate), str(alloc_sub + alloc_tax),
                     str(alloc_tax / 2 if intra else to_money(0)),
                     str(alloc_tax / 2 if intra else to_money(0)),
                     str(alloc_tax if inter else to_money(0)), tax_type))
                # This is the stock-issue ledger entry. It is append-only and atomic with the invoice.
                self.inv_repo.record_movement(
                    item_type='sku', item_id=sku_id, movement_type='Sales', quantity=-alloc,
                    batch_id=batch_id, warehouse_id=warehouse_id, reference=invoice_number,
                    user=self.user['username'], source='sales_invoice', commit=False)
                remaining -= alloc
            if remaining != 0:
                raise InsufficientStockError('Insufficient saleable stock for SKU')
        total = subtotal + tax_total
        self.conn.execute('UPDATE sales_invoices SET subtotal=?,tax_amount=?,total=? WHERE id=?',
                          (str(subtotal), str(tax_total), str(total), invoice_id))
        self.conn.execute(
            'INSERT INTO customer_receivables(customer_id,invoice_id,amount,entry_type,reference) VALUES(?,?,?,?,?)',
            (customer_id, invoice_id, str(total), 'Invoice', invoice_number))
        self.conn.execute(
            "INSERT INTO transactions(txn_type,category,amount,reference,created_by,tax_amount,source_type,source_id) VALUES('Sale','Revenue',?,?,?,?,?,?)",
            (str(total), invoice_number, self.user['username'], str(tax_total), 'Invoice', str(invoice_id)))
        write_audit(self.conn, user=self.user['username'], action='invoice:create', entity='sales_invoice',
                    entity_id=invoice_id,
                    after={'invoice_number': invoice_number, 'total': str(total), 'sales_order_id': sales_order_id},
                    commit=False)
        return invoice_id, invoice_number, total

    def _normalize_lines(self, line_items):
        out = []
        for li in line_items:
            try:
                sku_id = int(li['sku_id']); qty = to_qty(li['quantity']); rate = to_money(li['rate'])
                tax_rate = to_money(li.get('tax_rate', 0))
            except (KeyError, TypeError, ValueError) as e:
                raise ValidationError(f'Invalid sales line: {e}')
            if qty <= 0:
                raise ValidationError('Quantity must be positive')
            if rate < 0 or tax_rate < 0:
                raise ValidationError('Rate and tax rate cannot be negative')
            out.append({'sku_id': sku_id, 'quantity': qty, 'rate': rate, 'tax_rate': tax_rate})
        return out

    def _validate_customer(self, customer_id):
        row = self.conn.execute('SELECT id,is_active FROM customers WHERE id=?', (customer_id,)).fetchone()
        if not row or not row['is_active']:
            raise ValidationError('Customer is not active')

    def _get_order(self, order_id):
        row = self.conn.execute('SELECT * FROM sales_orders WHERE id=?', (order_id,)).fetchone()
        if not row:
            raise ValidationError('Sales order not found')
        return row

    def _allocate_fefo(self, sku_id, qty, warehouse_id):
        batches = self.inv_repo.fefo_batches('sku', sku_id, warehouse_id)
        remaining = to_qty(qty)
        out = []
        for b in batches:
            take = min(remaining, to_qty(b['balance']))
            if take > 0:
                out.append((b['batch_id'], take)); remaining -= take
            if remaining <= 0: break
        # Legacy/unbatched opening stock is allowed; new production stock is batch/QC controlled.
        if remaining > 0:
            row = self.inv_repo.get_balance('sku', sku_id, warehouse_id, None)
            q = "SELECT COALESCE(SUM(CAST(quantity AS DECIMAL)),0) FROM stock_movements WHERE item_type='sku' AND item_id=? AND batch_id IS NOT NULL"
            params = [sku_id]
            if warehouse_id is not None:
                q += ' AND warehouse_id=?'; params.append(warehouse_id)
            batched = self.conn.execute(q, params).fetchone()[0]
            unbatched = to_qty(row) - to_qty(batched)
            if unbatched >= remaining:
                out.append((None, remaining)); remaining = to_qty(0)
        if remaining > 0:
            raise InsufficientStockError(f'Insufficient saleable stock for SKU {sku_id} (short {remaining})')
        return out

    def _next_seq(self):
        row = self.conn.execute("SELECT COUNT(*) c FROM sales_invoices WHERE invoice_date=date('now')").fetchone()
        return row['c'] + 1

    def _next_order_seq(self):
        row = self.conn.execute("SELECT COUNT(*) c FROM sales_orders WHERE date(created_at)=date('now')").fetchone()
        return row['c'] + 1

    # ---------- Payments / receivables ----------
    def record_payment(self, customer_id, invoice_id, amount, reference=None, payment_mode=None):
        require_permission(self.user['role'], 'Create')
        amt = to_money(amount)
        if amt <= 0:
            raise ValidationError('Payment must be positive')
        invoice = self.conn.execute('SELECT customer_id,status FROM sales_invoices WHERE id=?', (invoice_id,)).fetchone()
        if not invoice or invoice['customer_id'] != customer_id:
            raise ValidationError('Invoice does not belong to this customer')
        if invoice['status'] != 'Issued':
            raise ValidationError('Payment can only be recorded against an issued invoice')
        outstanding = self.outstanding_invoice(invoice_id)
        if amt > outstanding:
            raise ValidationError(f'Payment exceeds invoice outstanding ({outstanding})')
        try:
            self.conn.execute('BEGIN')
            self.conn.execute(
                'INSERT INTO customer_receivables(customer_id,invoice_id,amount,entry_type,reference) VALUES(?,?,?,?,?)',
                (customer_id, invoice_id, str(-amt), 'Payment', reference))
            self.conn.execute(
                "INSERT INTO payment_allocations(ledger_type,ledger_id,amount,payment_reference,created_by) VALUES('receivable',?,?,?,?)",
                (invoice_id, str(amt), reference, self.user['username']))
            self.conn.execute(
                "INSERT INTO transactions(txn_type,category,amount,reference,created_by,payment_mode,source_type,source_id) VALUES('Payment-In','Receivable',?,?,?,?,?,?)",
                (str(amt), reference, self.user['username'], payment_mode, 'CustomerPayment', str(invoice_id)))
            write_audit(self.conn, user=self.user['username'], action='payment:receive',
                        entity='customer_receivable', entity_id=invoice_id,
                        after={'amount': str(amt), 'payment_mode': payment_mode}, commit=False)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def outstanding_invoice(self, invoice_id):
        row = self.conn.execute(
            "SELECT COALESCE(SUM(CAST(amount AS DECIMAL)),0) bal FROM customer_receivables WHERE invoice_id=?",
            (invoice_id,)).fetchone()
        return to_money(row['bal'])

    def outstanding_balance(self, customer_id):
        row = self.conn.execute(
            "SELECT COALESCE(SUM(CAST(amount AS DECIMAL)),0) bal FROM customer_receivables WHERE customer_id=?",
            (customer_id,)).fetchone()
        return to_money(row['bal'])

    # ---------- Cancellation (append-only stock reversal) ----------
    def cancel_invoice(self, invoice_id, reason):
        require_permission(self.user['role'], 'Cancel')
        if not reason or len(reason.strip()) < 5:
            raise ValidationError('Cancellation reason is required')
        inv = self.conn.execute('SELECT * FROM sales_invoices WHERE id=?', (invoice_id,)).fetchone()
        if not inv or inv['status'] != 'Issued':
            raise ValidationError('Only an issued invoice can be cancelled')
        try:
            self.conn.execute('BEGIN')
            items = self.conn.execute('SELECT * FROM sales_invoice_items WHERE invoice_id=?', (invoice_id,)).fetchall()
            for it in items:
                self.inv_repo.record_movement(
                    item_type='sku', item_id=it['sku_id'], movement_type='SalesReturn', quantity=to_qty(it['quantity']),
                    batch_id=it['batch_id'], warehouse_id=inv['warehouse_id'], reference=inv['invoice_number'],
                    user=self.user['username'], source='cancellation', commit=False)
            self.conn.execute("UPDATE sales_invoices SET status='Cancelled' WHERE id=?", (invoice_id,))
            self.conn.execute(
                'INSERT INTO customer_receivables(customer_id,invoice_id,amount,entry_type,reference) VALUES(?,?,?,?,?)',
                (inv['customer_id'], invoice_id, str(-to_money(inv['total'])), 'InvoiceCancellation', reason))
            self.conn.execute(
                "INSERT INTO transactions(txn_type,category,amount,reference,created_by,source_type,source_id) VALUES('Sale-Cancellation','Revenue',?,?,?,?,?)",
                (str(to_money(inv['total'])), reason, self.user['username'], 'InvoiceCancellation', str(invoice_id)))
            write_audit(self.conn, user=self.user['username'], action='invoice:cancel', entity='sales_invoice',
                        entity_id=invoice_id, before=dict(inv), after={'status': 'Cancelled'}, reason=reason, commit=False)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
