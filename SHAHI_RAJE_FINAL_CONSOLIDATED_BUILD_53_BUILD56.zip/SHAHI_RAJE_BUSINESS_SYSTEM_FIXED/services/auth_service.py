import hashlib
import hmac
import secrets
from core.permissions import require_permission

PBKDF2_ITERATIONS = 310000


def hash_password(raw: str) -> str:
    if not isinstance(raw, str) or len(raw) < 8:
        raise ValueError("Password must contain at least 8 characters")
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", raw.encode("utf-8"), bytes.fromhex(salt), PBKDF2_ITERATIONS).hex()
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${salt}${digest}"


def _verify(raw: str, stored: str) -> tuple[bool, bool]:
    """Return (valid, legacy_sha256)."""
    if stored.startswith("pbkdf2_sha256$"):
        try:
            _, iterations, salt, expected = stored.split("$", 3)
            actual = hashlib.pbkdf2_hmac("sha256", raw.encode("utf-8"), bytes.fromhex(salt), int(iterations)).hex()
            return hmac.compare_digest(actual, expected), False
        except (ValueError, TypeError):
            return False, False
    legacy = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return hmac.compare_digest(legacy, stored), True


def authenticate(conn, username: str, password: str):
    row = conn.execute("SELECT * FROM users WHERE username=? AND is_active=1", (username.strip(),)).fetchone()
    if not row:
        return None
    valid, legacy = _verify(password, row["password_hash"])
    if not valid:
        return None
    # Transparently upgrade legacy hashes after a successful login.
    if legacy:
        upgraded = hash_password(password)
        conn.execute("UPDATE users SET password_hash=?, password_scheme='pbkdf2_sha256', password_change_required=1 WHERE id=?", (upgraded, row["id"]))
    conn.execute("UPDATE users SET last_login=datetime('now') WHERE id=?", (row["id"],))
    conn.commit()
    return {"id": row["id"], "username": row["username"], "role": row["role"], "password_change_required": bool(row["password_change_required"] or legacy)}


def change_password(conn, user_id: int, current_password: str, new_password: str):
    row = conn.execute("SELECT password_hash FROM users WHERE id=? AND is_active=1", (user_id,)).fetchone()
    if not row:
        raise ValueError("User not found")
    valid, _ = _verify(current_password, row["password_hash"])
    if not valid:
        raise ValueError("Current password is incorrect")
    if current_password == new_password:
        raise ValueError("New password must be different")
    new_hash = hash_password(new_password)
    conn.execute("UPDATE users SET password_hash=?, password_scheme='pbkdf2_sha256', password_change_required=0 WHERE id=?", (new_hash, user_id))
    conn.commit()
