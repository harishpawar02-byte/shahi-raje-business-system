"""Application service layer for masters, reports, settings, tasks and corrections."""
import json
from datetime import date, datetime, timezone
from decimal import Decimal
from core.audit import write_audit
from core.exceptions import ValidationError, DuplicateRecordError, InsufficientStockError
from core.money import to_money, to_qty
from core.permissions import require_permission
from database.repositories.inventory_repository import InventoryRepository

class MISService:
    def __init__(self, conn, user):
        self.conn, self.user = conn, user
        self.inv = InventoryRepository(conn)

    def _user(self): return self.user["username"]

    # ---------- Masters ----------
    def products(self, active_only=True):
        q="SELECT * FROM products" + (" WHERE is_active=1" if active_only else "") + " ORDER BY id"
        return self.conn.execute(q).fetchall()
    def skus(self, active_only=True):
        q="""SELECT s.*,p.name product_name,u.name unit_name FROM skus s JOIN products p ON p.id=s.product_id LEFT JOIN units u ON u.id=s.unit_id"""
        if active_only: q += " WHERE s.is_active=1 AND p.is_active=1"
        return self.conn.execute(q+" ORDER BY s.id").fetchall()
    def raw_materials(self, active_only=True):
        q="""SELECT rm.*,u.name unit_name,s.name supplier_name FROM raw_materials rm LEFT JOIN units u ON u.id=rm.unit_id LEFT JOIN suppliers s ON s.id=rm.preferred_supplier_id"""
        if active_only: q += " WHERE rm.is_active=1"
        return self.conn.execute(q+" ORDER BY rm.id").fetchall()
    def suppliers(self, active_only=True):
        q="SELECT * FROM suppliers" + (" WHERE is_active=1" if active_only else "") + " ORDER BY id"
        return self.conn.execute(q).fetchall()
    def customers(self, active_only=True):
        q="SELECT * FROM customers" + (" WHERE is_active=1" if active_only else "") + " ORDER BY id"
        return self.conn.execute(q).fetchall()
    def units(self): return self.conn.execute("SELECT * FROM units ORDER BY name").fetchall()
    def warehouses(self): return self.conn.execute("SELECT * FROM warehouses WHERE is_active=1 ORDER BY name").fetchall()
    def packaging(self, active_only=True):
        q="SELECT p.*,u.name unit_name FROM packaging_materials p LEFT JOIN units u ON u.id=p.unit_id"
        if active_only: q += " WHERE p.is_active=1"
        return self.conn.execute(q+" ORDER BY p.name").fetchall()

    def _unique(self, table, field, value, exclude_id=None):
        q=f"SELECT id FROM {table} WHERE lower({field})=lower(?)"
        params=[value]
        if exclude_id: q += " AND id<>?"; params.append(exclude_id)
        return self.conn.execute(q,params).fetchone() is not None

    def create_product(self,name,category):
        require_permission(self.user['role'],'Create'); name=name.strip()
        if not name: raise ValidationError('Product name is required')
        if self._unique('products','name',name): raise DuplicateRecordError('Product already exists')
        cur=self.conn.execute('INSERT INTO products(name,category) VALUES(?,?)',(name,category or None)); self.conn.commit()
        write_audit(self.conn,user=self._user(),action='product:create',entity='product',entity_id=cur.lastrowid,after={'name':name,'category':category})
        return cur.lastrowid
    def update_product(self,id_,name,category):
        require_permission(self.user['role'],'Edit'); old=self.conn.execute('SELECT * FROM products WHERE id=?',(id_,)).fetchone()
        if not old: raise ValidationError('Product not found')
        if self._unique('products','name',name.strip(),id_): raise DuplicateRecordError('Product already exists')
        self.conn.execute('UPDATE products SET name=?,category=? WHERE id=?',(name.strip(),category or None,id_)); self.conn.commit()
        write_audit(self.conn,user=self._user(),action='product:update',entity='product',entity_id=id_,before=dict(old),after={'name':name.strip(),'category':category})
    def deactivate(self,table,id_):
        require_permission(self.user['role'],'Edit'); allowed={'products','skus','raw_materials','suppliers','customers','packaging_materials','employees','users'}
        if table not in allowed: raise ValidationError('Unsupported master')
        old=self.conn.execute(f'SELECT * FROM {table} WHERE id=?',(id_,)).fetchone()
        self.conn.execute(f'UPDATE {table} SET is_active=0 WHERE id=?',(id_,)); self.conn.commit()
        write_audit(self.conn,user=self._user(),action=f'{table}:deactivate',entity=table,entity_id=id_,before=dict(old) if old else None,after={'is_active':0})

    def create_sku(self, product_id, code, pack_size, unit_id, barcode, selling_price, mrp, standard_cost, packaging_material_id, tax_rate, reorder_level):
        require_permission(self.user['role'],'Create'); code=code.strip()
        if not code: raise ValidationError('SKU code is required')
        if self._unique('skus','sku_code',code): raise DuplicateRecordError('SKU code already exists')
        cur=self.conn.execute('''INSERT INTO skus(product_id,sku_code,pack_size,unit_id,barcode,selling_price,mrp,standard_cost,packaging_material_id,tax_rate,reorder_level) VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
            (product_id,code,pack_size.strip(),unit_id,barcode.strip() or None,str(to_money(selling_price)),str(to_money(mrp)),str(to_money(standard_cost)),packaging_material_id,str(to_money(tax_rate)),str(to_qty(reorder_level))))
        self.conn.commit(); write_audit(self.conn,user=self._user(),action='sku:create',entity='sku',entity_id=cur.lastrowid,after={'code':code,'product_id':product_id}); return cur.lastrowid

    def create_raw_material(self, code,name,category,unit_id,purchase_unit_id,conversion_factor,reorder,min_level,max_level,supplier_id):
        require_permission(self.user['role'],'Create'); code=code.strip(); name=name.strip()
        if self._unique('raw_materials','name',name): raise DuplicateRecordError('Raw material already exists')
        if self._unique('raw_materials','code',code): raise DuplicateRecordError('Raw material code already exists')
        cur=self.conn.execute('''INSERT INTO raw_materials(code,name,category,unit_id,purchase_unit_id,conversion_factor,reorder_level,min_level,max_level,preferred_supplier_id) VALUES(?,?,?,?,?,?,?,?,?,?)''',
            (code,name,category or None,unit_id,purchase_unit_id or unit_id,str(to_qty(conversion_factor)),str(to_qty(reorder)),str(to_qty(min_level)),str(to_qty(max_level)),supplier_id))
        self.conn.commit(); write_audit(self.conn,user=self._user(),action='raw_material:create',entity='raw_material',entity_id=cur.lastrowid,after={'code':code,'name':name}); return cur.lastrowid

    def create_supplier(self,code,name,contact,email,address,gstin,payment_terms):
        require_permission(self.user['role'],'Create');
        if self._unique('suppliers','name',name): raise DuplicateRecordError('Supplier already exists')
        if self._unique('suppliers','code',code): raise DuplicateRecordError('Supplier code already exists')
        cur=self.conn.execute('INSERT INTO suppliers(code,name,contact,email,address,gstin,payment_terms) VALUES(?,?,?,?,?,?,?)',(code,name,contact,email,address,gstin,payment_terms)); self.conn.commit()
        write_audit(self.conn,user=self._user(),action='supplier:create',entity='supplier',entity_id=cur.lastrowid,after={'code':code,'name':name}); return cur.lastrowid
    def create_customer(self,code,name,ctype,contact,email,address,gstin,payment_terms,credit_limit):
        require_permission(self.user['role'],'Create');
        if self._unique('customers','name',name): raise DuplicateRecordError('Customer already exists')
        if self._unique('customers','code',code): raise DuplicateRecordError('Customer code already exists')
        cur=self.conn.execute('INSERT INTO customers(code,name,customer_type,contact,email,address,gstin,payment_terms,credit_limit) VALUES(?,?,?,?,?,?,?,?,?)',(code,name,ctype,contact,email,address,gstin,payment_terms,str(to_money(credit_limit)))); self.conn.commit()
        write_audit(self.conn,user=self._user(),action='customer:create',entity='customer',entity_id=cur.lastrowid,after={'code':code,'name':name}); return cur.lastrowid
    def create_packaging(self,code,name,category,unit_id,reorder,cost):
        require_permission(self.user['role'],'Create');
        cur=self.conn.execute('INSERT INTO packaging_materials(code,name,category,unit_id,reorder_level,standard_cost) VALUES(?,?,?,?,?,?)',(code,name,category,unit_id,str(to_qty(reorder)),str(to_money(cost)))); self.conn.commit(); return cur.lastrowid


    def update_sku(self,id_,code,pack_size,unit_id,barcode,selling_price,mrp,standard_cost,packaging_material_id,tax_rate,reorder_level):
        require_permission(self.user['role'],'Edit'); old=self.conn.execute('SELECT * FROM skus WHERE id=?',(id_,)).fetchone()
        if not old: raise ValidationError('SKU not found')
        if self._unique('skus','sku_code',code.strip(),id_): raise DuplicateRecordError('SKU code already exists')
        self.conn.execute('''UPDATE skus SET sku_code=?,pack_size=?,unit_id=?,barcode=?,selling_price=?,mrp=?,standard_cost=?,packaging_material_id=?,tax_rate=?,reorder_level=? WHERE id=?''',(code.strip(),pack_size.strip(),unit_id,barcode.strip() or None,str(to_money(selling_price)),str(to_money(mrp)),str(to_money(standard_cost)),packaging_material_id,str(to_money(tax_rate)),str(to_qty(reorder_level)),id_))
        self.conn.commit(); write_audit(self.conn,user=self._user(),action='sku:update',entity='sku',entity_id=id_,before=dict(old),after={'sku_code':code.strip(),'pack_size':pack_size.strip()})

    def update_raw_material(self,id_,code,name,category,unit_id,purchase_unit_id,conversion_factor,reorder,min_level,max_level,supplier_id):
        require_permission(self.user['role'],'Edit'); old=self.conn.execute('SELECT * FROM raw_materials WHERE id=?',(id_,)).fetchone()
        if not old: raise ValidationError('Raw material not found')
        if self._unique('raw_materials','name',name.strip(),id_): raise DuplicateRecordError('Raw material already exists')
        if self._unique('raw_materials','code',code.strip(),id_): raise DuplicateRecordError('Raw material code already exists')
        self.conn.execute('UPDATE raw_materials SET code=?,name=?,category=?,unit_id=?,purchase_unit_id=?,conversion_factor=?,reorder_level=?,min_level=?,max_level=?,preferred_supplier_id=? WHERE id=?',(code.strip(),name.strip(),category or None,unit_id,purchase_unit_id or unit_id,str(to_qty(conversion_factor)),str(to_qty(reorder)),str(to_qty(min_level)),str(to_qty(max_level)),supplier_id,id_));self.conn.commit();write_audit(self.conn,user=self._user(),action='raw_material:update',entity='raw_material',entity_id=id_,before=dict(old),after={'code':code.strip(),'name':name.strip()})

    def update_supplier(self,id_,code,name,contact,email,address,gstin,payment_terms):
        require_permission(self.user['role'],'Edit');old=self.conn.execute('SELECT * FROM suppliers WHERE id=?',(id_,)).fetchone();
        if self._unique('suppliers','name',name.strip(),id_) or self._unique('suppliers','code',code.strip(),id_): raise DuplicateRecordError('Supplier name/code already exists')
        self.conn.execute('UPDATE suppliers SET code=?,name=?,contact=?,email=?,address=?,gstin=?,payment_terms=? WHERE id=?',(code.strip(),name.strip(),contact,email,address,gstin,payment_terms,id_));self.conn.commit();write_audit(self.conn,user=self._user(),action='supplier:update',entity='supplier',entity_id=id_,before=dict(old),after={'code':code.strip(),'name':name.strip()})

    def update_customer(self,id_,code,name,ctype,contact,email,address,gstin,payment_terms,credit_limit):
        require_permission(self.user['role'],'Edit');old=self.conn.execute('SELECT * FROM customers WHERE id=?',(id_,)).fetchone();
        if self._unique('customers','name',name.strip(),id_) or self._unique('customers','code',code.strip(),id_): raise DuplicateRecordError('Customer name/code already exists')
        self.conn.execute('UPDATE customers SET code=?,name=?,customer_type=?,contact=?,email=?,address=?,gstin=?,payment_terms=?,credit_limit=? WHERE id=?',(code.strip(),name.strip(),ctype,contact,email,address,gstin,payment_terms,str(to_money(credit_limit)),id_));self.conn.commit();write_audit(self.conn,user=self._user(),action='customer:update',entity='customer',entity_id=id_,before=dict(old),after={'code':code.strip(),'name':name.strip()})

    # ---------- Inventory correction ----------
    def correct_stock(self, movement_id, corrected_quantity, reason, warehouse_id=None, batch_id=None, allow_negative_override=False):
        require_permission(self.user['role'],'Edit')
        if not reason or len(reason.strip()) < 5: raise ValidationError('Correction reason must be at least 5 characters')
        original=self.conn.execute('SELECT * FROM stock_movements WHERE id=?',(movement_id,)).fetchone()
        if not original: raise ValidationError('Original stock movement not found')
        already=self.conn.execute('SELECT 1 FROM stock_movements WHERE correction_of_id=?',(movement_id,)).fetchone()
        if already: raise ValidationError('This movement already has a correction. Create a separate correction if needed.')
        desired=to_qty(corrected_quantity); old_qty=to_qty(original['quantity']); delta=desired-old_qty
        if delta == 0: raise ValidationError('Correction does not change quantity')
        override = bool(allow_negative_override and self.user['role'] in ('Owner','Admin'))
        projected=self.inv.get_balance(original['item_type'],original['item_id'],original['warehouse_id'],original['batch_id'])+delta
        if projected < 0 and not override: raise InsufficientStockError(f'Correction would make stock negative ({projected})')
        cur=self.conn.execute('''INSERT INTO stock_movements(item_type,item_id,batch_id,warehouse_id,movement_type,quantity,reference,created_by,correction_of_id,correction_reason,approved_by,source) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
            (original['item_type'],original['item_id'],original['batch_id'],warehouse_id if warehouse_id is not None else original['warehouse_id'],'Correction',str(delta),original['reference'],self._user(),movement_id,reason,self._user() if override else None,'correction'))
        write_audit(self.conn,user=self._user(),action='stock:correction',entity=original['item_type'],entity_id=original['item_id'],before={'movement_id':movement_id,'quantity':str(old_qty)},after={'movement_id':cur.lastrowid,'delta':str(delta),'new_effective_quantity':str(desired)},reason=reason,approved_by=self._user() if override else '')
        self.conn.commit(); return cur.lastrowid

    # ---------- Page query helpers (UI never executes SQL directly) ----------
    def purchase_drafts(self):
        return self.purchase_orders(['Draft'])
    def purchase_receivable_orders(self):
        return self.purchase_orders(['Approved','Partially Received'])
    def supplier_purchase_orders(self, supplier_id):
        return self.conn.execute('SELECT id,po_number FROM purchase_orders WHERE supplier_id=? ORDER BY id DESC',(supplier_id,)).fetchall()
    def customer_invoices(self, customer_id):
        return self.conn.execute('SELECT id,invoice_number,total,status FROM sales_invoices WHERE customer_id=? ORDER BY id DESC',(customer_id,)).fetchall()

    def production_skus(self, product_id):
        # Production UI needs the parent product name as well as SKU fields.
        # Keep this in the service layer so Streamlit pages never depend on
        # columns that are not returned by the repository/service query.
        return self.conn.execute(
            '''SELECT s.*, p.name AS product_name, u.name AS unit_name
               FROM skus s
               JOIN products p ON p.id=s.product_id
               LEFT JOIN units u ON u.id=s.unit_id
               WHERE s.product_id=? AND s.is_active=1 AND p.is_active=1
               ORDER BY s.id''',
            (product_id,)
        ).fetchall()
    def pending_production_orders(self):
        return self.production_orders(['Planned'])
    def raw_material_name(self, raw_material_id):
        row=self.conn.execute('SELECT name FROM raw_materials WHERE id=?',(raw_material_id,)).fetchone()
        return row['name'] if row else None
    def completed_production_orders(self):
        return self.production_orders(['Completed'])
    def transactions(self, limit=100):
        limit=max(1,min(int(limit),5000))
        return self.conn.execute('SELECT * FROM transactions ORDER BY id DESC LIMIT ?',(limit,)).fetchall()
    def create_user(self, username, password_hash, role):
        require_permission(self.user['role'],'Approve')
        username=username.strip()
        if not username: raise ValidationError('Username is required')
        if self._unique('users','username',username): raise DuplicateRecordError('Username already exists')
        cur=self.conn.execute('INSERT INTO users(username,password_hash,password_scheme,password_change_required,role) VALUES(?,?,?,?,?)',(username,password_hash,'pbkdf2_sha256',1,role))
        self.conn.commit()
        write_audit(self.conn,user=self._user(),action='user:create',entity='user',entity_id=cur.lastrowid,after={'username':username,'role':role})
        return cur.lastrowid
    def create_employee(self,name,role_title,contact):
        require_permission(self.user['role'],'Approve')
        if not name.strip(): raise ValidationError('Employee name is required')
        cur=self.conn.execute('INSERT INTO employees(name,role_title,contact) VALUES(?,?,?)',(name.strip(),role_title.strip() if role_title else None,contact.strip() if contact else None))
        self.conn.commit()
        write_audit(self.conn,user=self._user(),action='employee:create',entity='employee',entity_id=cur.lastrowid,after={'name':name.strip(),'role_title':role_title})
        return cur.lastrowid

    # ---------- Settings / tasks ----------
    def settings(self): return {r['setting_key']:r['setting_value'] for r in self.conn.execute('SELECT setting_key,setting_value FROM company_settings')}
    def save_setting(self,key,value):
        require_permission(self.user['role'],'Edit'); self.conn.execute('INSERT INTO company_settings(setting_key,setting_value,updated_at,updated_by) VALUES(?,?,datetime(\'now\'),?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=datetime(\'now\'),updated_by=excluded.updated_by',(key,str(value),self._user())); self.conn.commit()
        write_audit(self.conn,user=self._user(),action='setting:update',entity='company_setting',entity_id=key,after={'value':str(value)})
    def tasks(self): return self.conn.execute("SELECT * FROM task_workflows ORDER BY CASE priority WHEN 'High' THEN 0 WHEN 'Normal' THEN 1 ELSE 2 END, COALESCE(due_date,'9999-12-31'), id DESC").fetchall()
    def add_task(self,title,description,priority,due_date,assigned_to):
        require_permission(self.user['role'],'Create'); cur=self.conn.execute('INSERT INTO task_workflows(title,description,priority,due_date,assigned_to,created_by) VALUES(?,?,?,?,?,?)',(title,description,priority,due_date,assigned_to,self._user())); self.conn.commit(); return cur.lastrowid
    def complete_task(self,id_):
        require_permission(self.user['role'],'Edit'); self.conn.execute("UPDATE task_workflows SET status='Completed',completed_at=datetime('now') WHERE id=?",(id_,)); self.conn.commit()

    def add_research_source(self,title,url,source_date,confidence,summary):
        require_permission(self.user['role'],'Create');cur=self.conn.execute('INSERT INTO research_sources(title,source_url,source_date,confidence,summary,created_by) VALUES(?,?,?,?,?,?)',(title,url,source_date,confidence,summary,self._user()));self.conn.commit();write_audit(self.conn,user=self._user(),action='research:add',entity='research_source',entity_id=cur.lastrowid,after={'title':title,'source_date':source_date,'confidence':confidence});return cur.lastrowid
    def research_sources(self):return self.conn.execute('SELECT * FROM research_sources ORDER BY id DESC').fetchall()
    def create_forecast(self,metric,period,value,confidence,basis):
        require_permission(self.user['role'],'Create');cur=self.conn.execute('INSERT INTO forecasts(metric,period,forecast_value,confidence,basis,created_by) VALUES(?,?,?,?,?,?)',(metric,period,str(value),confidence,basis,self._user()));self.conn.commit();return cur.lastrowid
    def forecasts(self):return self.conn.execute('SELECT * FROM forecasts ORDER BY id DESC').fetchall()

    # ---------- Dashboard / reports ----------
    def dashboard(self):
        def count(t,where='1=1'): return self.conn.execute(f'SELECT COUNT(*) FROM {t} WHERE {where}').fetchone()[0]
        low=self.conn.execute('''SELECT rm.id,rm.name,COALESCE(SUM(CAST(sm.quantity AS REAL)),0) balance,CAST(rm.reorder_level AS REAL) reorder_level FROM raw_materials rm LEFT JOIN stock_movements sm ON sm.item_type='raw_material' AND sm.item_id=rm.id WHERE rm.is_active=1 GROUP BY rm.id HAVING balance<=reorder_level ORDER BY balance ASC''').fetchall()
        return {'products':count('products','is_active=1'),'skus':count('skus','is_active=1'),'raw_materials':count('raw_materials','is_active=1'),'suppliers':count('suppliers','is_active=1'),'customers':count('customers','is_active=1'),'pending_production':count('production_orders',"status='Planned'"),'pending_qc':count('batches',"qc_status='Pending'"),'unread_notifications':count('notifications','is_read=0'),'low_stock':low}
    def stock_report(self):
        return self.conn.execute('''SELECT sm.item_type,sm.item_id,CASE WHEN sm.item_type='raw_material' THEN rm.name ELSE p.name END item_name,COALESCE(w.name,'All Warehouses') warehouse,COALESCE(SUM(CAST(sm.quantity AS REAL)),0) balance FROM stock_movements sm LEFT JOIN raw_materials rm ON sm.item_type='raw_material' AND sm.item_id=rm.id LEFT JOIN products p ON sm.item_type='sku' AND sm.item_id=p.id LEFT JOIN warehouses w ON w.id=sm.warehouse_id GROUP BY sm.item_type,sm.item_id,sm.warehouse_id ORDER BY item_type,item_name''').fetchall()
    def audit(self,limit=100): return self.conn.execute('SELECT * FROM audit_log ORDER BY id DESC LIMIT ?', (limit,)).fetchall()

    # ---------- Operational queries / administration ----------
    def purchase_orders(self, statuses=None):
        q='SELECT po.*,s.name supplier_name FROM purchase_orders po JOIN suppliers s ON s.id=po.supplier_id';p=[]
        if statuses:
            placeholders=','.join('?' for _ in statuses);q+=f' WHERE po.status IN ({placeholders})';p.extend(statuses)
        return self.conn.execute(q+' ORDER BY po.id DESC',p).fetchall()
    def purchase_items(self, po_id):
        return self.conn.execute('SELECT i.*,rm.name raw_material_name FROM purchase_order_items i JOIN raw_materials rm ON rm.id=i.raw_material_id WHERE i.po_id=? ORDER BY i.id',(po_id,)).fetchall()
    def production_orders(self, statuses=None):
        q='SELECT po.*,p.name product_name,r.version recipe_version FROM production_orders po JOIN products p ON p.id=po.product_id JOIN recipes r ON r.id=po.recipe_id';p=[]
        if statuses:
            placeholders=','.join('?' for _ in statuses);q+=f' WHERE po.status IN ({placeholders})';p.extend(statuses)
        return self.conn.execute(q+' ORDER BY po.id DESC',p).fetchall()
    def sales_invoices(self, customer_id=None):
        q='SELECT i.*,c.name customer_name FROM sales_invoices i JOIN customers c ON c.id=i.customer_id';p=[]
        if customer_id:q+=' WHERE i.customer_id=?';p.append(customer_id)
        return self.conn.execute(q+' ORDER BY i.id DESC',p).fetchall()
    def users(self): return self.conn.execute('SELECT id,username,role,is_active,last_login,password_change_required FROM users ORDER BY id').fetchall()
    def employees(self): return self.conn.execute('SELECT * FROM employees WHERE is_active=1 ORDER BY id').fetchall()
    def notifications(self): return self.conn.execute('SELECT * FROM notifications ORDER BY is_read, id DESC LIMIT 200').fetchall()
    def pending_qc(self): return self.conn.execute("SELECT b.*,p.name product_name,s.sku_code FROM batches b LEFT JOIN skus s ON b.item_type='sku' AND b.item_id=s.id LEFT JOIN products p ON s.product_id=p.id WHERE b.qc_status='Pending' ORDER BY b.id DESC").fetchall()
    def all_recipes(self, product_id=None):
        q = "SELECT r.*, p.name product_name FROM recipes r JOIN products p ON p.id=r.product_id"
        params = []
        if product_id is not None:
            q += " WHERE r.product_id=?"
            params.append(product_id)
        return self.conn.execute(q + " ORDER BY r.product_id, r.version DESC, r.id DESC", params).fetchall()
    def mark_notification_read(self,id_):
        require_permission(self.user['role'],'Edit');self.conn.execute('UPDATE notifications SET is_read=1 WHERE id=?',(id_,));self.conn.commit()
    def add_warehouse(self,code,name,branch):
        require_permission(self.user['role'],'Create');
        if self._unique('warehouses','name',name) or self._unique('warehouses','code',code): raise DuplicateRecordError('Warehouse name/code already exists')
        cur=self.conn.execute('INSERT INTO warehouses(code,name,branch) VALUES(?,?,?)',(code.strip(),name.strip(),branch.strip() if branch else None));self.conn.commit();write_audit(self.conn,user=self._user(),action='warehouse:create',entity='warehouse',entity_id=cur.lastrowid,after={'code':code,'name':name});return cur.lastrowid
    def add_unit(self,name,base_unit,conversion_factor):
        require_permission(self.user['role'],'Create');name=name.strip();base_unit=base_unit.strip();factor=to_qty(conversion_factor)
        if factor<=0:raise ValidationError('Conversion factor must be positive')
        if self._unique('units','name',name):raise DuplicateRecordError('Unit already exists')
        cur=self.conn.execute('INSERT INTO units(name,base_unit,conversion_factor) VALUES(?,?,?)',(name,base_unit,str(factor)));self.conn.commit();return cur.lastrowid
