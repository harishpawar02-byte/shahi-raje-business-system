from datetime import date
from core.permissions import require_permission
from core.money import to_qty,to_money
from core.exceptions import ValidationError
from core.audit import write_audit
from database.repositories.inventory_repository import InventoryRepository

class ProductionService:
    def __init__(self,conn,current_user):self.conn=conn;self.user=current_user;self.inv_repo=InventoryRepository(conn)
    def create_recipe_version(self,product_id,items,reason='New recipe version'):
        require_permission(self.user['role'],'Create')
        if not items:raise ValidationError('Recipe needs at least one ingredient')
        seen=set();clean=[]
        for it in items:
            rid=int(it['raw_material_id']);qty=to_qty(it['quantity_per_batch'])
            if rid in seen or qty<=0:raise ValidationError('Recipe contains duplicate/invalid ingredient')
            seen.add(rid);clean.append((rid,qty))
        last=self.conn.execute('SELECT COALESCE(MAX(version),0) FROM recipes WHERE product_id=?',(product_id,)).fetchone()[0];v=last+1
        try:
            self.conn.execute('BEGIN');self.conn.execute('UPDATE recipes SET is_active=0 WHERE product_id=?',(product_id,));cur=self.conn.execute('INSERT INTO recipes(product_id,version,is_active) VALUES(?,?,1)',(product_id,v))
            for rid,qty in clean:self.conn.execute('INSERT INTO recipe_items(recipe_id,raw_material_id,quantity_per_batch) VALUES(?,?,?)',(cur.lastrowid,rid,str(qty)))
            self.conn.execute('INSERT INTO recipe_change_log(recipe_id,action,version,changed_by,reason) VALUES(?,?,?,?,?)',(cur.lastrowid,'CREATE',v,self.user['username'],reason))
            write_audit(self.conn,user=self.user['username'],action='recipe:new_version',entity='recipe',entity_id=cur.lastrowid,after={'product_id':product_id,'version':v,'items':[{'raw_material_id':r,'quantity':str(q)} for r,q in clean]},commit=False);self.conn.commit();return cur.lastrowid,v
        except Exception:self.conn.rollback();raise
    def active_recipe(self,product_id):return self.conn.execute('SELECT * FROM recipes WHERE product_id=? AND is_active=1',(product_id,)).fetchone()
    def all_recipes(self,product_id=None):
        q='SELECT r.*,p.name product_name FROM recipes r JOIN products p ON p.id=r.product_id';p=[]
        if product_id:q+=' WHERE r.product_id=?';p.append(product_id)
        return self.conn.execute(q+' ORDER BY r.product_id,r.version DESC',p).fetchall()
    def recipe_items(self,recipe_id):return self.conn.execute('SELECT ri.*,rm.name raw_material_name FROM recipe_items ri JOIN raw_materials rm ON rm.id=ri.raw_material_id WHERE ri.recipe_id=? ORDER BY ri.id',(recipe_id,)).fetchall()
    def plan_production(self,product_id,recipe_id,planned_qty,rm_rates=None,output_sku_id=None,warehouse_id=None):
        require_permission(self.user['role'],'Create');qty=to_qty(planned_qty);rm_rates=rm_rates or {}
        if qty<=0:raise ValidationError('Planned quantity must be positive')
        recipe=self.conn.execute('SELECT * FROM recipes WHERE id=? AND product_id=?',(recipe_id,product_id)).fetchone()
        if not recipe:raise ValidationError('Recipe does not belong to product')
        est=to_money(0)
        for it in self.recipe_items(recipe_id):est += to_money(to_qty(it['quantity_per_batch'])*qty)*to_money(rm_rates.get(it['raw_material_id'],0))
        n=self.conn.execute("SELECT COUNT(*) FROM production_orders WHERE date(created_at)=date('now')").fetchone()[0]+1;num=f'PRD-{date.today():%Y%m%d}-{n:03d}'
        cur=self.conn.execute('INSERT INTO production_orders(production_number,product_id,recipe_id,planned_qty,estimated_cost,created_by,output_sku_id,warehouse_id) VALUES(?,?,?,?,?,?,?,?)',(num,product_id,recipe_id,str(qty),str(est),self.user['username'],output_sku_id,warehouse_id));self.conn.commit();write_audit(self.conn,user=self.user['username'],action='production:plan',entity='production_order',entity_id=cur.lastrowid,after={'number':num,'recipe_id':recipe_id,'recipe_version':recipe['version'],'planned_qty':str(qty)});return cur.lastrowid,num,est
    def consume_and_produce(self,*,production_order_id,product_id,consumptions,output_batch_number,output_qty,wastage_qty=0,mfg_date=None,expiry_date=None,qc_status='Pending',qc_result=None,warehouse_id=None,output_sku_id=None,qc_inspector=None):
        require_permission(self.user['role'],'Create');out=to_qty(output_qty);wast=to_qty(wastage_qty)
        if out<=0:raise ValidationError('Produced quantity must be positive')
        if wast<0:raise ValidationError('Wastage cannot be negative')
        po=self.conn.execute('SELECT * FROM production_orders WHERE id=?',(production_order_id,)).fetchone()
        if not po or po['status']!='Planned':raise ValidationError('Production order is not available')
        if to_qty(po['planned_qty']) < out+wast:raise ValidationError('Produced quantity + wastage cannot exceed planned quantity')
        sku_id=output_sku_id or po['output_sku_id']
        if not sku_id:
            fallback=self.conn.execute('SELECT id FROM skus WHERE product_id=? AND is_active=1 ORDER BY id LIMIT 1',(product_id,)).fetchone()
            sku_id=fallback['id'] if fallback else None
        if not sku_id:raise ValidationError('No active output SKU exists for this product')
        sku=self.conn.execute('SELECT product_id FROM skus WHERE id=? AND is_active=1',(sku_id,)).fetchone()
        if not sku or sku['product_id']!=product_id:raise ValidationError('Output SKU does not belong to selected product')
        recipe=self.conn.execute('SELECT * FROM recipes WHERE id=?',(po['recipe_id'],)).fetchone()
        expected={r['raw_material_id']:to_qty(r['quantity_per_batch'])*to_qty(po['planned_qty']) for r in self.recipe_items(po['recipe_id'])}
        actual_consumed={}
        for c in consumptions:actual_consumed[c['raw_material_id']]=actual_consumed.get(c['raw_material_id'],to_qty(0))+to_qty(c['quantity'])
        if set(actual_consumed)!=set(expected):raise ValidationError('Consumption must contain every recipe ingredient exactly once')
        for rid,qty in expected.items():
            if actual_consumed[rid] < 0 or actual_consumed[rid] > qty:raise ValidationError('Consumption exceeds recipe requirement')
        if qc_status not in ('Passed','Failed','Pending'):raise ValidationError('Invalid QC status')
        try:
            self.conn.execute('BEGIN');actual=to_money(0)
            for c in consumptions:
                qty=to_qty(c['quantity']);rate=to_money(c.get('rate',0));
                self.inv_repo.record_movement(item_type='raw_material',item_id=c['raw_material_id'],movement_type='Production',quantity=-qty,batch_id=c.get('batch_id'),warehouse_id=warehouse_id,reference=po['production_number'],user=self.user['username'],commit=False)
                self.conn.execute('INSERT INTO production_consumption(production_order_id,raw_material_id,batch_id,quantity,rate,warehouse_id) VALUES(?,?,?,?,?,?)',(production_order_id,c['raw_material_id'],c.get('batch_id'),str(qty),str(rate),warehouse_id));actual += qty*rate
            batch=self.inv_repo.create_batch(batch_number=output_batch_number,item_type='sku',item_id=sku_id,mfg_date=mfg_date,expiry_date=expiry_date,recipe_version_id=po['recipe_id'],commit=False)
            saleable=1 if qc_status=='Passed' else 0
            self.conn.execute('UPDATE batches SET qc_status=?,qc_result=?,approved_by=?,qc_date=?,qc_inspector=?,saleable=? WHERE id=?',(qc_status,qc_result,self.user['username'] if qc_status=='Passed' else None,date.today().isoformat(),qc_inspector or self.user['username'],saleable,batch))
            self.conn.execute('INSERT INTO qc_records(batch_id,inspector,parameters_json,result,remarks,approved_by) VALUES(?,?,?,?,?,?)',(batch,qc_inspector or self.user['username'],'{}',qc_status,qc_result,self.user['username'] if qc_status=='Passed' else None))
            if qc_status=='Passed':self.inv_repo.record_movement(item_type='sku',item_id=sku_id,movement_type='Production',quantity=out,batch_id=batch,warehouse_id=warehouse_id,reference=po['production_number'],user=self.user['username'],commit=False)
            self.conn.execute("UPDATE production_orders SET produced_qty=?,wastage_qty=?,output_batch_id=?,status='Completed',actual_cost=?,output_sku_id=?,warehouse_id=?,qc_status=?,approved_by=? WHERE id=?",(str(out),str(wast),batch,str(actual),sku_id,warehouse_id,qc_status,self.user['username'] if qc_status=='Passed' else None,production_order_id))
            write_audit(self.conn,user=self.user['username'],action='production:complete',entity='production_order',entity_id=production_order_id,after={'batch':output_batch_number,'sku_id':sku_id,'recipe_version':recipe['version'] if recipe else None,'qc_status':qc_status,'actual_cost':str(actual)},commit=False);self.conn.commit();return batch,actual,(actual/to_money(out) if out else to_money(0))
        except Exception:self.conn.rollback();raise
    def approve_qc(self,batch_id,remarks=''):
        require_permission(self.user['role'],'Approve');b=self.conn.execute('SELECT * FROM batches WHERE id=?',(batch_id,)).fetchone()
        if not b:raise ValidationError('Batch not found')
        if b['qc_status']!='Pending':raise ValidationError('Batch is not pending QC')
        self.conn.execute("UPDATE batches SET qc_status='Passed',saleable=1,approved_by=?,qc_date=?,qc_result=? WHERE id=?",(self.user['username'],date.today().isoformat(),remarks,batch_id))
        self.conn.execute("UPDATE qc_records SET result='Passed',approved_by=?,remarks=? WHERE batch_id=? AND result='Pending'",(self.user['username'],remarks,batch_id))
        # Production output is posted only after approval; this is what makes Pending batches non-saleable/non-stocked.
        po=self.conn.execute('SELECT * FROM production_orders WHERE output_batch_id=?',(batch_id,)).fetchone()
        if po and not self.inv_repo.get_balance('sku',po['output_sku_id'],po['warehouse_id'],batch_id)>0:
            self.inv_repo.record_movement(item_type='sku',item_id=po['output_sku_id'],movement_type='Production',quantity=to_qty(po['produced_qty']),batch_id=batch_id,warehouse_id=po['warehouse_id'],reference=po['production_number'],user=self.user['username'],commit=False)
            self.conn.commit()
        write_audit(self.conn,user=self.user['username'],action='qc:approve',entity='batch',entity_id=batch_id,after={'qc_status':'Passed'},approved_by=self.user['username'],commit=False);self.conn.commit()
