"""Deterministic, auditable business agents. No external API is required."""
from core.permissions import require_permission
from core.audit import write_audit
from core.money import to_money
from services.notification_service import NotificationService

class AgentService:
    def __init__(self,conn,current_user):self.conn=conn;self.user=current_user
    def _add(self,name,text,basis):
        cur=self.conn.execute('INSERT INTO agent_recommendations(agent_name,recommendation,based_on) VALUES(?,?,?)',(name,text,basis));self.conn.commit();return cur.lastrowid
    def run_inventory_agent(self):
        rows=self.conn.execute('''SELECT rm.id,rm.name,COALESCE(SUM(CAST(sm.quantity AS REAL)),0) balance,CAST(rm.reorder_level AS REAL) reorder_level,CAST(rm.max_level AS REAL) max_level FROM raw_materials rm LEFT JOIN stock_movements sm ON sm.item_type='raw_material' AND sm.item_id=rm.id WHERE rm.is_active=1 GROUP BY rm.id HAVING balance<=reorder_level''').fetchall();ids=[]
        for r in rows:
            pending=self.conn.execute("SELECT 1 FROM agent_recommendations WHERE agent_name='InventoryAgent' AND status='Pending' AND recommendation LIKE ?",(f"%{r['name']}%",)).fetchone()
            if not pending:ids.append(self._add('InventoryAgent',f"Reorder '{r['name']}'. Current stock {r['balance']:.2f}; reorder level {r['reorder_level']:.2f}; target max {r['max_level']:.2f}.",'raw material ledger vs reorder/min/max configuration'))
        return ids
    def run_finance_agent(self):
        row=self.conn.execute("SELECT COALESCE(SUM(CASE WHEN txn_type='Sale' THEN CAST(amount AS REAL) ELSE 0 END),0) sales,COALESCE(SUM(CASE WHEN txn_type='Expense' THEN CAST(amount AS REAL) ELSE 0 END),0) expenses,COALESCE(SUM(CASE WHEN txn_type='Purchase' THEN CAST(amount AS REAL) ELSE 0 END),0) purchases FROM transactions").fetchone();profit=row['sales']-row['expenses']-row['purchases'];return self._add('FinanceAgent',f"Current ledger totals: sales ₹{row['sales']:.2f}, purchases ₹{row['purchases']:.2f}, expenses ₹{row['expenses']:.2f}, simple ledger surplus ₹{profit:.2f}.",'transactions ledger; this is an operational indicator, not statutory accounting')
    def run_ceo_agent(self):
        d=self.conn.execute('SELECT COUNT(*) pending FROM task_workflows WHERE status="Pending"').fetchone()['pending'];p=self.conn.execute('SELECT COUNT(*) n FROM production_orders WHERE status="Planned"').fetchone()['n'];n=self.conn.execute('SELECT COUNT(*) n FROM notifications WHERE is_read=0').fetchone()['n'];return self._add('CEOAgent',f"Owner briefing: {d} pending tasks, {p} planned production orders, {n} unread notifications. Review these queues before sensitive approvals.",'internal MIS operational tables only')
    def pending_recommendations(self):return self.conn.execute("SELECT * FROM agent_recommendations WHERE status='Pending' ORDER BY id DESC").fetchall()
    def approve(self,rec_id):
        require_permission(self.user['role'],'Approve');r=self.conn.execute('SELECT * FROM agent_recommendations WHERE id=? AND status=\'Pending\'',(rec_id,)).fetchone()
        if not r:return False
        self.conn.execute("UPDATE agent_recommendations SET status='Approved',approved_by=?,decided_at=datetime('now') WHERE id=?",(self.user['username'],rec_id));write_audit(self.conn,user=self.user['username'],action='agent:approve',entity='agent_recommendation',entity_id=rec_id,after={'status':'Approved'},approved_by=self.user['username'],commit=False);self.conn.commit();return True
    def reject(self,rec_id,reason=''):
        require_permission(self.user['role'],'Approve');self.conn.execute("UPDATE agent_recommendations SET status='Rejected',approved_by=?,decided_at=datetime('now') WHERE id=? AND status='Pending'",(self.user['username'],rec_id));write_audit(self.conn,user=self.user['username'],action='agent:reject',entity='agent_recommendation',entity_id=rec_id,after={'status':'Rejected'},reason=reason,approved_by=self.user['username'],commit=False);self.conn.commit()
