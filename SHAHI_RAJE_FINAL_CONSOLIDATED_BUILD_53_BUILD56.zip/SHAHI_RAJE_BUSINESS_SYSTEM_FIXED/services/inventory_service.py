from core.permissions import require_permission
from core.money import to_qty
from database.repositories.inventory_repository import InventoryRepository
from services.mis_service import MISService

class InventoryService:
    def __init__(self,conn,current_user): self.conn=conn; self.user=current_user; self.repo=InventoryRepository(conn)
    def stock_in(self,**kw):
        require_permission(self.user['role'],'Create'); kw['quantity']=abs(to_qty(kw['quantity'])); kw['user']=self.user['username']; return self.repo.record_movement(**kw)
    def stock_out(self,**kw):
        require_permission(self.user['role'],'Create'); kw['quantity']=-abs(to_qty(kw['quantity'])); kw['user']=self.user['username']; return self.repo.record_movement(**kw)
    def balance(self,item_type,item_id,warehouse_id=None): return self.repo.get_balance(item_type,item_id,warehouse_id)
    def fefo_suggestion(self,item_type,item_id,warehouse_id=None): return self.repo.fefo_batches(item_type,item_id,warehouse_id)
    def correct(self,movement_id,corrected_quantity,reason,allow_negative_override=False):
        return MISService(self.conn,self.user).correct_stock(movement_id,corrected_quantity,reason,allow_negative_override=allow_negative_override)

    def transfer(self, *, item_type, item_id, quantity, source_warehouse_id=None, destination_warehouse_id=None, batch_id=None, reference=None):
        require_permission(self.user['role'], 'Create')
        qty = to_qty(quantity)
        if qty <= 0:
            raise ValueError('Transfer quantity must be positive')
        if source_warehouse_id == destination_warehouse_id:
            raise ValueError('Source and destination warehouse must be different')
        if destination_warehouse_id is None:
            raise ValueError('Destination warehouse is required')
        available = self.repo.get_unassigned_balance(item_type, item_id, batch_id) if source_warehouse_id is None else self.repo.get_balance(item_type, item_id, source_warehouse_id, batch_id)
        if available < qty:
            from core.exceptions import InsufficientStockError
            raise InsufficientStockError(f'Insufficient stock for transfer (available {available})')
        try:
            self.conn.execute('BEGIN')
            ref = reference or 'Stock Transfer'
            self.repo.record_movement(item_type=item_type, item_id=item_id, movement_type='Transfer OUT', quantity=-qty,
                                      warehouse_id=source_warehouse_id, batch_id=batch_id, reference=ref,
                                      user=self.user['username'], source='inventory_transfer', commit=False)
            self.repo.record_movement(item_type=item_type, item_id=item_id, movement_type='Transfer IN', quantity=qty,
                                      warehouse_id=destination_warehouse_id, batch_id=batch_id, reference=ref,
                                      user=self.user['username'], source='inventory_transfer', commit=False)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
