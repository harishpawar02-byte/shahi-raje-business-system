from datetime import date
from core.permissions import require_permission
from core.money import to_qty,to_money
from core.audit import write_audit
from core.exceptions import ValidationError
from database.repositories.purchase_repository import PurchaseOrderRepository
from database.repositories.inventory_repository import InventoryRepository

class PurchaseService:
    def __init__(self,conn,current_user): self.conn=conn;self.user=current_user;self.po_repo=PurchaseOrderRepository(conn);self.inv_repo=InventoryRepository(conn)
    def _next(self,table,date_field,prefix):
        n=self.conn.execute(f"SELECT COUNT(*)+1 FROM {table} WHERE date({date_field})=date('now')").fetchone()[0];return f"{prefix}-{date.today():%Y%m%d}-{n:03d}"
    def create_po(self,supplier_id,items):
        require_permission(self.user['role'],'Create')
        if not items: raise ValidationError('At least one PO item is required')
        po=self._next('purchase_orders','order_date','PO'); cur=self.conn.execute('INSERT INTO purchase_orders(po_number,supplier_id,created_by) VALUES(?,?,?)',(po,supplier_id,self.user['username']))
        for it in items:self.conn.execute('INSERT INTO purchase_order_items(po_id,raw_material_id,quantity,rate) VALUES(?,?,?,?)',(cur.lastrowid,it['raw_material_id'],str(to_qty(it['quantity'])),str(to_money(it['rate']))))
        write_audit(self.conn,user=self.user['username'],action='po:create',entity='purchase_order',entity_id=cur.lastrowid,after={'po_number':po,'items':items},commit=False);self.conn.commit();return cur.lastrowid,po
    def approve_po(self,po_id):
        require_permission(self.user['role'],'Approve'); row=self.conn.execute('SELECT * FROM purchase_orders WHERE id=?',(po_id,)).fetchone()
        if not row or row['status']!='Draft':raise ValidationError('Only Draft PO can be approved')
        self.conn.execute("UPDATE purchase_orders SET status='Approved' WHERE id=?",(po_id,));write_audit(self.conn,user=self.user['username'],action='po:approve',entity='purchase_order',entity_id=po_id,approved_by=self.user['username'],commit=False);self.conn.commit()
    def receive_goods(self,po_id,receipts,warehouse_id=None):
        require_permission(self.user['role'],'Create'); po=self.conn.execute('SELECT * FROM purchase_orders WHERE id=?',(po_id,)).fetchone()
        if not po or po['status'] not in ('Approved','Partially Received'): raise ValidationError('PO must be approved before receipt')
        if not receipts: raise ValidationError('Receipt lines required')
        try:
            self.conn.execute('BEGIN'); grn=self._next('goods_receipts','received_date','GRN'); cur=self.conn.execute('INSERT INTO goods_receipts(grn_number,po_id,received_by) VALUES(?,?,?)',(grn,po_id,self.user['username']));grn_id=cur.lastrowid;total=to_money(0)
            for r in receipts:
                item=self.conn.execute('SELECT * FROM purchase_order_items WHERE id=? AND po_id=?',(r['po_item_id'],po_id)).fetchone()
                if not item: raise ValidationError('Invalid PO item')
                qty=to_qty(r['quantity']); ordered=to_qty(item['quantity']); received=to_qty(item['received_qty']);
                if qty<=0 or received+qty>ordered: raise ValidationError('Receipt quantity exceeds ordered quantity')
                batch=None
                if r.get('batch_number'): batch=self.inv_repo.create_batch(batch_number=r['batch_number'],item_type='raw_material',item_id=r['raw_material_id'],mfg_date=r.get('mfg_date'),expiry_date=r.get('expiry_date'),commit=False)
                self.conn.execute('INSERT INTO goods_receipt_items(grn_id,po_item_id,batch_id,quantity) VALUES(?,?,?,?)',(grn_id,r['po_item_id'],batch,str(qty)))
                self.inv_repo.record_movement(item_type='raw_material',item_id=r['raw_material_id'],movement_type='Purchase',quantity=qty,warehouse_id=warehouse_id,batch_id=batch,reference=grn,user=self.user['username'],commit=False)
                self.conn.execute('UPDATE purchase_order_items SET received_qty=? WHERE id=?',(str(received+qty),item['id']));total += qty*to_money(r.get('rate',item['rate']))
            status='Received' if all(to_qty(r['quantity'])>=to_qty(r['received_qty']) for r in self.conn.execute('SELECT quantity,received_qty FROM purchase_order_items WHERE po_id=?',(po_id,))) else 'Partially Received'
            self.conn.execute('UPDATE purchase_orders SET status=? WHERE id=?',(status,po_id))
            self.conn.execute("INSERT INTO supplier_payables(supplier_id,po_id,amount,entry_type,reference) VALUES(?,?,?,'Invoice',?)",(po['supplier_id'],po_id,str(to_money(total)),grn))
            self.conn.execute("INSERT INTO transactions(txn_type,category,amount,reference,created_by,source_type,source_id) VALUES('Purchase','Raw Material',?,?,?,'GRN',?)",(str(to_money(total)),grn,self.user['username'],str(grn_id)))
            write_audit(self.conn,user=self.user['username'],action='grn:receive',entity='goods_receipt',entity_id=grn_id,after={'grn_number':grn,'po_id':po_id,'value':str(to_money(total))},commit=False);self.conn.commit();return grn_id,grn
        except Exception:self.conn.rollback();raise
    def record_payment(self,supplier_id,po_id,amount,reference=None,payment_mode=None):
        require_permission(self.user['role'],'Create');amt=to_money(amount)
        outstanding=self.outstanding_payable(supplier_id)
        if amt<=0 or amt>outstanding: raise ValidationError(f'Payment exceeds outstanding payable ({outstanding})')
        self.conn.execute("INSERT INTO supplier_payables(supplier_id,po_id,amount,entry_type,reference) VALUES(?,?,?,?,?)",(supplier_id,po_id,str(-amt),'Payment',reference));self.conn.execute("INSERT INTO transactions(txn_type,category,amount,reference,created_by,payment_mode) VALUES('Payment-Out','Payable',?,?,?,?)",(str(amt),reference,self.user['username'],payment_mode));write_audit(self.conn,user=self.user['username'],action='payment:pay_supplier',entity='supplier_payable',entity_id=po_id,after={'amount':str(amt)},commit=False);self.conn.commit()
    def outstanding_payable(self,supplier_id):return to_money(self.conn.execute('SELECT COALESCE(SUM(CAST(amount AS REAL)),0) FROM supplier_payables WHERE supplier_id=?',(supplier_id,)).fetchone()[0])
