from core.money import to_money
from core.permissions import require_permission
from core.audit import write_audit
from core.exceptions import ValidationError

class FinanceService:
    def __init__(self,conn,current_user):self.conn=conn;self.user=current_user
    def record_expense(self,category,amount,reference=None,notes=None,payment_mode=None):
        require_permission(self.user['role'],'Create');amt=to_money(amount)
        if amt<=0:raise ValidationError('Amount must be positive')
        cur=self.conn.execute("INSERT INTO transactions(txn_type,category,amount,reference,notes,created_by,payment_mode) VALUES('Expense',?,?,?,?,?,?)",(category,str(amt),reference,notes,self.user['username'],payment_mode));self.conn.commit();write_audit(self.conn,user=self.user['username'],action='finance:expense',entity='transaction',entity_id=cur.lastrowid,after={'amount':str(amt),'category':category});return cur.lastrowid
    def summary(self,from_date=None,to_date=None):
        q='SELECT txn_type,SUM(CAST(amount AS REAL)) total FROM transactions';p=[]
        if from_date and to_date:q+=' WHERE txn_date BETWEEN ? AND ?';p=[from_date,to_date]
        q+=' GROUP BY txn_type';tot={r['txn_type']:to_money(r['total']) for r in self.conn.execute(q,p)}
        revenue=tot.get('Sale',to_money(0));expense=tot.get('Expense',to_money(0));purchase=tot.get('Purchase',to_money(0));return {'revenue':revenue,'expense':expense,'purchase':purchase,'profit':revenue-expense-purchase,'by_type':tot}
    def costing_variance(self,id_):
        r=self.conn.execute('SELECT estimated_cost,actual_cost,produced_qty FROM production_orders WHERE id=?',(id_,)).fetchone()
        if not r or r['actual_cost'] is None:return None
        est=to_money(r['estimated_cost'] or 0);act=to_money(r['actual_cost'] or 0);pct=((act-est)/est*to_money(100)) if est else to_money(0);return {'estimated':est,'actual':act,'variance':act-est,'variance_pct':pct}
