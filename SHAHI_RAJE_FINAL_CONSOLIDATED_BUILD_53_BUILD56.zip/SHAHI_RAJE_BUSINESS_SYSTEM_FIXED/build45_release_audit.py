from pathlib import Path
import sqlite3, hashlib, re, sys

ROOT=Path(__file__).resolve().parent
DB=ROOT/'data'/'mis.db'
ANDROID=ROOT.parent/'SHAHI_RAJE_ANDROID_READY_SOURCE'
errors=[]
if not DB.exists(): errors.append('DB_MISSING')
else:
    con=sqlite3.connect(DB); con.execute('PRAGMA foreign_keys=ON')
    fk=[r for r in con.execute('PRAGMA foreign_key_check').fetchall()]
    if fk: errors.append(f'FK_ERRORS:{len(fk)}')
    tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    required={'products','skus','raw_materials','suppliers','customers','stock_movements','audit_log','users','schema_migrations'}
    errors += [f'MISSING_TABLE:{t}' for t in sorted(required-tables)]
    con.close()
manifest=ANDROID/'app'/'src'/'main'/'AndroidManifest.xml'
gradle=ANDROID/'app'/'build.gradle'
for p in (manifest,gradle):
    if not p.exists(): errors.append('ANDROID_FILE_MISSING:'+str(p.name))
if manifest.exists():
    text=manifest.read_text(encoding='utf-8')
    if 'android:exported="true"' not in text: errors.append('MAIN_ACTIVITY_EXPORTED_NOT_DECLARED')
    if 'usesCleartextTraffic="true"' in text: errors.append('CLEARTEXT_ENABLED')
if gradle.exists():
    text=gradle.read_text(encoding='utf-8')
    if 'targetSdk' not in text: errors.append('TARGET_SDK_UNSET')

print('BUILD-45 RELEASE AUDIT')
print('DB=', DB)
print('ANDROID_SOURCE=', ANDROID)
print('ERRORS=', errors)
if errors: sys.exit(1)
print('PASS')
