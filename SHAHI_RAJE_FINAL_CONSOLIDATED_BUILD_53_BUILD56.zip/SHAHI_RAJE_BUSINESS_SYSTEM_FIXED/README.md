# SHAHI RAJE BUSINESS MANAGEMENT SYSTEM

## Final consolidated local MIS build — Phases 0–12

This package is the consolidated build. It is designed for a small spice/manufacturing business and keeps SQLite as the local source of truth.

### Included

- Secure login with PBKDF2-HMAC-SHA256 and transparent legacy-password upgrade
- Owner/Admin and functional role permissions
- Products and configurable SKUs/package sizes
- Raw materials with units, conversion, reorder/min/max and preferred supplier
- Packaging-material master
- Suppliers and customers with business details
- Append-only inventory ledger, batch tracking, FEFO suggestions and safe correction workflow
- Negative-stock protection with Owner/Admin override requiring an audit trail
- Purchase: PO → approval → GRN → stock-in → payable → payment
- Production: recipe versioning → production order → consumption → batch → QC → finished stock
- Recipe versions remain immutable and production orders retain their recipe version reference
- Sales: invoice → stock issue → receivable → payment
- Configurable GST presentation (GST / intra-state / inter-state / exempt metadata); statutory compliance must be independently verified
- Finance: operational transaction ledger, expenses, P&L-style indicator and production cost variance
- HR/Admin: users and employees
- Four UI languages: Marathi, Hindi, English, Gujarati
- Task/work queue and in-app notifications
- Rule-based Inventory, Finance and CEO agents with explicit Owner/Admin approval for recommendations
- Market-research source register with source/date/confidence fields
- Forecast register that clearly labels forecast values and their basis
- Backup validation and safe restore with a pre-restore safety backup
- Numbered, idempotent migrations
- Audit logging for important changes
- Automated tests for core workflows, hardening, UI sequencing and page/service architecture
- Windows helper scripts

### External services deliberately not required

The core MIS works locally without paid APIs. Cloud hosting, PostgreSQL hosting, WhatsApp/SMS/email gateways, hardware barcode scanners and third-party LLM APIs are not required for the core system and are therefore not faked or represented as connected.

### Run on Windows

1. Ensure Python 3.11+ is installed.
2. Double-click `START_SHAHI_RAJE.bat`.
3. The script creates/uses `.venv`, installs `requirements.txt`, applies migrations and starts Streamlit.
4. Open the displayed local address.

### Security

The seeded owner account uses the initial password `HR/Admin` and is flagged to require a password change. Change it before real use.

Do not put passwords, API keys or other secrets in source files or logs.

### Data protection

Business history is preserved. Inventory corrections append a compensating ledger row instead of editing the original row. Recipe versions used by production remain referenced by the production record. Financial, purchase, sales, production and audit records are not silently deleted.

### Verification performed on this package

- Python compilation: PASS
- Automated tests: **27 passed**
- SQLite `PRAGMA integrity_check`: **ok**
- SQLite foreign-key check: **0 errors**
- Migration set: **v001–v010 (v010 adds the controlled Sales Order workflow)**
- Migration idempotency: PASS
- Existing business-data counts preserved; v010 is additive and does not rewrite existing sales/inventory history
- Final build includes append-only sales cancellation, QC approval, password management, reports, task/notification control, operational settings and the Sales Order → Stock Check → Picking → Invoice + Stock Issue workflow
- Final audit also verifies that Streamlit pages do not execute SQL directly, all displayed tables use a human-facing 1..N serial sequence, and no DeltaGenerator/object/debug leakage is present

### Important limitation

The assistant cannot directly control or deploy software on the owner's Windows laptop from this chat. This package is the consolidated artifact; after replacing the local project with it, the supplied Windows starter script is the intended zero-code startup path.

This is operational MIS software, not a claim of statutory accounting/tax/legal compliance.
