"""
Central configuration for the MIS application.
Change values here (or via environment variables) — never hard-code
paths / secrets inside individual pages or services.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
BACKUP_DIR = BASE_DIR / "backups"
DB_PATH = os.environ.get("MIS_DB_PATH", str(DATA_DIR / "mis.db"))

DATA_DIR.mkdir(exist_ok=True)
BACKUP_DIR.mkdir(exist_ok=True)

# Money / quantity precision (Decimal places)
MONEY_DECIMALS = 2
QTY_DECIMALS = 3

APP_NAME = "SHAHI RAJE BUSINESS MANAGEMENT SYSTEM"
